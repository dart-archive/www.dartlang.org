This example shows how to write a simple pub transformer.

For more information, see Writing a Pub Transformer:
https://www.dartlang.org/tools/pub/transformers/
