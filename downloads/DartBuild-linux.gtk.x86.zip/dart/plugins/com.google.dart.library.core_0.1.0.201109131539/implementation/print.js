// Copyright 2011 Google Inc. All Rights Reserved.

function native__Logger_native_print(str) {
  var log = function(msg) {
    if (this.console) this.console.log(msg);
    else if (this.write) this.write(msg);
  };
  log(str);
}
