// Copyright 2011 Google Inc. All Rights Reserved.

class StringReplaceTest {
  static testMain() {
    Expect.equals(
        "AtoBtoCDtoE", "AfromBtoCDtoE".replace("from", "to"));

    // Test with the replaced string at the begining.
    Expect.equals(
        "toABtoCDtoE", "fromABtoCDtoE".replace("from", "to"));

    // Test with the replaced string at the end.
    Expect.equals(
        "toABtoCDtoEto", "fromABtoCDtoEto".replace("from", "to"));

    // Test when there are no occurence of the string to replace.
    Expect.equals("ABC", "ABC".replace("from", "to"));

    // Test when the string to change is the empty string.
    Expect.equals("", "".replace("from", "to"));

    // Test when the string to change is a substring of the string to
    // replace.
    Expect.equals("fro", "fro".replace("from", "to"));

    // Test when the string to change is the replaced string.
    Expect.equals("to", "from".replace("from", "to"));

    // Test when the string to change is the replacement string.
    Expect.equals("to", "to".replace("from", "to"));

    // Test replacing by the empty string.
    Expect.equals("", "from".replace("from", ""));
    Expect.equals("AB", "AfromB".replace("from", ""));

    // Test changing the empty string.
    Expect.equals("to", "".replace("", "to"));

    // Test replacing the empty string.
    Expect.equals("toAtoBtoCto", "AtoBtoCto".replace("", "to"));
  }
}

main() {
  StringReplaceTest.testMain();
}
