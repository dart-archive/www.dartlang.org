// Copyright 2011 Google Inc. All Rights Reserved.

class UnicodeTest {

  static testMain() {
    var lowerStrasse =
        new String.fromCharCodes([115, 116, 114, 97, 223, 101]);
    Expect.equals("STRASSE", lowerStrasse.toUpperCase());
  }
}

main() {
  UnicodeTest.testMain();
}
