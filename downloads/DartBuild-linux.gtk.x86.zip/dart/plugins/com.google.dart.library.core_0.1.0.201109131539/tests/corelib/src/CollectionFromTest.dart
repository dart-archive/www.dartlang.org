// Copyright 2011 Google Inc. All Rights Reserved.

class CollectionFromTest {
  static testMain() {
    var set = new Set<int>();
    set.add(1);
    set.add(2);
    set.add(4);
    check(set, new Array<int>.from(set));
    check(set, new Array.from(set));
    check(set, new List<int>.from(set));
    check(set, new List.from(set));
    check(set, new Set<int>.from(set));
    check(set, new Set.from(set));
  }


  static check(Collection initial, Collection other) {
    Expect.equals(3, initial.length);
    Expect.equals(initial.length, other.length);

    int initialSum = 0;
    int otherSum = 0;

    initial.forEach(void f(e) { initialSum += e; });
    other.forEach(void f(e) { otherSum += e; });
    Expect.equals(4 + 2 + 1, otherSum);
    Expect.equals(otherSum, initialSum);
  }
}

main() {
  CollectionFromTest.testMain();
}
