// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * The class [Clock] provides access to a monotonically incrementing clock
 * device.
 */
class Clock {

  /**
   * Returns the current clock tick.
   */
  static int now() {
    return new DateTime.now().value;
  }

  /**
   * Returns the frequency of clock ticks in Hz.
   */
  static int frequency() {
    return 1000;
  }

}
