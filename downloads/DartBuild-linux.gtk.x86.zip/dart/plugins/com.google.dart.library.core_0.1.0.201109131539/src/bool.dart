// Copyright 2011 Google Inc. All Rights Reserved.
// Dart core library.

interface bool {
}
