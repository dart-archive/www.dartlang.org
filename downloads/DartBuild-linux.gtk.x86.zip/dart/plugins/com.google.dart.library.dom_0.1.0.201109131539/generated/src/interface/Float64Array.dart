/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface Float64Array extends ArrayBufferView {

  static final int BYTES_PER_ELEMENT = 8;

  int get length();

  Float64Array subarray(int start = null, int end = null);
}
