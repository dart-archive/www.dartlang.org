/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface CloseEvent extends Event {

  int get code();

  String get reason();

  bool get wasClean();

  void initCloseEvent(String typeArg = null, bool canBubbleArg = null, bool cancelableArg = null, bool wasCleanArg = null, int codeArg = null, String reasonArg = null);
}
