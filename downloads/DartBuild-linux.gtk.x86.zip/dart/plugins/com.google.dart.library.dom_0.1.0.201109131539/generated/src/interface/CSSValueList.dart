/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface CSSValueList extends CSSValue {

  int get length();

  CSSValue item(int index = null);
}
