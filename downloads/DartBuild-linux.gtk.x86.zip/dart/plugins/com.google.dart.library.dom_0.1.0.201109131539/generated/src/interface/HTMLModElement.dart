/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLModElement extends HTMLElement {

  String get cite();

  void set cite(String value);

  String get dateTime();

  void set dateTime(String value);
}
