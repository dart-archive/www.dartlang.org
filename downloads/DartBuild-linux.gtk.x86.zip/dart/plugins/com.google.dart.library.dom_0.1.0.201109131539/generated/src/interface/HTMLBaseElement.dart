/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLBaseElement extends HTMLElement {

  String get href();

  void set href(String value);

  String get target();

  void set target(String value);
}
