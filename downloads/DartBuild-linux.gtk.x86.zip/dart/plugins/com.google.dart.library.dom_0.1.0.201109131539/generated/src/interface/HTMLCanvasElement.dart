/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLCanvasElement extends HTMLElement {

  int get height();

  void set height(int value);

  int get width();

  void set width(int value);

  Object getContext(String contextId = null);

  String toDataURL(String type = null);
}
