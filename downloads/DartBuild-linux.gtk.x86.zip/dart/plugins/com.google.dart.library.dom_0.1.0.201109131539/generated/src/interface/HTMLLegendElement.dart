/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLLegendElement extends HTMLElement {

  String get accessKey();

  void set accessKey(String value);

  String get align();

  void set align(String value);

  HTMLFormElement get form();
}
