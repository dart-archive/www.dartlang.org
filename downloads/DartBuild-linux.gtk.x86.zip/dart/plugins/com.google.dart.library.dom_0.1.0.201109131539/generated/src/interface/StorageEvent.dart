/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface StorageEvent extends Event {

  String get key();

  String get newValue();

  String get oldValue();

  Storage get storageArea();

  String get url();

  void initStorageEvent(String typeArg = null, bool canBubbleArg = null, bool cancelableArg = null, String keyArg = null, String oldValueArg = null, String newValueArg = null, String urlArg = null, Storage storageAreaArg = null);
}
