/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface IDBKeyRange {

  IDBKey get lower();

  bool get lowerOpen();

  IDBKey get upper();

  bool get upperOpen();

  IDBKeyRange bound(IDBKey lower, IDBKey upper, bool lowerOpen = null, bool upperOpen = null);

  IDBKeyRange lowerBound(IDBKey bound, bool open = null);

  IDBKeyRange only(IDBKey value);

  IDBKeyRange upperBound(IDBKey bound, bool open = null);
}
