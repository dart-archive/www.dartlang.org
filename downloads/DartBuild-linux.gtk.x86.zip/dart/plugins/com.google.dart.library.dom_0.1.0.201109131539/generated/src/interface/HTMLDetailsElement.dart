/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLDetailsElement extends HTMLElement {

  bool get open();

  void set open(bool value);
}
