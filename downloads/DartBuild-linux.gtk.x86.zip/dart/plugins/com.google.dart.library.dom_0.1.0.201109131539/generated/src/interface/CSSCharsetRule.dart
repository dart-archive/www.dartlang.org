/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface CSSCharsetRule extends CSSRule {

  String get encoding();

  void set encoding(String value);
}
