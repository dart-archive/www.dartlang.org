/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface IDBIndex {

  String get keyPath();

  String get name();

  IDBObjectStore get objectStore();

  bool get unique();

  IDBRequest getKey(IDBKey key);

  IDBRequest openCursor(IDBKeyRange range = null, int direction = null);

  IDBRequest openKeyCursor(IDBKeyRange range = null, int direction = null);
}
