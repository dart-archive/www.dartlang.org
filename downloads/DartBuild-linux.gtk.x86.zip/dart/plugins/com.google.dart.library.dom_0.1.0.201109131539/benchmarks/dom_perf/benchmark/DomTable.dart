// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// DOMTable - a benchmark creating tables and accessing
// table elements
//
// This benchmark tests different mechanisms for creating an
// HTML table. By either creating the DOM elements
// individually or by creating an inner HTML as a string.
// The effect of forcing a layout is also measured.
// A second part of the benchmark sums the contents of all
// elements. Again in one set the benchmark is created using
// DOM functions from JavaScript, causing all nodes to be
// prewrapped, while in a second set the table is created
// using inner HTML which will wrap the elements at access.

class DomTable {
  // Size of the created tables.
  static final int MAX_ROWS = 100;
  static final int MAX_COLS = 40;

  // Helper variable to create consistent values for the table elements.
  static int elementCount;

  static HTMLElement createCell(int rowId, int colId) {
    HTMLElement cell = document.createElement('td');
    cell.id = '\$' + rowId + '\$' + colId;
    cell.textContent = elementCount.toString();
    elementCount++;
    return cell;
  }

  static HTMLElement createRow(int rowId, int cols) {
    HTMLElement row = document.createElement('tr');
    for (int i = 0; i < cols; i++) {
      row.appendChild(createCell(rowId, i));
    }
    return row;
  }

  static HTMLElement createTable(int rows, int cols) {
    HTMLElement table = document.createElement('table');
    for (int i = 0; i < rows; i++) {
      table.appendChild(createRow(i, cols));
    }
    return table;
  }

  // Functions needed to create a table by creating a big piece of HTML in a
  // single string.
  static String createCellIH(int rowId, int colId) {
    return '<td id="\$' + rowId + '\$' + colId + '">'+
        (elementCount++) +
        '</td>';
  }

  static String createRowIH(int rowId, int cols) {
    String htmlString = '<tr>';
    for (int i = 0; i < cols; i++) {
      htmlString += createCellIH(rowId, i);
    }
    return htmlString + '</tr>';
  }

  static String createTableIH(int rows, int cols) {
    String htmlString = '<table>';
    for (int i = 0; i < rows; i++) {
      htmlString += createRowIH(i, cols);
    }
    return htmlString + '</table>';
  }

  // Shared setup function for all table creation tests.
  static Object createSetup() {
    elementCount = 0;
    return document.getElementById('benchmark_content');
  }

  static HTMLElement create(HTMLElement rootElement) {
    // Create the table and add it to the rootElement
    // for the benchmark.
    rootElement.appendChild(createTable(MAX_ROWS, MAX_COLS));
    return rootElement;
  }

  static Object createLayout(HTMLElement rootElement) {
    // Create the table and add it to the rootElement
    // for the benchmark.
    rootElement.appendChild(createTable(MAX_ROWS, MAX_COLS));
    // Force a layout by requesting the height of the table.
    // The result is going to be ignored because there is not cleanup
    // function registered.
    return rootElement.scrollHeight;
  }

  static HTMLElement innerHTML(HTMLElement rootElement) {
    // Create the HTML string for the table and set it at
    // the rootElement for the benchmark.
    rootElement.innerHTML = createTableIH(MAX_ROWS, MAX_COLS);
    return rootElement;
  }

  static Object innerHTMLLayout(HTMLElement rootElement) {
    // Create the HTML string for the table and set it
    // at the rootElement for the benchmark.
    rootElement.innerHTML = createTableIH(MAX_ROWS, MAX_COLS);
    // Force a layout by requesting the height of the table.
    // The result is going to be ignored because there is
    // not cleanup function registered.
    return rootElement.scrollHeight;
  }

  static HTMLElement sumSetup() {
    // Create the table to be summed using DOM operations
    // from Dart. By doing it this way the elements are
    // all pre-wrapped.
    elementCount = 0;
    HTMLElement rootElement =
        document.getElementById('benchmark_content');
    HTMLElement table = createTable(MAX_ROWS, MAX_COLS * 5);
    rootElement.appendChild(table);
    return rootElement;
}

  static HTMLElement sumSetupIH() {
    // Create the table to be summed using InnerHTML.
    // By doing it this way the elements need to be
    // wrapped on access.
    elementCount = 0;
    HTMLElement rootElement =
        document.getElementById('benchmark_content');
    String table = createTableIH(MAX_ROWS, MAX_COLS * 5);
    rootElement.innerHTML = table;
    return rootElement;
  }

  static int sumById(ignore) {
    // Sum all elements in the table by finding each
    // element by its id.
    int sum = 0;
    int maxRows = MAX_ROWS;
    int maxCols = MAX_COLS * 5;
    for (int r = 0; r < maxRows; r++) {
      for (int c = 0; c < maxCols; c++) {
        HTMLElement cell =
            document.getElementById('\$'+r+'\$'+c);
        sum += Math.parseInt(cell.textContent);
      }
    }
    return sum;
  }

  static int sumByTagName(HTMLElement rootElement) {
    // Sum all elements in the table by getting a
    // NodeList of all "td" elements.
    int sum = 0;
    NodeList nodes = rootElement.getElementsByTagName('td');
    int length = nodes.length;
    for (int i = 0; i < length; i++) {
      HTMLElement cell = nodes[i];
      sum += Math.parseInt(cell.textContent);
    }
    return sum;
  }

  static void main() {
    elementCount = 0;

    new BenchmarkSuite('DOMTable', [
        new Benchmark('create',
                      (x) { create(x); },
                      () => createSetup()),
        new Benchmark('create and layout',
                      (x) { createLayout(x); },
                      () => createSetup()),
        new Benchmark('create with innerHTML',
                      (x) { innerHTML(x); },
                      () => createSetup()),
        new Benchmark('create and layout with innerHTML',
                      (x) { innerHTMLLayout(x); },
                      () => createSetup()),
        new Benchmark('sum elements by id',
                      (x) { sumById(x); },
                      () => sumSetup()),
        new Benchmark('sum elements by id with innerHTML',
                      (x) { sumById(x); },
                      () => sumSetupIH()),
        new Benchmark('sum elements by tagname',
                      (x) { sumByTagName(x); },
                      () => sumSetup()),
        new Benchmark('sum elements by tagname with innerHTML',
                      (x) { sumByTagName(x); },
                      () => sumSetupIH())
    ]);
  }
}
