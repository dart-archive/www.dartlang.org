// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// CreateNodes
// Test mechanisms for creating and inserting nodes into a DOM tree.
//
// There are many ways to add nodes into a DOM tree.  This test exercises
// use of:
//    - createElement()/appendChild()
//    - createDocumentFragment()
//    - innerHTML()
//    - spans

class CreateNodes {
  static final int ITERATIONS = 10000;
  static final int ITERATIONS_SLOW = 2000;

  static HTMLElement nodeProto;
  static int currentIterations;

  static HTMLElement createNode() {
    if (null == nodeProto) {
      String html = getNodeHTML();
      HTMLElement span = document.createElement('span');
      span.innerHTML = html;
      nodeProto = span.firstChild;
    }
    return nodeProto;
  }

  static String getNodeHTML() {
    return '<div style="font-style:bold">test</div>';
  }

  static void appendNodesWithDOM(node) {
    Array<HTMLElement> nodes = createNodesWithDOM(node);
    justAppendNodesWithDOM(nodes);
    forceNode();
  }

  static void justAppendNodesWithDOM(Array<HTMLElement> nodes) {
    for (int i = 0; i < ITERATIONS; i++) {
      BenchmarkSuite.benchmarkContent.appendChild(nodes[i]);
    }
  }

  static String createNodesWithHTML(String html) {
    StringBuffer allHTML = new StringBuffer();
    for (int i = 0; i < currentIterations; i++) {
      allHTML.add(html);
    }
    return allHTML.toString();
  }

  static void checkNodes() {
    final int length = BenchmarkSuite.benchmarkContent.childNodes.length;
    final int count = currentIterations;
    if (length != count) {
      throw new BenchmarkException(
          'Should have ${count} nodes, have: ${length}',
          'CreateNodes');
    }
  }

  // Ensures that the node has really been created and not just delayed.
  static void forceNode() {
    HTMLElement child =
        BenchmarkSuite.benchmarkContent.childNodes[ITERATIONS ~/ 2];
  }

  static void appendNodesWithHTML(String html) {
    String allHTML = createNodesWithHTML(html);
    BenchmarkSuite.benchmarkContent.innerHTML = allHTML;
    forceNode();
  }

  static Array<HTMLElement> createNodesWithDOM(node) {
    Array<HTMLElement> nodes =
        new Array<HTMLElement>();
    for (int i = 0; i < ITERATIONS; i++) {
      nodes.add(node.cloneNode(true));
    }
    return nodes;
  }

  static Array<HTMLElement> createNodesWithDOMSetup() {
    return createNodesWithDOM(createNode());
  }

  static HTMLElement createNodeSetup() {
    currentIterations = ITERATIONS;
    return createNode();
  }

  static Array<HTMLElement> createNodesWithHTMLUsingSpans(String html) {
    Array<HTMLElement> spans =
        new Array<HTMLElement>();
    for (int i = 0; i < currentIterations; i++) {
      HTMLElement spanNode = document.createElement('span');
      spanNode.innerHTML = html;
      spans.add(spanNode);
    }
    return spans;
  }

  static void appendNodesWithHTMLUsingSpans(String html) {
    Array<HTMLElement> spans = createNodesWithHTMLUsingSpans(html);
    HTMLElement content = BenchmarkSuite.benchmarkContent;

    for (int i = 0; i < currentIterations; i++) {
      content.appendChild(spans[i]);
    }
    forceNode();
  }

  static void appendNodesWithDOMUsingDocumentFragment(var node) {
    final fragment = createNodesWithDOMUsingDocumentFragment(node);
    BenchmarkSuite.benchmarkContent.appendChild(fragment);
    forceNode();
  }

  static void appendNodesWithDOMUsingSharedDocumentFragment(
      HTMLElement fragment) {
    BenchmarkSuite.benchmarkContent.appendChild(fragment.cloneNode(true));
    forceNode();
  }

  static Object createNodesWithDOMUsingDocumentFragment(node) {
    Array<HTMLElement> nodes = createNodesWithDOM(node);
    final fragment = document.createDocumentFragment();
    for (int i = 0; i < ITERATIONS; i++) {
      fragment.appendChild(nodes[i]);
    }
    return fragment;
  }

  static HTMLElement createSharedDocumentFragment() {
    final Array<HTMLElement> nodes = createNodesWithDOM(createNode());
    final fragment = document.createDocumentFragment();
    for (int i = 0; i < ITERATIONS; i++) {
      fragment.appendChild(nodes[i]);
    }
    return fragment;
  }

  static String createHTMLSetup() {
    currentIterations = ITERATIONS_SLOW;
    return getNodeHTML();
  }

  static String createIFramesHTML() {
    Array<String> html = new Array<String>();
    for (int i = 0; i < 100; i++) {
      html.add('<iframe src="blank.html"></iframe>');
    }
    return Strings.join(html, '');
  }

  static void appendIFramesHTML(String html) {
    BenchmarkSuite.benchmarkContent.innerHTML = html;
  }

  static Array<HTMLElement> createIFramesDOM() {
    Array<HTMLElement> nodes = new Array<HTMLElement>();
    for (int i = 0; i < 100; i++) {
      HTMLIFrameElement iframe = document.createElement('iframe');
      iframe.src = 'blank.html';
      nodes.add(iframe);
    }
    return nodes;
  }

  static void appendIFramesDOM(Array<HTMLElement> nodes) {
    final content = BenchmarkSuite.benchmarkContent;
    for (int i = 0, l = nodes.length; i < l; i++) {
      content.appendChild(nodes[i]);
    }
  }

  static void main() {
    currentIterations = ITERATIONS;

    new BenchmarkSuite('CreateNodes', [
        new Benchmark(
            'append, DOM, DocumentFragment',
            (x) { appendNodesWithDOMUsingDocumentFragment(x); },
            () => createNodeSetup(),
            (x) { checkNodes(); }),
        new Benchmark(
            'create, DOM, DocumentFragment',
            (x) { createNodesWithDOMUsingDocumentFragment(x); },
            () => createNodeSetup()),
        new Benchmark(
            'append, DOM, SharedDocumentFragment',
            (x) { appendNodesWithDOMUsingSharedDocumentFragment(x); },
            () => createSharedDocumentFragment(),
            (x) { checkNodes(); }),
        new Benchmark(
            'create, DOM',
            (x) { createNodesWithDOM(x); },
            () => createNodeSetup()),
        new Benchmark(
            'append, DOM',
            (x) { appendNodesWithDOM(x); },
            () => createNodeSetup(),
            (x) { checkNodes(); }),
        new Benchmark(
            'append, DOM, iFrame',
            (x) { appendIFramesDOM(x); },
            () => createIFramesDOM()),
        new Benchmark(
            'append, HTML',
            (x) { appendNodesWithHTML(x); },
            () => createHTMLSetup(),
            (x) { checkNodes(); }),
        new Benchmark(
            'create, HTML, Spans',
            (x) { createNodesWithHTMLUsingSpans(x); },
            () => createHTMLSetup()),
        new Benchmark(
            'append, HTML, Spans',
            (x) { appendNodesWithHTMLUsingSpans(x); },
            () => createHTMLSetup(),
            (x) { checkNodes(); }),
        new Benchmark(
            'append, HTML, iFrame',
            (x) { appendIFramesHTML(x); },
            () => createIFramesHTML())
                                               ]);
  }
}
