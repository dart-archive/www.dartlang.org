// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// GridSort
//
// This test is designed to test the performance of sorting a grid of nodes
// such as what you might use in a spreadsheet application.
class GridSort {
  // Returns an array of integers from 0 to totalCells.
  static Array<int> generateValuesArray(int totalCells) {
    Array<int> values = new Array<int>(totalCells);
    for (int i = 0; i < totalCells; i++) {
      values[i] = i;
    }
    return values;
  }

  // Creates value text nodes in a table using DOM methods.
  static void populateTableUsingDom(String tableId, int width, int height) {
    HTMLTableElement table = document.getElementById(tableId);
    Array<int> values = generateValuesArray(width * height);
    BenchUtil.shuffle(values);

    for (int i = 0; i < height; i++) {
      HTMLTableRowElement row = table.insertRow(i);
      for (int j = 0; j < width; j++) {
        HTMLTableCellElement cell = row.insertCell(j);
        String value = values[i * width + j].toString();
        cell.appendChild(document.createTextNode(value));
      }
    }
  }

  // Returns HTML string for rows/columns of table data.
  static String getTableContentHTML(int width, int height) {
    Array<int> values = generateValuesArray(width * height);
    BenchUtil.shuffle(values);

    // Fragments we will join together at the end.
    Array<String> html = new Array<String>();
    int htmlIndex  = 0;

    for (int i = 0; i < height; i++) {
      html.add('<tr>');
      for (int j = 0; j < width; j++) {
        html.add('<td>');
        String value = values[i * width + j].toString();
        html.add(value);
        html.add('</td>');
      }
      html.add('</tr>');
    }
    return Strings.join(html, '');
  }

  static void sortTableOnColumn(HTMLTableElement table, int columnIndex) {
    int numRows = table.rows.length;
    Array<SortHelper> sortHelpers = new Array<SortHelper>(numRows);
    for (int i = 0; i < numRows; i++) {
      sortHelpers[i] = new SortHelper(table.rows[i], i);
    }

    // Sort by nodeValue with original position breaking ties.
    sortHelpers.sort((SortHelper a, SortHelper b) {
        int va = Math.parseInt(a.nodes[columnIndex].nodeValue);
        int vb = Math.parseInt(b.nodes[columnIndex].nodeValue);
        int cmp = va.compareTo(vb);
        if (cmp == 0) {
          cmp = a.originalIndex.compareTo(b.originalIndex);
        }
        return cmp;
      });

    // Now place all cells in their new position.
    int numSortHelpers = sortHelpers.length;
    for (int i = 0; i < numSortHelpers; i++) {
      SortHelper helper = sortHelpers[i];
      if (i == helper.originalIndex) {
        continue; // no need to move this row.
      }
      HTMLTableRowElement row = table.rows[i];
      int columnCount = row.cells.length;
      for (int j = 0; j < columnCount; j++) {
        HTMLElement cell = row.cells[j];
        if (null != cell.firstChild) {
          // A SortHelper will still have a reference to this node, so it
          // won't get orphaned/garbage collected.
          cell.removeChild(cell.firstChild);
        }
        cell.appendChild(helper.nodes[j]);
      }
    }
  }

  static void clearExistingTable() {
    HTMLTableElement table = document.getElementById('gridsort_table');
    if (null != table) {
      // clear out existing table
      table.parentNode.removeChild(table);
    }
  }

  static Object createTableUsingDom() {
    clearExistingTable();
    HTMLTableElement table = document.createElement('table');
    table.id = 'gridsort_table';
    table.border = '1';
    document.getElementById('benchmark_content').appendChild(table);
    populateTableUsingDom('gridsort_table', 60, 60);
  }

  static Object createTableUsingInnerHtml() {
    clearExistingTable();
    String tableContent = getTableContentHTML(60, 60);
    String html = '<table id="gridsort_table" border="1">' +
        tableContent + '</table>';
    HTMLElement content = document.getElementById('benchmark_content');
    content.innerHTML = html;
  }

  static void sortTable() {
    HTMLTableElement table = document.getElementById('gridsort_table');
    sortTableOnColumn(table, 0);
  }

  static void main() {
    new BenchmarkSuite('GridSort', [
        new Benchmark('SortDomTable (60x60)',
                      (x) { sortTable(); },
                      () { createTableUsingDom(); },
                      null, false),
        new Benchmark('SortInnerHtmlTable (60x60)',
                      (x) { sortTable(); },
                      () { createTableUsingInnerHtml(); },
                      null, false)
    ]);
  }
}

// When sorting a table by a column, we create one of these for each
// cell in the column, and it keeps pointers to all the nodes in that
// row. This way we can sort an array of SortHelper objects, and then
// use the sibling node pointers to move all values in a row to their
// proper place according to the new sort order.
class SortHelper {
  Array<HTMLElement> nodes;
  int originalIndex;

  SortHelper(HTMLTableRowElement row, this.originalIndex) {
    int numCells = row.cells.length;
    nodes = new Array<HTMLElement>(numCells);

    for (int i = 0; i < numCells; i++) {
      nodes[i] = row.cells[i].firstChild;
    }
  }
}
