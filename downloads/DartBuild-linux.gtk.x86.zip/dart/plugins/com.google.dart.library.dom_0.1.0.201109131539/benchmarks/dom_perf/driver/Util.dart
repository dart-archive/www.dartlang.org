// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * This class has static fields that hold objects that this isolate
 * uses to interact with the environment.  Which objects are available
 * depend on how the isolate was started.  In the UI isolate
 * of the browser, the window object is available.
 */
class Env {

  static HTMLElement byId(String id) {
    HTMLElement elem = document.getElementById(id);
    if (elem === null) {
      log('${id} not found in ${document}');
    }
    return elem;
  }

  // Written this way due to Dartc/DartVM incompatibilities.
  static void postMessage(DOMWindow target, String data) {
    target.dynamic.postMessage(data, '*');
  }

  static void addListener(void handler(Event event)) {
    window.addEventListener("message",
                            (Event e) { handler(e); },
                            false);
  }

  static void later(void call(), int ms = 10) {
    window.setTimeout(() {
      call();
    }, ms);
  }

  static void whenLoaded(void call()) {
    if (null != document.getElementsByTagName('body')) {
      call();
    } else {
      window.addEventListener('load',
                              (e) { call(); },
                              false);
    }
  }

  static void log(String message) {
    window.console.dynamic.log(message);
  }

  // Cross-platform function to get the profiler object.
  static Profiler get profiler() {
    // TODO: support Chromium profiler eventually.
    return new Profiler();
  }
}

// A stub profiler object.
class Profiler {
  Profiler() {
  }

  start() {
  }

  stop() {
  }
}
