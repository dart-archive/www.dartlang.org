// Copyright 2011 Google Inc. All Rights Reserved.

class StringSplitTest {
  static testMain() {
    var array = "a b c".split(" ");
    Expect.equals(3, array.length);
    Expect.equals("a", array[0]);
    Expect.equals("b", array[1]);
    Expect.equals("c", array[2]);

    array = "adbdc".split("d");
    Expect.equals(3, array.length);
    Expect.equals("a", array[0]);
    Expect.equals("b", array[1]);
    Expect.equals("c", array[2]);

    array = "addbddc".split("dd");
    Expect.equals(3, array.length);
    Expect.equals("a", array[0]);
    Expect.equals("b", array[1]);
    Expect.equals("c", array[2]);

    array = "abc".split(" ");
    Expect.equals(1, array.length);
    Expect.equals("abc", array[0]);

    array = "abc".split("");
    Expect.equals(3, array.length);
    Expect.equals("a", array[0]);
    Expect.equals("b", array[1]);
    Expect.equals("c", array[2]);

    array = "   ".split(" ");
    Expect.equals(4, array.length);
    Expect.equals("", array[0]);
    Expect.equals("", array[1]);
    Expect.equals("", array[2]);
    Expect.equals("", array[3]);
  }
}

main() {
  StringSplitTest.testMain();
}
