// Copyright 2011 Google Inc. All Rights Reserved.
// Test that a final array literal is not expandable nor modifiable.

class ConstArrayLiteralTest {

  static void testMain() {
    var array = const [4, 2, 3];
    Expect.equals(3, array.length);

    var exception = null;
    try {
      array.add(4);
    } catch (UnsupportedOperationException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
    Expect.equals(3, array.length);
    exception = null;

    exception = null;
    try {
      array.addAll([4, 5]);
    } catch (UnsupportedOperationException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
    Expect.equals(3, array.length);

    exception = null;
    try {
      array[0] = 0;
    } catch (UnsupportedOperationException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
    Expect.equals(3, array.length);

    exception = null;
    try {
      array.sort((a, b) => a < b);
    } catch (UnsupportedOperationException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
    Expect.equals(3, array.length);
    Expect.equals(4, array[0]);
    Expect.equals(2, array[1]);
    Expect.equals(3, array[2]);

    exception = null;
    try {
      array.copyFrom([1], 0, 0, 1);
    } catch (UnsupportedOperationException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
    Expect.equals(3, array.length);
    Expect.equals(4, array[0]);
    Expect.equals(2, array[1]);
    Expect.equals(3, array[2]);
  }
}

main() {
  ConstArrayLiteralTest.testMain();
}
