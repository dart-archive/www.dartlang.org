// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for RegExp.hasMatch.

class RegExpHasMatchTest {
  static testMain() {
    Expect.equals(false, new RegExp("bar", "").hasMatch("foo"));
    Expect.equals(true, new RegExp("bar|foo", "").hasMatch("foo"));
    Expect.equals(true, new RegExp("o+", "").hasMatch("foo"));
  }
}

main() {
  RegExpHasMatchTest.testMain();
}
