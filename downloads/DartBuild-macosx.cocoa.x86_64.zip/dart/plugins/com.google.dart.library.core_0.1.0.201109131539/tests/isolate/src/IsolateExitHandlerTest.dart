// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for testing that the exit-handler is executed at the end.

void main() {
  IsolateExitHandlerTest.testMain();
}

class IsolateExitHandlerTest extends Isolate {
  static int counter = 0;

  IsolateExitHandlerTest() : super.heavy();

  static void testMain() {
    Isolate.setExitHandler(() {
      Expect.equals(1, counter);
    });
    new IsolateExitHandlerTest().spawn().then((SendPort p) {
      p.call("bar").receive((msg, replyTo) {
        counter++;
      });
    });
  }

  void main() {
    bool encounteredException = false;
    try {
      IsolateNatives.setExitHandler(() {
        Expect.equals(true, false);
      });
    } catch(var e) {
      encounteredException = true;
    }
    Expect.equals(true, encounteredException);

    this.port.receive((ignored, replyTo) {
      replyTo.send("foo", null);
      this.port.close();
    });
  }
}
