// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for testing that isolates are spawned.

class IsolateNegativeTest extends Isolate {
  IsolateNegativeTest() : super();

  static void testMain() {
    new IsolateNegativeTest().spawn().then(function(SendPort port) {
      port.call("foo").receive(function(message, replyTo) {
        Expect.equals(true, false);   // <=-------- Should fail here.
      });
    });
  }

  void main() {
    this.port.receive(function(ignored, replyTo) {
      replyTo.send("foo", null);
    });
  }
}

main() {
  IsolateNegativeTest.testMain();
}
