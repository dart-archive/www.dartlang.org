// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for testing isolate communication with
// simple messages.

class IsolateTest {

  static void testMain() {
    RequestReplyTest.test();
    CountTest.test();
    PromiseBasedTest.test();
    StaticStateTest.test();
  }
}


// ---------------------------------------------------------------------------
// Request-reply test.
// ---------------------------------------------------------------------------

class RequestReplyTest {

  static void test() {
    testCall();
    testSend();
    testSendSingleShot();
  }

  static void testCall() {
    new RequestReplyIsolate().spawn().then((SendPort port) {
      port.call(42).receive((message, replyTo) {
        Expect.equals(42 + 87, message);
      });
    });
  }

  static void testSend() {
    new RequestReplyIsolate().spawn().then((SendPort port) {
      ReceivePort reply = new ReceivePort();
      port.send(99, reply.toSendPort());
      reply.receive((message, replyTo) {
        Expect.equals(99 + 87, message);
        reply.close();
      });
    });
  }

  static void testSendSingleShot() {
    new RequestReplyIsolate().spawn().then((SendPort port) {
      ReceivePort reply = new ReceivePort.singleShot();
      port.send(99, reply.toSendPort());
      reply.receive((message, replyTo) {
        Expect.equals(99 + 87, message);
      });
    });
  }

}


class RequestReplyIsolate extends Isolate {

  RequestReplyIsolate() : super() { }

  void main() {
    this.port.receive((message, SendPort replyTo) {
      replyTo.send(message + 87, null);
      this.port.close();
    });
  }

}


// ---------------------------------------------------------------------------
// Simple counting test.
// ---------------------------------------------------------------------------

class CountTest {

  static int count;

  static void test() {
    print("Hello ");
    new CountIsolate().spawn().then((SendPort remote) {
      ReceivePort local = new ReceivePort();
      SendPort reply = local.toSendPort();

      local.receive((int message, SendPort replyTo) {
        if (message == -1) {
          Expect.equals(11, count);
          // Close the only ReceivePort to terminate the isolate after the
          // callback returns.
          local.close();
          println("IsolateTest exiting.");
          return;
        }
        Expect.equals((count - 1) * 2, message);
        println("IsolateTest: ", message);
        remote.send(count++, reply);
        if (count == 10) {
          remote.send(-1, reply);
        }
      });

      println("!");
      count = 0;
      remote.send(count++, reply);
    });
  }
}


class CountIsolate extends Isolate {

  CountIsolate() : super() { }

  void main() {
    print("World");
    int count = 0;

    this.port.receive((int message, SendPort replyTo) {
      println("Remote: ", message);
      if (message == -1) {
        Expect.equals(10, count);
        replyTo.send(-1, null);
        // Close the only ReceivePort to terminate the isolate after the
        // callback returns.
        this.port.close();
        println("RemoteRunner exiting.");
        return;
      }

      Expect.equals(count, message);
      count++;
      replyTo.send(message * 2, null);
    });
  }
}


// ---------------------------------------------------------------------------
// Promise-based test.
// ---------------------------------------------------------------------------

class PromiseBasedTest {

  static void test() {
    Proxy proxy = new Proxy.forIsolate(new PromiseIsolate());
    proxy.send([42]);  // Seed the isolate.
    proxy.call([87]).then((int value) {
      Expect.equals(42 + 87, value);
      return 99;
    }).then((int value) {
      Expect.equals(99, value);
    });
  }

}


class PromiseIsolate extends Isolate {

  PromiseIsolate() : super() { }

  void main() {
    int seed = 0;
    this.port.receive((var message, SendPort replyTo) {
      if (seed == 0) {
        seed = message[0];
      } else {
        Promise<int> response = new Promise<int>();
        var proxy = new Proxy.forPort(replyTo);
        proxy.send([response]);
        response.complete(seed + message[0]);
      }
    });
  }

}


// ---------------------------------------------------------------------------
// State state test.
// ---------------------------------------------------------------------------

class StaticStateTest {

  static String state;

  static void test() {
    Expect.equals(null, state);
    state = "foo";
    Expect.equals("foo", state);

    new StaticStateIsolate().spawn().then((SendPort remote) {
      remote.call("bar").receive((reply, replyTo) {
        Expect.equals("foo", state);
        Expect.equals(null, reply);

        state = "baz";
        remote.call("doh").receive((reply, replyTo) {
          Expect.equals("baz", state);
          Expect.equals("bar", reply);
        });
      });
    });
  }

}


class StaticStateIsolate extends Isolate {

  StaticStateIsolate() : super() { }

  void main() {
    Expect.equals(null, StaticStateTest.state);
    this.port.receive((var message, SendPort replyTo) {
      String old = StaticStateTest.state;
      StaticStateTest.state = message;
      replyTo.send(old, null);
    });
  }

}

main() {
  IsolateTest.testMain();
}
