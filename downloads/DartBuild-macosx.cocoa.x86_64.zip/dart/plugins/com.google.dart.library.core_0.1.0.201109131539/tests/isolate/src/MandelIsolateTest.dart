// Copyright 2011 Google Inc. All Rights Reserved.

class MandelIsolateTest {

  static final TERMINATION_MESSAGE = -1;
  static final N = 100;
  static final ISOLATES = 20;

  static void testMain() {
    final state = new MandelbrotState();
    for (int i = 0; i < Math.min(ISOLATES, N); i++) state.startClient(i);
  }

}


class MandelbrotState {

  MandelbrotState() {
    _result = new Array<Array<int>>(MandelIsolateTest.N);
    _lineProcessedBy = new Array<LineProcessorClient>(MandelIsolateTest.N);
    _sent = 0;
    _missing = MandelIsolateTest.N;
  }

  void startClient(int id) {
    assert(_sent < MandelIsolateTest.N);
    final client = new LineProcessorClient(this, id);
    client.processLine(_sent++);
  }

  void notifyProcessedLine(LineProcessorClient client, int y, Array<int> line) {
    assert(_result[y] === null);
    _result[y] = line;
    _lineProcessedBy[y] = client;

    if (_sent != MandelIsolateTest.N) {
      client.processLine(_sent++);
    } else {
      client.shutdown();
    }

    // If all lines have been computed, validate the result.
    if (--_missing == 0) _validateResult();
  }

  void _validateResult() {
    // TODO(ngeoffray): Implement this.
  }

  Array<Array<int>> _result;
  Array<LineProcessorClient> _lineProcessedBy;
  int _sent;
  int _missing;

}


class LineProcessorClient {

  LineProcessorClient(MandelbrotState this._state, int this._id) {
    _out = new LineProcessor().spawn();
  }

  void processLine(int y) {
    _out.then((SendPort p) {
      p.call(y).receive((Array<int> message, SendPort replyTo) {
        _state.notifyProcessedLine(this, y, message);
      });
    });
  }

  void shutdown() {
    _out.then((SendPort p) {
      p.send(MandelIsolateTest.TERMINATION_MESSAGE, null);
    });
  }

  MandelbrotState _state;
  int _id;
  Promise<SendPort> _out;

}


class LineProcessor extends Isolate {

  LineProcessor() : super() { }

  void main() {
    this.port.receive((message, SendPort replyTo) {
      if (message == MandelIsolateTest.TERMINATION_MESSAGE) {
        assert(replyTo == null);
        this.port.close();
      } else {
        replyTo.send(_processLine(message), null);
      }
    });
  }

  static Array<int> _processLine(int y) {
    double inverseN = 2.0 / MandelIsolateTest.N;
    double Civ = y * inverseN - 1.0;
    Array<int> result = new Array<int>(MandelIsolateTest.N);
    for (int x = 0; x < MandelIsolateTest.N; x++) {
      double Crv = x * inverseN - 1.5;

      double Zrv = Crv;
      double Ziv = Civ;

      double Trv = Crv * Crv;
      double Tiv = Civ * Civ;

      int i = 49;
      do {
        Ziv = (Zrv * Ziv) + (Zrv * Ziv) + Civ;
        Zrv = Trv - Tiv + Crv;

        Trv = Zrv * Zrv;
        Tiv = Ziv * Ziv;
      } while (((Trv + Tiv) <= 4.0) && (--i > 0));

      result[x] = i;
    }
    return result;
  }

}

main() {
  MandelIsolateTest.testMain();
}
