// Copyright 2011 Google Inc. All Rights Reserved.
// Dart core library.

// JavaScript implementation of TimeZoneImplementation.
class TimeZoneImplementation implements TimeZone {
  int get offset() {
    if (isUtc) return 0;
    throw "Unimplemented";
  }
  factory TimeZoneImplementation(Time offset) {
    if (offset.duration == 0) {
      return const TimeZoneImplementation.utc();
    } else {
      throw "Unimplemented";
    }
  }

  const TimeZoneImplementation.utc() : this.isUtc = true;
  const TimeZoneImplementation.local() : this.isUtc = false;

  bool operator ==(other) {
    if (!(other is TimeZoneImplementation)) return false;
    return isUtc == other.isUtc;
  }

  String toString() {
    if (isUtc) return "TimeZone (UTC)";
    return "TimeZone (Local)";
  }

  final bool isUtc;
}
