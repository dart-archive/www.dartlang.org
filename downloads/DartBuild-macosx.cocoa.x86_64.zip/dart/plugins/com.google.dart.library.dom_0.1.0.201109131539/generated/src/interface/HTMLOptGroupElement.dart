/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLOptGroupElement extends HTMLElement {

  bool get disabled();

  void set disabled(bool value);

  String get label();

  void set label(String value);
}
