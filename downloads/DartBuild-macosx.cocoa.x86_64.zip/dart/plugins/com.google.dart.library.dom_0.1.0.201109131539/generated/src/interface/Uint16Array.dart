/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface Uint16Array extends ArrayBufferView {

  static final int BYTES_PER_ELEMENT = 2;

  int get length();

  Uint16Array subarray(int start = null, int end = null);
}
