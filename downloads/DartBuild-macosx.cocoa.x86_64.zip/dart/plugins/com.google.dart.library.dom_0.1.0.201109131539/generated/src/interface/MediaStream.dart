/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface MediaStream {

  static final int ENDED = 2;

  static final int LIVE = 1;

  String get label();

  EventListener get onended();

  void set onended(EventListener value);

  int get readyState();

  MediaStreamTrackList get tracks();

  void addEventListener(String type, EventListener listener, bool useCapture = null);

  bool dispatchEvent(Event event);

  void removeEventListener(String type, EventListener listener, bool useCapture = null);
}
