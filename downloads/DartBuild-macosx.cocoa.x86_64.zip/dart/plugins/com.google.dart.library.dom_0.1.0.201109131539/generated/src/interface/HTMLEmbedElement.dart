/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLEmbedElement extends HTMLElement {

  String get align();

  void set align(String value);

  int get height();

  void set height(int value);

  String get name();

  void set name(String value);

  String get src();

  void set src(String value);

  String get type();

  void set type(String value);

  int get width();

  void set width(int value);
}
