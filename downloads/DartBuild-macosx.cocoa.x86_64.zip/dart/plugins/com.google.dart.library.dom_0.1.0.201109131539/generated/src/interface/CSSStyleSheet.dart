/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface CSSStyleSheet extends StyleSheet {

  CSSRuleList get cssRules();

  CSSRule get ownerRule();

  CSSRuleList get rules();

  int addRule(String selector = null, String style = null, int index = null);

  void deleteRule(int index = null);

  int insertRule(String rule = null, int index = null);

  void removeRule(int index = null);
}
