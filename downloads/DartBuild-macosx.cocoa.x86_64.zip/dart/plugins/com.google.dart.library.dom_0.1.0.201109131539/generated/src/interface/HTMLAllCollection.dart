/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLAllCollection {

  int get length();

  Node item(int index = null);

  Node namedItem(String name);

  NodeList tags(String name);
}
