/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLBRElement extends HTMLElement {

  String get clear();

  void set clear(String value);
}
