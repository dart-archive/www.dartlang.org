/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface UIEvent extends Event {

  int get charCode();

  int get detail();

  int get keyCode();

  int get layerX();

  int get layerY();

  int get pageX();

  int get pageY();

  DOMWindow get view();

  int get which();

  void initUIEvent(String type = null, bool canBubble = null, bool cancelable = null, DOMWindow view = null, int detail = null);
}
