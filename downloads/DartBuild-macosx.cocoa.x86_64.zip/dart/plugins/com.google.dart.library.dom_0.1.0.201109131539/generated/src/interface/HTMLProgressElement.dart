/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLProgressElement extends HTMLElement {

  HTMLFormElement get form();

  NodeList get labels();

  num get max();

  void set max(num value);

  num get position();

  num get value();

  void set value(num value);
}
