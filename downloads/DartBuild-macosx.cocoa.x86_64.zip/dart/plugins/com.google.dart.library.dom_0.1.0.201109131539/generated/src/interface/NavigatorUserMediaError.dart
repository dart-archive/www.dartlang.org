/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface NavigatorUserMediaError {

  static final int PERMISSION_DENIED = 1;

  int get code();
}
