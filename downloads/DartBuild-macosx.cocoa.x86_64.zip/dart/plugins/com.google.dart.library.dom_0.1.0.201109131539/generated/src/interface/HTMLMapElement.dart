/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLMapElement extends HTMLElement {

  HTMLCollection get areas();

  String get name();

  void set name(String value);
}
