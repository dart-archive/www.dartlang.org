/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DOMParser {

  Document parseFromString(String str = null, String contentType = null);
}
