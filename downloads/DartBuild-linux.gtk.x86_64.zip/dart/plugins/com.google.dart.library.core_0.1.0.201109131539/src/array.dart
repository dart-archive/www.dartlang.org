// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * An [Array] is an indexable collection with a length. It can be of
 * fixed size or extendable.
 */
interface Array<E> extends Collection<E> factory ArrayFactory {

  /**
   * Creates an array of the given [length].
   */
  Array(int length = null);

  /**
   * Creates an array with the elements of [other]. The order in
   * the array will be the order provided by the iterator of [other].
   */
  Array.from(Iterable<E> other);

  /**
   * Creates an array which is a subcopy of [other], starting at
   * [startIndex] (inclusive) and ending at [endIndex] (exclusive). If
   * [startIndex] is negative, it has the same effect as if it were
   * zero. If [endIndex] is greather than the length, it has the same
   * effect as if it were [:other.length:]. If [:startIndex > endIndex:],
   * the created array is of [length] 0.
   */
  Array.fromArray(Array<E> other, int startIndex, int endIndex);

  /**
   * Returns the element at the given [index] in the array or throws
   * an [IndexOutOfRangeException] if [index] is out of bounds.
   */
  E operator [](int index);

  /**
   * Sets the entry at the given [index] in the array to [value].
   * Throws an [IndexOutOfRangeException] if [index] is out of bounds.
   */
  void operator []=(int index, E value);

  /**
   * Changes the length of the array. If [newLength] is greater than
   * the current [length], entries are initialized to [:null:]. Throws a
   * [UnsupportedOperationException] if the array is not extendable.
   */
  void set length(int newLength);

  /**
   * Adds [value] at the end of the array, extending the length by
   * one. Throws a [UnsupportedOperationException] if the array is not
   * extendable.
   */
  void add(E value);

  /**
   * Adds [value] at the end of the array, extending the length by
   * one. Throws a [UnsupportedOperationException] if the array is not
   * extendable.
   */
  void addLast(E value);

  /**
   * Appends all elements of the [collection] to the end of array.
   * Extends the length of the array by the length of [collection].
   * Throws a [UnsupportedOperationException] if the array is not
   * extendable.
   */
  void addAll(Collection<E> collection);

  /**
   * Sorts the array according to the order specified by the comparator.
   * The order specified by the comparator must be reflexive,
   * anti-symmetric, and transitive.
   *
   * The comparator function [compare] must take two arguments [a] and [b]
   * and return
   *
   *   an integer strictly less than 0 if a < b,
   *   0 if a = b, and
   *   an integer strictly greater than 0 if a > b.
   */
  void sort(int compare(E a, E b));

  /**
   * Copies [count] elements from the [src] array starting at index
   * [srcStart] to this array starting at index [dstStart].
   *
   * The type of [src] is Array<Object> because one must be able to
   * give an Array<Object> only containing eg. String objects and copy
   * its elements into an Array<String>.
   */
  void copyFrom(Array<Object> src, int srcStart, int dstStart, int count);

  /**
   * Returns the first index of [element] in this array. Searches this
   * array from index [startIndex] to the length of the array. Returns
   * -1 if [element] is not found.
   */
  int indexOf(E element, int startIndex);

  /**
   * Returns the last index of [element] in this array. Searches this
   * array from index [startIndex] to 0. Returns -1 if [element] is
   * not found.
   */
  int lastIndexOf(E element, int startIndex);

  /**
   * Removes all elements in the array. The length of the array
   * becomes zero. Throws a [UnsupportedOperationException] if
   * the array is not extendable.
   */
  void clear();

  /**
   * Pops and returns the last element of the array.
   * Throws a [UnsupportedOperationException] if the length of the
   * array cannot be changed.
   */
  E removeLast();

  /**
   * Returns the last element of the array, or throws an out of bounds
   * exception if the array is empty.
   */
  E last();
}
