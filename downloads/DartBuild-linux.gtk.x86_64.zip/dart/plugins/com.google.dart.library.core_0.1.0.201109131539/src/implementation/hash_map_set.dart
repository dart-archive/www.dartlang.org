// Copyright 2011 Google Inc. All Rights Reserved.

// Hash map implementation with open addressing and quadratic probing.
class HashMap<K extends Hashable, V> implements Map<K, V> {

  // The [keys_] array contains the keys inserted in the map.
  // The [keys_] array must be a raw array because it
  // will contain both elements of type K, and the [deletedKey_] of type
  // Object.
  // The alternative of declaring the [keys_] array as of type Object
  // does not work, because the HashSetIterator constructor would fail:
  //  HashSetIterator(HashSet<E> set_)
  //    : nextValidIndex_ = -1,
  //      entries_ = set_.backingMap_.keys_ {
  //    advance_();
  //  }
  // With K being type int, for example, it would fail because
  // ObjectArray<Object> is not assignable to type Array<int> of entries_.
  Array keys_;

  // The values_ inserted in the map. For a filled entry index in this
  // array, there is always the corresponding key in the [keys_] array
  // at the same entry index.
  Array<V> values_;

  // The load limit is the number of entries we allow until we double
  // the size of the arrays.
  int loadLimit_;

  // The current number of entries in the map. Will never be greater
  // than [loadLimit_].
  int numberOfEntries_;

  // The current number of deleted entries in the map.
  int numberOfDeleted_;

  // The sentinel when a key is deleted from the map. We cannot use static
  // const here because we would need to allocate a "const Object()" which
  // would end up canonicalized and then we cannot distinguish the deleted
  // key from the canonicalized Object().
  static Object deletedKey_;

  // The initial capacity of a hash map.
  static final int initialCapacity_ = 8;  // must be power of 2

  HashMap() {
    if (deletedKey_ === null) {
      deletedKey_ = new Object();
    }
    numberOfEntries_ = 0;
    numberOfDeleted_ = 0;
    loadLimit_ = computeLoadLimit_(initialCapacity_);
    keys_ = new Array(initialCapacity_);
    values_ = new Array<V>(initialCapacity_);
  }

  // TODO: Add a constructor with an initial capacity. This could be used here
  // since we know how many elements will need to be added.
  factory HashMap.fromLiteral(Object ... elements) {
    var map = new HashMap();
    var len = elements.length;
    for (int i = 1; i < len; i += 2) {
      var key = elements[i-1];
      var value = elements[i];
      map[key] = value;
    }
    return map;
  }

  static int computeLoadLimit_(int capacity) {
    return (capacity * 3) ~/ 4;
  }

  static int firstProbe_(int hashCode, int length) {
    return hashCode & (length - 1);
  }

  static int nextProbe_(int currentProbe, int numberOfProbes, int length) {
    return (currentProbe + numberOfProbes) & (length - 1);
  }

  int probeForAdding_(K key) {
    int hash = firstProbe_(key.hashCode(), keys_.length);
    int numberOfProbes = 1;
    int initialHash = hash;
    // insertionIndex points to a slot where a key was deleted.
    int insertionIndex = -1;
    while (true) {
      Object existingKey = keys_[hash];
      if (existingKey === null) {
        // We are sure the key is not already in the set.
        // If the current slot is empty and we didn't find any
        // insertion slot before, return this slot.
        if (insertionIndex < 0) return hash;
        // If we did find an insertion slot before, return it.
        return insertionIndex;
      } else if (existingKey == key) {
        // The key is already in the map. Return its slot.
        return hash;
      } else if ((insertionIndex < 0) && (deletedKey_ === existingKey)) {
        // The slot contains a deleted element. Because previous calls to this
        // method may not have had this slot deleted, we must continue iterate
        // to find if there is a slot with the given key.
        insertionIndex = hash;
      }

      // We did not find an insertion slot. Look at the next one.
      hash = nextProbe_(hash, numberOfProbes++, keys_.length);
      // ensureCapacity_ has guaranteed the following cannot happen.
      // assert(hash != initialHash);
    }
  }

  int probeForLookup_(K key) {
    int hash = firstProbe_(key.hashCode(), keys_.length);
    int numberOfProbes = 1;
    int initialHash = hash;
    while (true) {
      Object existingKey = keys_[hash];
      // If the slot does not contain anything (in particular, it does not
      // contain a deleted key), we know the key is not in the map.
      if (existingKey === null) return -1;
      // The key is in the map, return its index.
      if (existingKey == key) return hash;
      // Go to the next probe.
      hash = nextProbe_(hash, numberOfProbes++, keys_.length);
      // ensureCapacity_ has guaranteed the following cannot happen.
      // assert(hash != initialHash);
    }
  }

  void ensureCapacity_() {
    int newNumberOfEntries = numberOfEntries_ + 1;
    // Test if adding an element will reach the load limit.
    if (newNumberOfEntries >= loadLimit_) {
      grow_(keys_.length * 2);
      return;
    }

    // Make sure that we don't have poor performance when a map
    // contains lots of deleted entries: we grow_ if
    // there are more deleted entried than free entries.
    int capacity = keys_.length;
    int numberOfFreeOrDeleted = capacity - newNumberOfEntries;
    int numberOfFree = numberOfFreeOrDeleted - numberOfDeleted_;
    // assert(numberOfFree > 0);
    if (numberOfDeleted_ > numberOfFree) {
      grow_(keys_.length);
    }
  }

  static bool isPowerOfTwo_(int x) {
    return ((x & (x - 1)) == 0);
  }

  void grow_(int newCapacity) {
    assert(isPowerOfTwo_(newCapacity));
    int capacity = keys_.length;
    loadLimit_ = computeLoadLimit_(newCapacity);
    Array oldKeys = keys_;
    Array<V> oldValues = values_;
    keys_ = new Array(newCapacity);
    values_ = new Array<V>(newCapacity);
    for (int i = 0; i < capacity; i++) {
      Object key = oldKeys[i];
      // If there is no key, we don't need to deal with the current slot.
      if (key === null || key === deletedKey_) {
        continue;
      }
      V value = oldValues[i];
      // Insert the {key, value} pair in their new slot.
      int newIndex = probeForAdding_(key);
      keys_[newIndex] = key;
      values_[newIndex] = value;
    }
    numberOfDeleted_ = 0;
  }

  void clear() {
    numberOfEntries_ = 0;
    numberOfDeleted_ = 0;
    int length = keys_.length;
    for (int i = 0; i < length; i++) {
      keys_[i] = null;
      values_[i] = null;
    }
  }

  void operator []=(K key, V value) {
    ensureCapacity_();
    int index = probeForAdding_(key);
    if ((keys_[index] === null) || (keys_[index] === deletedKey_)) {
      numberOfEntries_++;
    }
    keys_[index] = key;
    values_[index] = value;
  }

  V operator [](K key) {
    int index = probeForLookup_(key);
    if (index < 0) return null;
    return values_[index];
  }

  V putIfAbsent(K key, V ifAbsent()) {
    int index = probeForLookup_(key);
    if (index >=0) return values_[index];

    V value = ifAbsent();
    this[key] = value;
    return value;
  }

  V remove(K key) {
    int index = probeForLookup_(key);
    if (index >= 0) {
      numberOfEntries_--;
      V value = values_[index];
      values_[index] = null;
      // Set the key to the sentinel to not break the probing chain.
      keys_[index] = deletedKey_;
      numberOfDeleted_++;
      return value;
    }
    return null;
  }

  bool isEmpty() {
    return numberOfEntries_ == 0;
  }

  int get length() {
    return numberOfEntries_;
  }

  void forEach(void f(K key, V value)) {
    int length = keys_.length;
    for (int i = 0; i < length; i++) {
      if ((keys_[i] !== null) && (keys_[i] !== deletedKey_)) {
        f(keys_[i], values_[i]);
      }
    }
  }


  Collection<K> getKeys() {
    Array<K> array = new Array<K>(length);
    int i = 0;
    forEach(void _(K key, V value) {
      array[i++] = key;
    });
    return array;
  }

  Collection<V> getValues() {
    Array<V> array = new Array<V>(length);
    int i = 0;
    forEach(void _(K key, V value) {
      array[i++] = value;
    });
    return array;
  }

  bool containsKey(K key) {
    return (probeForLookup_(key) != -1);
  }

  bool containsValue(V value) {
    int length = values_.length;
    for (int i = 0; i < length; i++) {
      if ((keys_[i] !== null) && (keys_[i] !== deletedKey_)) {
        if (values_[i] == value) return true;
      }
    }
    return false;
  }
}

class HashSet<E extends Hashable> implements Set<E> {

  HashSet() {
    backingMap_ = new HashMap<E, E>();
  }

  // TODO(ahe): Bug 5257789.
  factory HashSet/* <E> */.from(Iterable/* <E> */ other) {
    Set/* <E> */ set = new HashSet/* <E> */();
    for (final e in other) {
      set.add(e);
    }
    return set;
  }

  void clear() {
    backingMap_.clear();
  }

  void add(E value) {
    backingMap_[value] = value;
  }

  bool contains(E value) {
    return backingMap_.containsKey(value);
  }

  bool remove(E value) {
    if (!backingMap_.containsKey(value)) return false;
    backingMap_.remove(value);
    return true;
  }

  void addAll(Collection<E> collection) {
    collection.forEach(void _(E value) {
      add(value);
    });
  }

  Set<E> getIntersectionWith(Collection<E> collection) {
    Set<E> result = new Set<E>();
    collection.forEach(void _(E value) {
      if (contains(value)) result.add(value);
    });
    return result;
  }

  bool isSubsetOf(Collection<E> other) {
    return new Set<E>.from(other).containsAll(this);
  }

  void removeAll(Collection<E> collection) {
    collection.forEach(void _(E value) {
      remove(value);
    });
  }

  bool containsAll(Collection<E> collection) {
    return collection.every(bool _(E value) {
      return contains(value);
    });
  }

  void forEach(void f(E element)) {
    backingMap_.forEach(void _(E key, E value) {
      f(key);
    });
  }

  Set<E> filter(bool f(E element)) {
    Set<E> result = new Set<E>();
    backingMap_.forEach(void _(E key, E value) {
      if (f(key)) result.add(key);
    });
    return result;
  }

  bool every(bool f(E element)) {
    Collection<E> keys = backingMap_.getKeys();
    return keys.every(f);
  }

  bool some(bool f(E element)) {
    Collection<E> keys = backingMap_.getKeys();
    return keys.some(f);
  }

  Set<E> intersection(Collection<E> other) {
    throw "Set.intersection unimplemented";
  }

  bool isEmpty() {
    return backingMap_.isEmpty();
  }

  int get length() {
    return backingMap_.length;
  }

  Iterator<E> iterator() {
    return new HashSetIterator<E>(this);
  }

  // The map backing this set. The associations in this map are all
  // of the form element -> element. If a value is not in the map,
  // then it is not in the set.
  HashMap<E, E> backingMap_;
}

class HashSetIterator<E> implements Iterator<E> {

  // TODO(4504458): Replace set_ with set.
  HashSetIterator(HashSet<E> set_)
    : nextValidIndex_ = -1,
      entries_ = set_.backingMap_.keys_ {
    advance_();
  }

  bool hasNext() {
    if (nextValidIndex_ >= entries_.length) return false;
    if (entries_[nextValidIndex_] === HashMap.deletedKey_) {
      // This happens in case the set was modified in the meantime.
      // A modification on the set may make this iterator misbehave,
      // but we should never return the sentinel.
      advance_();
    }
    return nextValidIndex_ < entries_.length;
  }

  E next() {
    if (!hasNext()) {
      throw const NoMoreElementsException();
    }
    E res = entries_[nextValidIndex_];
    advance_();
    return res;
  }

  void advance_() {
    int length = entries_.length;
    var entry;
    Object deletedKey = HashMap.deletedKey_;
    do {
      if (++nextValidIndex_ >= length) break;
      entry = entries_[nextValidIndex_];
    } while ((entry === null) || (entry === deletedKey));
  }

  // The entries in the set. May contain null or the sentinel value.
  Array<E> entries_;

  // The next valid index in [entries_] or the length of [entries_].
  // If it is the length of [entries_], calling [hasNext] on the
  // iterator will return false.
  int nextValidIndex_;
}
