// Copyright 2011 Google Inc. All Rights Reserved.
// Dart core library.

interface num extends Comparable, Hashable {
  // Arithmetic operations.
  num operator +(num other);
  num operator -(num other);
  num operator *(num other);
  num operator %(num other);
  num operator /(num other);
  // Truncating division.
  num operator ~/(num other);
  // The unary '-' operator.
  num operator negate();
  num remainder(num other);

  // Relational operations.
  bool operator <(num other);
  bool operator <=(num other);
  bool operator >(num other);
  bool operator >=(num other);

  // Predicates.
  bool isEven();
  bool isOdd();
  bool isNaN();
  bool isNegative();
  bool isInfinite();

  num abs();
  num round();
  num floor();
  num ceil();
  num truncate();

  int toInt();
  double toDouble();

  String toStringAsFixed(int fractionDigits);
  String toStringAsExponential(int fractionDigits);
  String toStringAsPrecision(int precision);
  String toRadixString(int radix);
}
