// Copyright 2011 Google Inc. All Rights Reserved.

class Strings {

  /**
   * Factory implementation of String.fromCharCodes:
   * Allocates a new String for the specified [charCodes].
   */
  factory String.fromCharCodes(Array<int> charCodes) {
    return StringBase.createFromCharCodes(charCodes);
  }

  /**
   * Joins all the given strings to create a new string.
   */
  static String join(Array<String> strings, String separator) {
    return StringBase.join(strings, separator);
  }

  /**
   * Concatenates all the given strings to create a new string.
   */
  static String concatAll(Array<String> strings) {
    return StringBase.concatAll(strings);
  }
}
