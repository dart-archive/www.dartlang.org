// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * A [DoubleLinkedList] boxes its elements into [DoubleLinkedListEntry]
 * objects. One can iterate over the entries by using [forEachEntry]
 * or manipulating the individual entries.
 */
interface DoubleLinkedList<E> extends List<E>
    factory DoubleLinkedListImplementation<E> {

  DoubleLinkedList();

  /**
   * Creates a [DoubleLinkedList] that contains all elements of
   * [other].
   */
  DoubleLinkedList.from(Iterable<E> other);

  /**
   * Applies the function f to each entry in the list.
   */
  void forEachEntry(void f(DoubleLinkedListEntry<E> entry));

  /**
   * Returns the last entry in the list, or null if the list has no
   * entry.
   */
  DoubleLinkedListEntry<E> lastEntry();

  /**
   * Returns the first entry in the list, or null if the list has no
   * entry.
   */
  DoubleLinkedListEntry<E> firstEntry();

  /**
   * Because elements can be added in the list by using methods in
   * [List], and [DoubleLinkedListEntry],
   * this class does not keep track of the number of elements
   * inserted. Therefore the [length] getter on [DoubleLinkedList]
   * objects is O(n).
   */
  int get length();
}

/**
 * An entry in a double linked list. An entry boxes an element and has access
 * to the next and previous entry in the list.
 */
interface DoubleLinkedListEntry<E> extends ListEntry<E> {
  /**
   * Returns the next list entry pointed to by this entry.
   */
  DoubleLinkedListEntry<E> nextEntry();

  /**
   * Returns the previous list entry pointed to by this entry.
   */
  DoubleLinkedListEntry<E> previousEntry();

  /**
   * Prepends an element to this list entry.
   */
  void prepend(E element);

  /**
   * Appends an element to this list entry.
   */
  void append(E element);

  /**
   * Removes the entry from its list.
   */
  E remove();
}
