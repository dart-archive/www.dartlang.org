// Copyright 2011 Google Inc. All Rights Reserved.

function native_ArrayFactory__new(typeToken, length) {
  // TODO(floitsch): use type information.
  return new Array(length);
}

function native_ObjectArray__indexOperator(index) {
  return this[index];
}

function native_ObjectArray__indexAssignOperator(index, value) {
  this[index] = value;
}

function native_ObjectArray_get$length() {
  return this.length;
}

function native_ObjectArray__setLength(length) {
  this.length = length;
}

function native_ObjectArray__add(element) {
  this.push(element);
}

function $inlineArrayIndexCheck(array, index) {
  if (index >= 0 && index < array.length) {
    return index;
  }
  native__ArrayJsUtil__throwIndexOutOfRangeException(index);
}
