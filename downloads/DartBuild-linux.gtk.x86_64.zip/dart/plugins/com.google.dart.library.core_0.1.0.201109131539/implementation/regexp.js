// Copyright 2011 Google Inc. All Rights Reserved.

function native_JSSyntaxRegExp_firstMatch(str) {
  var m = $DartRegExpToJSRegExp(this).exec(str);
  if (m != null) {
    var match = native_JSSyntaxMatch__new(this, str);
    match.match_ = m;
    return match;
  }
  return $Dart$Null;
}

function native_JSSyntaxRegExp_hasMatch(str) {
  return $DartRegExpToJSRegExp(this).test(str);
}

function native_JSSyntaxRegExp_stringMatch(str) {
  var m = $DartRegExpToJSRegExp(this).exec(str);
  return (m != null ? m[0] : $Dart$Null);
}

function native_JSSyntaxMatch_group(nb) {
  return this.match_[nb];
}

function native__LazyAllMatchesIterator__jsInit(regExp) {
  this.re = $DartRegExpToJSRegExp(regExp);
}

// The given RegExp is only used to initialize a new Match. We use the
// cached JS regexp to compute the next match.
function native__LazyAllMatchesIterator__computeNextMatch(regExp, str) {
  var re = this.re;
  if (re === null) return $Dart$Null;
  var m = re.exec(str);
  if (m == null) {
    this.re = null;
    return $Dart$Null;
  }
  var match = native_JSSyntaxMatch__new(regExp, str);
  match.match_ = m;
  if (!re.global) {
    this.re = null;
  }
  return match;
}

function $DartRegExpToJSRegExp(exp) {
  return new RegExp(native_JSSyntaxRegExp__pattern(exp),
                    native_JSSyntaxRegExp__flags(exp));
}

function $DartRegExpToJSRegExpWithFlags(exp, flags) {
  return new RegExp(native_JSSyntaxRegExp__pattern(exp),
                    native_JSSyntaxRegExp__flags(exp) + flags);
}
