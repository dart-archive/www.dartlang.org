// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for RegExp.firstMatch.

class RegExpFirstMatchTest {
  static testMain() {
    Expect.equals('cat', new RegExp("(\\w+)", "").firstMatch("cat dog")[0]);
    Expect.equals(null, new RegExp("foo", "").firstMatch("bar"));
  }
}

main() {
  RegExpFirstMatchTest.testMain();
}
