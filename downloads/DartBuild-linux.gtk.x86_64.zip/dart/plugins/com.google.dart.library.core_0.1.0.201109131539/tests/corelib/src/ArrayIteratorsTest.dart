// Copyright 2011 Google Inc. All Rights Reserved.

class ArrayIteratorsTest {
  static void checkArrayIterator(Array a) {
    Iterator it = a.iterator();
    Expect.equals(false, it.hasNext() == a.isEmpty());
    for (int i = 0; i < a.length; i++) {
      Expect.equals(true, it.hasNext());
      var elem = it.next();
    }
    Expect.equals(false, it.hasNext());
    bool exceptionCaught = false;
    try {
     var eleme = it.next();
    } catch (NoMoreElementsException e) {
     exceptionCaught = true;
    }
    Expect.equals(true, exceptionCaught);
  }

  static testMain() {
    checkArrayIterator([]);
    checkArrayIterator([1, 2]);
    checkArrayIterator(new Array(0));
    checkArrayIterator(new Array(10));
    checkArrayIterator(new Array());
    Array g = new Array();
    g.addAll([1, 2]);
    checkArrayIterator(g);

    Iterator it = g.iterator();
    Expect.equals(true, it.hasNext());
    g.removeLast();
    Expect.equals(true, it.hasNext());
    g.removeLast();
    Expect.equals(false, it.hasNext());

    g.addAll([10, 20]);
    int sum = 0;
    for (var elem in g) {
      sum += elem;
      // Iterator must realize that g has no more elements.
      g.removeLast();
    }
    Expect.equals(10, sum);
  }
}

main() {
  ArrayIteratorsTest.testMain();
}
