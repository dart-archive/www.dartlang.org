// Copyright 2011 Google Inc. All Rights Reserved.

class StringFromArrayTest {
  static testMain() {
    Expect.equals("", new String.fromCharCodes(new Array(0)));
    Expect.equals("", new String.fromCharCodes([]));
    Expect.equals("", new String.fromCharCodes(const []));
    Expect.equals("AB", new String.fromCharCodes([65, 66]));
    Expect.equals("AB", new String.fromCharCodes(const [65, 66]));
    Expect.equals("", new String.fromCharCodes(new Array()));
    var a = new Array();
    a.add(65);
    a.add(66);
    Expect.equals("AB", new String.fromCharCodes(a));
  }
}

main() {
  StringFromArrayTest.testMain();
}
