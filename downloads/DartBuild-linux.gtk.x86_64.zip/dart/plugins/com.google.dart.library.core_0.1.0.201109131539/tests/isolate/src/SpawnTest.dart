// Copyright 2011 Google Inc. All Rights Reserved.

class SpawnTest {

  static void testMain() {
    spawnIsolate();
  }

  static void spawnIsolate() {
    SpawnedIsolate isolate = new SpawnedIsolate();
    isolate.spawn().then((SendPort port) {
      port.call(42).receive((message, replyTo) {
        Expect.equals(42, message);
      });
    });
  }
}

class SpawnedIsolate extends Isolate {

  SpawnedIsolate() : super() { }

  void main() {
    this.port.receive((message, SendPort replyTo) {
      Expect.equals(42, message);
      replyTo.send(42, null);
      this.port.close();
    });
  }

}

main() {
  SpawnTest.testMain();
}
