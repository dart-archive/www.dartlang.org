// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for testing that exceptions in other isolates bring down
// the program.

class Isolate2NegativeTest extends Isolate {
  Isolate2NegativeTest() : super();

  static void testMain() {
    new Isolate2NegativeTest().spawn();
  }

  void main() {
    throw "foo";
  }
}

main() {
  Isolate2NegativeTest.testMain();
}
