// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for testing that the exit-handler is executed.

void main() {
  IsolateExitHandlerNegativeTest.testMain();
}

class IsolateExitHandlerNegativeTest extends Isolate {
  IsolateExitHandlerNegativeTest() : super.heavy();

  static void testMain() {
    Isolate.setExitHandler(function() {
      Expect.equals(true, false);   // <=-------- Should fail here.
    });
    new IsolateExitHandlerNegativeTest().spawn();
  }

  void main() {
    this.port.close();
  }
}
