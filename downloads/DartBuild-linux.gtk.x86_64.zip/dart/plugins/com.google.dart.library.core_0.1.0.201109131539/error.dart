// Copyright 2011 Google Inc. All Rights Reserved.
// Exceptions thrown by the VM.

class AssertionError {
  const AssertionError();
}

class TypeError extends AssertionError {
  const TypeError() : super();
}

class FallThroughError {
  const FallThroughError() : super();
}

