/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface SQLStatementCallback {

  bool handleEvent(SQLTransaction transaction, SQLResultSet resultSet);
}
