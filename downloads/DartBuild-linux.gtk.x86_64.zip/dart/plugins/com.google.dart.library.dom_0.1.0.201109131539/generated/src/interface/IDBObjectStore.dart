/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface IDBObjectStore {

  String get keyPath();

  String get name();

  IDBRequest add(String value, IDBKey key = null);

  IDBRequest clear();

  IDBIndex createIndex(String name, String keyPath);

  IDBRequest delete(IDBKey key);

  void deleteIndex(String name);

  IDBIndex index(String name);

  IDBRequest openCursor(IDBKeyRange range = null, int direction = null);

  IDBRequest put(String value, IDBKey key = null);
}
