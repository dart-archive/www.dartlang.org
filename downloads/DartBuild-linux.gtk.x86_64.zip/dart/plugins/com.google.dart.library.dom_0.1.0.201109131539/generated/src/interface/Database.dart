/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface Database {

  String get version();

  void changeVersion(String oldVersion, String newVersion, SQLTransactionCallback callback = null, SQLTransactionErrorCallback errorCallback = null, VoidCallback successCallback = null);

  void readTransaction(SQLTransactionCallback callback, SQLTransactionErrorCallback errorCallback = null, VoidCallback successCallback = null);

  void transaction(SQLTransactionCallback callback, SQLTransactionErrorCallback errorCallback = null, VoidCallback successCallback = null);
}
