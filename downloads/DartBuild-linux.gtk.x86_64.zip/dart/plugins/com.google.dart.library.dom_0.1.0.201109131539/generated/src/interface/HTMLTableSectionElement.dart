/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLTableSectionElement extends HTMLElement {

  String get align();

  void set align(String value);

  String get ch();

  void set ch(String value);

  String get chOff();

  void set chOff(String value);

  HTMLCollection get rows();

  String get vAlign();

  void set vAlign(String value);

  void deleteRow(int index = null);

  HTMLElement insertRow(int index = null);
}
