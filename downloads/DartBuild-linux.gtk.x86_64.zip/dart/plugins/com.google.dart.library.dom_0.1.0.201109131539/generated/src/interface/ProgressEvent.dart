/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface ProgressEvent extends Event {

  bool get lengthComputable();

  int get loaded();

  int get total();

  void initProgressEvent(String type_OR_typeArg = null, bool bubbles_OR_canBubbleArg = null, bool cancelable_OR_cancelableArg = null, bool lengthComputable_OR_lengthComputableArg = null, int loaded_OR_loadedArg = null, int total = null);
}
