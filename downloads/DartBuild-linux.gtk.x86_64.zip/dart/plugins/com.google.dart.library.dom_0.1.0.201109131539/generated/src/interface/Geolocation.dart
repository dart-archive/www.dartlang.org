/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface Geolocation {

  void clearWatch(int watchId);

  void getCurrentPosition(PositionCallback successCallback, PositionErrorCallback errorCallback = null);

  int watchPosition(PositionCallback successCallback, PositionErrorCallback errorCallback = null);
}
