/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface History {

  int get length();

  void back();

  void forward();

  void go(int delta = null);

  void pushState(Object data, String title, String url = null);

  void replaceState(Object data, String title, String url = null);
}
