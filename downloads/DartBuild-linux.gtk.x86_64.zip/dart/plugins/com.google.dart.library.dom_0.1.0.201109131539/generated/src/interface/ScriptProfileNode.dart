/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface ScriptProfileNode {

  int get callUID();

  String get functionName();

  int get lineNumber();

  int get numberOfCalls();

  num get selfTime();

  num get totalTime();

  String get url();

  bool get visible();
}
