/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface MessageEvent extends Event {

  String get data();

  String get lastEventId();

  MessagePort get messagePort();

  String get origin();

  DOMWindow get source();

  void initMessageEvent(String typeArg = null, bool canBubbleArg = null, bool cancelableArg = null, String dataArg = null, String originArg = null, String lastEventIdArg = null, DOMWindow sourceArg = null, MessagePort messagePort = null);
}
