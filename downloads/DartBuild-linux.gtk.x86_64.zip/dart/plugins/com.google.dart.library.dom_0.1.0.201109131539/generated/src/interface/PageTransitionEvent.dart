/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface PageTransitionEvent extends Event {

  bool get persisted();

  void initPageTransitionEvent(String typeArg = null, bool canBubbleArg = null, bool cancelableArg = null, bool persisted = null);
}
