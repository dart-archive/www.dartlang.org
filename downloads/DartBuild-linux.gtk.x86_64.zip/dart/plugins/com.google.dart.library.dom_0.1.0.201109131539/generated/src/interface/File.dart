/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface File extends Blob {

  String get fileName();

  int get fileSize();

  DateTime get lastModifiedDate();

  String get name();
}
