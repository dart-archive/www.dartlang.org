/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface EntryArraySync {

  int get length();

  EntrySync item(int index);
}
