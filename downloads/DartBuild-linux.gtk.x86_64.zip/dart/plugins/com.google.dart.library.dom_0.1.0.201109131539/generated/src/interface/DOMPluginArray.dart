/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DOMPluginArray {

  int get length();

  DOMPlugin item(int index = null);

  DOMPlugin namedItem(String name = null);

  void refresh(bool reload = null);
}
