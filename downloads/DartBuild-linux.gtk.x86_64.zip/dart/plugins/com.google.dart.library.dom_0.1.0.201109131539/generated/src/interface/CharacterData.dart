/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface CharacterData extends Node {

  String get data();

  void set data(String value);

  int get length();

  void appendData(String data = null);

  void deleteData(int offset = null, int count = null);

  void insertData(int offset = null, String data = null);

  void replaceData(int offset = null, int count_OR_length = null, String data = null);

  String substringData(int offset = null, int count = null);
}
