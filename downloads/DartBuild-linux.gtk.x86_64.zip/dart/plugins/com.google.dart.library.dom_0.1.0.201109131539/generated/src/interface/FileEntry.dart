/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface FileEntry extends Entry {

  void createWriter(FileWriterCallback successCallback, ErrorCallback errorCallback = null);

  void file(FileCallback successCallback, ErrorCallback errorCallback = null);
}
