/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface BeforeLoadEvent extends Event {

  String get url();

  void initBeforeLoadEvent(String type = null, bool canBubble = null, bool cancelable = null, String url = null);
}
