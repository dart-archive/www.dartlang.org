// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//
// Tests cloning and appending small and medium DOM trees.

class CloneNodesTest {
  static final String STYLE_APPEND = 'append';
  static final String STYLE_CLONE = 'clone';

  final String _size;
  final String _style;

  HTMLElement _domTree;

  CloneNodesTest(this._size, this._style) {
  }

  String get name() {
    return '${_size}, ${_style}';
  }

  setup() {
    _domTree = getDOMTree();
    if (_style == STYLE_APPEND) {
      _domTree = _domTree.cloneNode(true);
    }
  }

  void test() {
    final int kIterations = 10;
    if (_style == STYLE_CLONE) {
      for (int iterations = 0; iterations < kIterations; iterations++) {
        _domTree.cloneNode(true);
      }
    } else {
      for (int iterations = 0; iterations < kIterations; iterations++) {
        BenchmarkSuite.benchmarkContent.appendChild(_domTree);
      }
    }
  }


  Benchmark getBenchmark() {
    return new Benchmark(name,
                         (x) { test(); },
                         () => setup());
  }

  HTMLElement getDOMTree() {
    HTMLElement domTree = CloneNodes.trees[_size];
    if (null == domTree) {
      switch (_size) {
        case BenchmarkSuite.SIZE_SMALL:
          domTree = CloneNodes.suite.generateSmallTree();
          break;
        case BenchmarkSuite.SIZE_MEDIUM:
          domTree = CloneNodes.suite.generateMediumTree();
          break;
        case BenchmarkSuite.SIZE_LARGE:
          domTree = CloneNodes.suite.generateLargeTree();
          break;
      }
      CloneNodes.trees[_size] = domTree;
    }
    return domTree;
  }
}

class CloneNodes {
  static Array<String> sizes;
  static Array<String> styles;
  static Map<String,HTMLElement> trees;
  static BenchmarkSuite suite;

  static void main() {
    sizes = [BenchmarkSuite.SIZE_SMALL, BenchmarkSuite.SIZE_MEDIUM];
    styles = [CloneNodesTest.STYLE_CLONE, CloneNodesTest.STYLE_APPEND];
    trees = new Map<String, HTMLElement>();

    Array<Benchmark> benchmarks = new Array<Benchmark>();
    // Generate a test for each size/style combination.
    sizes.forEach((size) {
        styles.forEach((style) {
            benchmarks.add(new CloneNodesTest(size, style).getBenchmark());
        });
    });

    suite = new BenchmarkSuite('CloneNodes', benchmarks);
  }
}
