// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//
// Tests looking for ids in different DOM trees full of div elements.
class GetElement {
  final String _size;
  final String _appendStyle;
  final String _treeStyle;
  Array<String> _ids;
  int _nodesFound;

  static Array<String> sizes;
  static Array<String> treeStyles;
  static Map<String /* size */,
    Map<String /* style */, Map<String /* tree/id */, Object>>> treeAndIds;
  static Array<String> appendStyles;
  static BenchmarkSuite suite;

  GetElement(this._size, this._appendStyle, this._treeStyle) :
    this._ids = null {}

  Object setupDOM() {
    HTMLElement domTree = getDOMTree().cloneNode(true);
    BenchmarkSuite.benchmarkContent.appendChild(domTree);
    _nodesFound = 0;
    _ids = getIds();
    return domTree;
  }

  Object setupHTML() {
    BenchmarkSuite.benchmarkContent.innerHTML = getDOMTree().innerHTML;
    _nodesFound = 0;
    _ids = getIds();
    return null;
  }

  Object setup() {
    if ('DOM' == _appendStyle) {
      return setupDOM();
    } else {
      return setupHTML();
    }
  }

  void test() {
    final int kIterations = 1;
    for (int iterations = 0; iterations < kIterations; iterations++) {
      _nodesFound = 0;
      for (int i = 0, len = _ids.length; i < len; i++) {
        HTMLElement div = document.getElementById(_ids[i]);
        String nodeName = div.nodeName;
        _nodesFound++;
      }
    }
  }

  void cleanup() {
    int expectedCount = _ids.length;
    if (_nodesFound != expectedCount) {
      throw new BenchmarkException(
          'Wrong number of nodes found: ${nodesFound} '+
          'expected: ${expectedCount}',
          name);
    }
  }

  String get name() {
    return (sizes.length > 1 ? (_size + ', ') : '') +
        '${_appendStyle}, ${_treeStyle}';
  }

  Benchmark getBenchmark() {
    return new Benchmark(name,
                         (x) { test(); },
                         () => setup(),
                         (x) { cleanup(); });
  }

  Array<String> getIdsFromTree(HTMLElement parent, int maxNumberOfNodes) {
    NodeList allDivs = parent.getElementsByTagName('div');
    int len = allDivs.length;
    int skip;
    if (maxNumberOfNodes >= allDivs.length) {
      skip = 0;
    } else {
      skip = Math2.floor(allDivs.length / maxNumberOfNodes) - 1;
    }
    Array<String> ids = new Array<String>();
    int l = 0;
    for (int i = 0, len = allDivs.length; i < len && l < maxNumberOfNodes;
         i += (skip + 1)) {
      HTMLElement div = allDivs[i];
      ids.add(div.id);
      l++;
    }
    return ids;
  }

  Map<String, Object> createTreeAndIds() {
    final int maxNumberOfNodes = 20000;
    HTMLElement domTree;

    if (_treeStyle == 'dups') {
      // We use four of the trees for the dups style,
      // so they get too big if you use the full size
      // for the bigger trees.
      switch (_size) {
        case 'small':
          domTree = suite.generateSmallTree();
          break;
        case 'medium':
          domTree = suite.generateDOMTree(15, 12, 4);
          break;
        case 'large':
          domTree = suite.generateDOMTree(26, 26, 1);
          break;
      }
    } else {
      switch (_size) {
        case 'small':
          domTree = suite.generateSmallTree();
          break;
        case 'medium':
          domTree = suite.generateMediumTree();
          break;
        case 'large':
          domTree = suite.generateLargeTree();
          break;
      }
    }

    NodeList allDivs = domTree.getElementsByTagName('*');
    int len = allDivs.length;
    int modBy;
    if (maxNumberOfNodes >= allDivs.length) {
      modBy = 1;
    } else {
      modBy = Math2.floor(allDivs.length / maxNumberOfNodes);
    }
    Array<String> ids = new Array<String>();
    for (int i = 0, len = allDivs.length; i < len; i++) {
      int mod = i % modBy;
      HTMLElement div = allDivs[i];
      if (mod == 0 && ids.length < maxNumberOfNodes) {
        if (null != div.id && div.id != '') {
          ids.add(div.id);
        }
      } else if (_treeStyle == 'sparse') {
        div.id = null;
      }
    }

    if (_treeStyle == 'dups') {
      HTMLElement newRoot = document.createElement('div');
      for (int i = 0; i < 5; i++) {
        newRoot.appendChild(domTree.cloneNode(true));
      }
      domTree = newRoot;
    }

    return {
      'tree': domTree,
      'ids': ids
    };
  }

  Map<String, Object> getTreeAndIds() {
    Map<String, Object> treeAndIdsMap = treeAndIds[_size];
    if (null == treeAndIdsMap) {
      treeAndIdsMap = new Map<String, Object>();
      treeAndIds[_size] = treeAndIdsMap;
    }
    Map<String, Object> treeAndIds =
        treeAndIdsMap[_treeStyle];
    if (null == treeAndIds) {
      treeAndIds = createTreeAndIds();
      treeAndIdsMap[_treeStyle] = treeAndIds;
    }
    return treeAndIds;
  }

  HTMLElement getDOMTree() {
    Map<String, Object> treeAndIds = getTreeAndIds();
    return treeAndIds['tree'].dynamic;
  }

  Array<String> getIds() {
    Map<String, Object> treeAndIds = getTreeAndIds();
    return treeAndIds['ids'].dynamic;
  }

  static void main() {
    sizes =  ['medium'];
    treeStyles = ['sparse', 'dense', 'dups'];
    treeAndIds = {};
    appendStyles = ['DOM', 'HTML'];

    Array<Benchmark> benchmarks = new Array<Benchmark>();

    for (String size in sizes) {
      for (String appendStyle in appendStyles) {
        for (String treeStyle in treeStyles) {
          benchmarks.add(
              new GetElement(size, appendStyle, treeStyle).getBenchmark());
        }
      }
    }

    suite = new BenchmarkSuite('Get Elements', benchmarks);
  }
}
