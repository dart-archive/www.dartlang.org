// Copyright 2011 Google Inc. All Rights Reserved.

class DomBenchmark extends BenchmarkSuiteObserver {
  int benchmarks;
  Map<String, Map<String, double>> scores;
  Map<String, double> currentSuiteScore;
  BenchmarkSuiteObserver reporter;

  static int completed;
  static bool success;
  static Map<String, String> args;
  static int nColumns;
  static Map<String, Map<String, double>> normalizedScores;
  static Map<String, Map<String, double>> lastScores;

  DomBenchmark(BenchmarkSuiteObserver reporter)
    : super() {
    this.benchmarks = BenchmarkSuite.countBenchmarks();
    this.reporter = reporter;
    this.scores = {};
  }

  void startAllBenchmarks() {
    completed = 0;
    success = true;
    reporter.startAllBenchmarks();
  }

  void startBenchmarkSuite(BenchmarkSuite suite) {
    currentSuiteScore = {};
    reporter.startBenchmarkSuite(suite);
  }

  void endBenchmarkSuite(BenchmarkSuite suite, int time, Object error) {
    var row = suite.row;
    var cell = row.insertCell(-1);
    row.style.setProperty('color', 'rgb(0, 0, 0)', '');
    cell.appendChild(document.createTextNode(time !== null ? time.toString() : ''));
    cell.colSpan = nColumns - 2;
    suite.cell.colSpan = 1;
    if (time != 0) {
      scores[suite.name] = currentSuiteScore;
    }

    reporter.endBenchmarkSuite(suite, time, error);
  }

  int get minIterations() {
    if (args['minIterations'] !== null) {
      return Math.parseInt(args['minIterations']);
    } else {
      return 5;
    }
  }

  static bool get isGolemRun() {
      return null != args['golem'];
  }

  bool get keepNodes() {
    HTMLInputElement keepNodes = Env.byId('keep_nodes');
    return keepNodes.checked;
  }

  void updateStatus() {
    HTMLElement statusBox = Env.byId('statusProgressBox');
    HTMLElement status = Env.byId('statusProgress');
    if (status === null) {
      return;
    }
    completed++;

    int percentage = Math2.floor(((completed / this.benchmarks) * 100.0));
    status.innerHTML = 'Running: ${percentage}% completed.';

    statusBox.style.setProperty('display', percentage < 100 ? 'block' : 'none', '');
  }

  // Returns the url for displaying the chart of the times
  // width and height define the dimensions of the chart
  // axis indicates if the axis is to be displayed.
  static String getChartURL(Array<int> times,
                            int width,
                            int height,
                            bool axis) {
    // Type: simple line.
    String url = 'http://chart.apis.google.com/chart?cht=ls';
    String size = '${width}x${height}';
    // Size.
    url = url.concat('&chs=${size}');
    // Data.
    String timesEncoded = simpleEncode(times);
    url = url.concat('&chd=${timesEncoded}');
    // Dots if small amount of data.
    if (times.length < (width ~/ 10)) {
      url = url.concat('&chm=o,FF0000,0,-1,3');
    }

    int maxTime = Math2.floor(1.25 * max(times));
    if (axis) {
      // Axes.
      url = url.concat('&chxt=x,y');
      // Range.
      int xmax = (times.length - 1);
      url = url.concat('&chxr=0,0,${xmax}|1,0,${maxTime}');
    }

    return url;
  }

  // Returns the url for displaying the chart of the distribution of the times
  // width and height define the dimensions of the chart
  // axis indicates if the axis is to be displayed.
  static String getDistributionChartURL(Array<int> times,
                                        int width,
                                        int height,
                                        bool axis) {
    String size = '${width}x${height}';
    Map<int,int> timeCounts = new Map<int,int>();
    int maxTime = 0;
    int minTime = 0;

    times.forEach((int time) {
      int count = timeCounts[time];
      if (count === null) {
        count = 0;
      }
      if (maxTime < time) {
        maxTime = time;
      }
      if (minTime == 0 || time < minTime) {
        minTime = time;
      }

      timeCounts[time] = count + 1;
    });

    minTime = Math2.floor(minTime * 0.80);
    maxTime = Math2.floor(maxTime * 1.25);
    Array<int> tc = new Array<int>();
    int maxCount = 0;
    for (int i = minTime; i <= maxTime; i++) {
      int count = timeCounts[i];
      if (count !== null) {
        if (count > maxCount) {
          maxCount = count;
        }
        tc.add(count);
      } else {
        tc.add(-1);
      }
    }
    maxCount = Math2.floor(maxCount * 1.25);
    // Type: vertical bar.
    String url = 'http://chart.apis.google.com/chart?&cht=bvs';
    // Size.
    url = url.concat('&chs=${size}');
    // Data.
    String tcEncoded = simpleEncode(tc);
    url = url.concat('&chd=${tcEncoded}');
    // Autocompute bar width.
    url = url.concat('&chbh=a,0,0');
    if (axis) {
      // Show x and y axis.
      url = url.concat('&chxt=x,y');
      // Range of axes.
      url = url.concat('&chxr=0,${minTime},${maxTime}|1,0,${maxCount}');
      int skip = Math2.floor((maxTime - minTime) / 10);
      Array<String> ticks = new Array<String>();
      for (int i = minTime; i < maxTime; i++) {
        ticks.add('');
      }

      for (int i = skip + 1; i < (maxTime - minTime); i += (skip + 1)) {
        ticks[i] = (i + minTime).toString();
      }

      // Ticks
      // TODO:[davemoore] Bar charts with adjusted ranges
      // have a problem with tickmarks. This code creates them explicitly
      // by having no more than 10 numbers, spaced out.
      // Blanks indicate no tick
      // Unfortunately when then benchmarks take too long, we end up with
      // too many blanks and the URL gets too long, and we fail
      String joinedTicks = Strings.join(ticks, '|');
      url = url.concat('&chxl=0:|${joinedTicks}');
    }

    return url;
  }

  void startBenchmark(Benchmark benchmark) {
    reporter.startBenchmark(benchmark);
  }

   // Adds a cell, limiting to precision decimal places.
  HTMLElement addCell(HTMLTableRowElement row, num amount, int precision) {
    HTMLTableCellElement cell = row.insertCell(-1);
    String amountStr =
        Math2.toStringAsFixed(amount, precision);
    cell.appendChild(document.createTextNode(amountStr));
    return cell;
  }

  // Adds an image.
  void addImage(HTMLTableRowElement row, Array<int> times,
                Function getChartUrlFunc) {
    String imgUrl = getChartUrlFunc(times, 100, 20, false);
    String linkUrl = getChartUrlFunc(times, 500, 200, true);
    HTMLTableCellElement cell = row.insertCell(-1);
    HTMLAnchorElement link = document.createElement('a');
    link.href = linkUrl;
    link.target = 'chart';
    HTMLImageElement img = document.createElement('img');
    img.src = imgUrl;
    img.border = '0';
    img.width = 100;
    img.height = 20;
    link.appendChild(img);
    cell.appendChild(link);
  }

  void addNodesLink(HTMLTableRowElement row, BenchmarkResult result) {
    // Nodes (Don't include benchmarkContent itself).
    if (result.nNodes != 0) {
      HTMLTableCellElement cell = row.insertCell(-1);
      HTMLAnchorElement link = document.createElement('a');
      link.href = '#';
      Text textNode =
          document.createTextNode(result.nNodes.toString() +
                                      (result.nNodes == 1 ? ' node' : ' nodes'));
      link.appendChild(textNode);
      link.onclick = (event) {
        var newWindow = window.open('benchmarkContent.html', '_blank');
        newWindow.setTimeout(
            () {
              Document newDocument = newWindow.document;
              HTMLElement benchmarkContentHolder =
                  Env.byId('benchmark_content_holder');
              benchmarkContentHolder.innerHTML = result.html;
              newDocument.title = result.benchmark.name;
            }, 500);
      };
      cell.appendChild(link);
    }
  }

  void endBenchmark(BenchmarkResult result) {
    updateStatus();
    HTMLTableRowElement row = result.benchmark.row;
    if (Env.byId('normalize_results').dynamic.checked && normalizedScores !== null) {
      Map<String, double> nSuite =
          normalizedScores[result.benchmark.suite.name];
      if (null != nSuite) {
        double nBenchmark = nSuite[result.benchmark.name];
        if (null != nBenchmark) {
          result.score = (result.score / nBenchmark) * 100;
        }
      }
    }

    if (null != result.error) {
      row.style.setProperty('color', 'rgb(255, 0, 0)', '');
      HTMLTableCellElement cell = row.insertCell(-1);
      cell.colSpan = nColumns - 2;
      cell.appendChild(document.createTextNode(result.error.toString()));
    } else {
      if (result.min < 10) {
        row.style.setProperty('font-style', 'oblique', '');
      }
      row.style.setProperty('color', 'rgb(0, 0, 0)', '');

      addCell(row, result.score, 1);
      addCell(row, result.mean, 2);
      addCell(row, result.median, 2);
      addCell(row, result.min, 0);
      addCell(row, result.max, 0);
      addCell(row, result.times.length, 0); // Runs

      if (args['noCharts'] === null) {
        addImage(row, result.times, (times, w, h, axis) =>
            getChartURL(times, w, h, axis));
        addImage(row, result.times, (times, w, h, axis) =>
            getDistributionChartURL(times, w, h, axis));
      }
    }

    addNodesLink(row, result);

    if (result.score !== null) {
      currentSuiteScore[result.benchmark.name] = result.score;
    }

    reporter.endBenchmark(result);
  }

  void endAllBenchmarks(int time) {
    Array<double> suiteScores = new Array<double>();

    scores.forEach((String suite, Map<String, double> results) {
      Array<double> scores = new Array<double>();
      results.forEach((String benchmark, double score) {
        scores.add(score);
      });
      suiteScores.add(Math2.geometricMean(scores));
    });
    time = Math2.round(Math2.geometricMean(suiteScores));
    if (success) {
      HTMLElement status = Env.byId('status');
      status.innerHTML = 'Score: ${time}';
    }

    HTMLElement button = Env.byId('start_button');
    button.style.setProperty('display', 'block', '');
    window.scrollTo(0, 0);
    lastScores = scores;

    reporter.endAllBenchmarks(time);
  }

  static void getResults() {
    DOMWindow newWindow =
        window.open('driver/normalize_factors.html', '_blank');

    windowLoaded() {
      var scores = lastScores;
      var resultText = [];
      resultText.add('<pre>');
      resultText.add('// Generated: ' + new DateTime.now().date);
      resultText.add('// Browser: ' + window.navigator.userAgent);
      // TODO resultText.add(dojo.toJson(scores, true));
      resultText.add('</pre>');
      Env.byId('results').innerHTML = Strings.join(resultText, '\n');
    }

    newWindow.setTimeout(() { windowLoaded(); }, 200);
  }

  static void suiteClicked(var event) {
    BenchmarkSuite suite = BenchmarkSuite.findSuiteByCheck(event.currentTarget);
    bool checked = event.currentTarget.checked;

    suite.benchmarks.forEach((benchmark) {
      benchmark.check.checked = checked;
    });
  }

  static Map<String, String> getQueryArgs() {
    String url = document.URL;
    int qMark = url.indexOf('?', 0);
    Map<String, String> argsMap = new Map<String, String>();
    if (qMark != -1) {
      String argsString = url.substringToEnd(qMark + 1);
      argsString = argsString.replace('+', ' ');
      Array<String> argPairs = argsString.split('&');
      argPairs.forEach((String argPair) {
        Array<String> argTuple = argPair.split('=');
        if (argTuple.length > 1) {
          argsMap[argTuple[0]] = argTuple[1];
        } else {
          argsMap[argTuple[0]] = '';
        }
      });
    }
    return argsMap;
  }

  // Benchmark Suites or benchmarks can be run automatically at launch
  // by passing them with the 'run=' query arg. A ',' separated list
  // can be passed. The values are the names of the suites, or the suite name
  // and benchmark name separated by a '.'.
  // For example ?run=CreateNodes will run all benchmarks in the CreateNodes
  // suite.
  // ?run=CreateNodes.appendNodesWithDOMUsingDocumentFragment
  // will run only that benchmark
  //
  // Replace any spaces in names with a '+'. Also, the special name 'all' runs
  // all suites/benchmarks (eg, '?run=all')
  //
  // You can specify that report submission happen automatically, and also
  // specify a value for the tags input field, via 'submitreport=1' and
  // 'tags=foo,bar' respectively. E.g.
  //  ?run=all&tags=foo,bar&submitreport=1
  //
  // As an alternative to submitting a report to a server, you may set
  // the report JSON as a javascript variable via 'reportInJS=1'.
  static initUI() {
    var results = Env.byId('results');
    String onlyCheckArg = null;
    if (args['run'] !== null && args['run'] != 'all') {
      onlyCheckArg = args['run'];
    }
    Map<String, bool> onlyCheckSuites = {};
    Map<String, bool> onlyCheckBenchmarks = {};
    Env.byId('master_toggle').dynamic.checked = null == onlyCheckArg;
    if (null != onlyCheckArg) {
      Array<String> onlyCheckValues = onlyCheckArg.split(',');
      onlyCheckValues.forEach((String onlyCheckValue) {
        if (onlyCheckValue.indexOf('.', 0) == -1) {
          onlyCheckSuites[onlyCheckValue] = true;
        } else {
          onlyCheckBenchmarks[onlyCheckValue] = true;
        }
      });
    }

    nColumns = Env.byId('results_header').dynamic.cells.length;

    BenchmarkSuite.suites.forEach((suite) {
      HTMLTableRowElement suiteRow = results.insertRow(-1);
      HTMLTableCellElement checkCell = suiteRow.insertCell(-1);
      HTMLInputElement check = document.createElement('input');
      check.type = 'checkbox';
      checkCell.appendChild(check);
      if (null != onlyCheckArg) {
        check.checked = onlyCheckSuites[suite.name];
      } else {
        check.checked = true;
      }
      // TODO check.suite = suite;
      check.onclick = (e) { suiteClicked(e); };
      HTMLTableCellElement suiteCell = suiteRow.insertCell(-1);
      suiteRow.style.setProperty('background-color', 'rgb(229, 236, 249)', '');
      suiteRow.style.setProperty('color', 'rgb(128, 128, 128)', '');
      suiteRow.style.setProperty('font-weight', 'bold', '');
      suiteCell.colSpan = nColumns - 1;
      suiteCell.appendChild(document.createTextNode(suite.name));
      // TODO (olonho): how to suiteRow.suite = suite;
      suite.row = suiteRow;
      suite.cell = suiteCell;
      suite.check = check;

      suite.benchmarks.forEach((benchmark) {
        HTMLTableRowElement markRow = results.insertRow(-1);
        HTMLTableCellElement checkCell = markRow.insertCell(-1);
        checkCell.style.setProperty('height', '22px', '');
        check = document.createElement('input');
        check.type = 'checkbox';
        checkCell.appendChild(check);
        if (null != onlyCheckArg) {
          String fullName = suite.name + '.' + benchmark.name;
          check.checked =
              onlyCheckSuites[suite.name] ||
              onlyCheckBenchmarks[fullName];
        } else {
          check.checked = true;
        }
        benchmark.check = check;
        var markCell = markRow.insertCell(-1);
        markCell.appendChild(document.createTextNode(benchmark.name));
        markRow.style.setProperty('color', 'rgb(128, 128, 128)', '');
        benchmark.row = markRow;
      });
    });
  }

  static final String SIMPLE_ENCODING =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

  static max(Array array) {
    var max = null;
    array.forEach((value) {
      if (max === null || max < value) {
        max = value;
      }
    });
    return max;
  }

  static min(Array array) {
    var min = null;
    array.forEach((value) {
      if (min === null || min > value) {
        min = value;
      }
    });
    return min;
  }

  // Encodes the array into the simple encoding for charts
  // If maxValue is null, it's computed to be 1.25 * the max value from
  // the valueArray
  static String simpleEncode(Array<int> valueArray, int maxValue = null) {
    if (maxValue === null || maxValue == 0) {
      maxValue = max(valueArray);
      maxValue = Math2.floor(maxValue * 1.25 + 1);
    }

    Array<String> chartData = new Array<String>();
    chartData.add('s'); chartData.add(':');
    for (int i = 0; i < valueArray.length; i++) {
      int currentValue = valueArray[i];
      if (currentValue >= 0) {
        int index = (SIMPLE_ENCODING.length - 1) * currentValue ~/ maxValue;
        chartData.add(SIMPLE_ENCODING[index].toString());
      } else {
        chartData.add('_');
      }
    }
    return Strings.join(chartData, '');
  }

  // Gets the range arguments for passing to the Google Charts api.
  String dimensions(Array x, Array y) {
    var maxX = max(x);
    maxX = Math2.floor(maxX * 1.25);
    String chds = '&chds=0,${maxX}';
    if (y !== null) {
      var maxY = max(y);
      maxY = Math2.floor(maxY * 1.25);
      chds = chds.concat('|0,${maxY}');
    }
    return chds;
  }

  // Encodes the array into the text format for charts.
  // If maxValue is null, it's computed to be 1.25 * the max value from
  // the valueArray.
  // To get the range declaration (which is automatically computed
  // for the simple encoding, be sure to call dimensions().
  static String textEncode(Array<String> x, Array<String> y) {
    String encoding = 't:';
    encoding = encoding.concat(Strings.join(x, ','));
    if (y !== null) {
      encoding = encoding.concat('|');
      encoding = encoding.concat(Strings.join(y, ','));
    }
    return encoding;
  }

  static void clearUI() {
    HTMLTableElement results = Env.byId('results');
    for (int r = 1, rLen = results.rows.length; r < rLen; r++) {
      HTMLTableRowElement row = results.rows[r];
      row.style.setProperty('color', 'rgb(128, 128, 128)', '');
      for (int i = row.cells.length; --i >= 2;) {
        row.deleteCell(i);
      }
    }
    Env.byId('status').innerHTML = 'Score: 0';
  }

  static void load() {
    String version = BenchmarkSuite.version;
    args = getQueryArgs();
    initUI();
    Env.byId('version').innerHTML = version;
    BenchmarkSuite.setBenchmarkContent(Env.byId('benchmark_content'));
  }

  static void delayLoad() {
    Env.later(() { load(); }, 2000);
  }

  static void run(BenchmarkSuiteObserver benchmarkRunner) {
    HTMLElement button = Env.byId('start_button');
    button.style.setProperty('display', 'none', '');
    clearUI();
    BenchmarkSuite.runSuites(benchmarkRunner);
  }

  void toggleAllChecks(var event) {
    var checked = event.currentTarget.checked;
    BenchmarkSuite.suites.forEach((suite) {
        suite.check.checked = checked;
        suite.benchmarks.each((benchmark) {
            benchmark.check.checked = checked;
        });
    });
  }

  void toggleReporting(Event event) {
    HTMLInputElement target = event.currentTarget;
    bool checked = target.checked;
    HTMLElement div = Env.byId('submit_report_div');
    String tags = Reporter.reportTags;
    // TODO: rewrite in Dart style
    if (checked) {
      Reporter.submitReport = true;
      StringBuffer content = new StringBuffer();
      String url = Reporter.reportUrl;
      content.add('<br>Report Url: <input size="60" ');
      content.add('value="${url}" ');
      content.add('type="text" '+
                  'onchange="Reporter.reportUrl=this.value"');
      content.add('<br>');
      content.add('Tags: <input type="text" size="30" ');
      content.add('value="${tags}" ');
      content.add('onchange="Reporter.reportTags=this.value">');
      content.add('<i>(comma-separated list; '+
                  'not required)</i><br><br>');
      div.innerHTML = content.toString();
    } else {
      Reporter.submitReport = false;
      div.innerHTML = '';
    }
  }
}
