// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * This class is the public interface of a set. A set is a collection
 * without duplicates.
 */
interface Set<E> extends Collection<E> factory HashSet/* <E> */ {
// TODO(ahe): Factory should be HashSet<E>
  Set();

  /**
   * Creates a [Set] that contains all elements of [other].
   */
  Set.from(Iterable<E> other);

  /**
   * Returns true if [value] is in the set.
   */
  bool contains(E value);

  /**
   * Adds [value] into the set. The method has no effect if
   * [value] was already in the set.
   */
  void add(E value);

  /**
   * Removes [value] from the set. Returns true if [value] was
   * in the set. Returns false otherwise. The method has no effect
   * if [value] value was not in the set.
   */
  bool remove(E value);

  /**
   * Adds all the elements of the given collection to the set.
   */
  void addAll(Collection<E> collection);

  /**
   * Removes all the elements of the given collection from the set.
   */
  void removeAll(Collection<E> collection);

  /**
   * Returns true if [collection] contains all the elements of this
   * collection.
   */
  bool isSubsetOf(Collection<E> collection);

  /**
   * Returns true if this collection contains all the elements of
   * [collection].
   */
  bool containsAll(Collection<E> collection);

  /**
   * Returns a new set which is the intersection between this set and
   * the given collection.
   */
  Set<E> intersection(Collection<E> other);

  /**
   * Removes all elements in the set.
   */
  void clear();

}

