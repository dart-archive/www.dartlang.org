// Copyright 2011 Google Inc. All Rights Reserved.

interface Pattern {
  // TODO(ngeoffray): change the interface to return an iterator.
  Collection<Match> allMatchesIn(String str);
}
