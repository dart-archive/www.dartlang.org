// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * A node in a splay tree. It holds the key, the value and the left
 * and right children in the tree.
 */
class SplayTreeNode<K, V> {
  SplayTreeNode(K k, V v) {
    key = k;
    value = v;
  }

  K key;
  V value;
  SplayTreeNode<K, V> left;
  SplayTreeNode<K, V> right;
}

/**
 * A splay tree is a self-balancing binary
 * search tree with the additional property that recently accessed
 * elements are quick to access again. It performs basic operations
 * such as insertion, look-up and removal in O(log(n)) amortized time.
 *
 * This implementation is a Dart version of the JavaScript
 * implementation in the V8 project.
 */
class SplayTree<K extends Comparable, V> implements Map<K, V> {

  // The root node of the splay tree. It will contain either the last
  // element inserted, or the last element looked up.
  SplayTreeNode<K, V> root_;

  // The dummy node used when performing a splay on the tree. It is a
  // local field of the class to avoid allocating a node each time a
  // splay is performed.
  SplayTreeNode<K, V> dummy_;

  // Number of elements in the splay tree.
  int count_;

  SplayTree() {
    dummy_ = new SplayTreeNode<K, V>(null, null);
    count_ = 0;
  }

  /**
   * Perform the splay operation for the given key. Moves the node with
   * the given key to the top of the tree.  If no node has the given
   * key, the last node on the search path is moved to the top of the
   * tree. This is the simplified top-down splaying algorithm from:
   * "Self-adjusting Binary Search Trees" by Sleator and Tarjan.
   */
  void splay_(K key) {
    if (isEmpty()) return;

    // The right child of the dummy node will hold
    // the L tree of the algorithm.  The left child of the dummy node
    // will hold the R tree of the algorithm.  Using a dummy node, left
    // and right will always be nodes and we avoid special cases.
    SplayTreeNode<K, V> left = dummy_;
    SplayTreeNode<K, V> right = dummy_;
    SplayTreeNode<K, V> current = root_;
    while (true) {
      if (key.compareTo(current.key) < 0) {
        if (current.left === null) break;
        if (key.compareTo(current.left.key) < 0) {
          // Rotate right.
          SplayTreeNode<K, V> tmp = current.left;
          current.left = tmp.right;
          tmp.right = current;
          current = tmp;
          if (current.left === null) break;
        }
        // Link right.
        right.left = current;
        right = current;
        current = current.left;
      } else if (key.compareTo(current.key) > 0) {
        if (current.right === null) break;
        if (key.compareTo(current.right.key) > 0) {
          // Rotate left.
          SplayTreeNode<K, V> tmp = current.right;
          current.right = tmp.left;
          tmp.left = current;
          current = tmp;
          if (current.right === null) break;
        }
        // Link left.
        left.right = current;
        left = current;
        current = current.right;
      } else {
        break;
      }
    }
    // Assemble.
    left.right = current.left;
    right.left = current.right;
    current.left = dummy_.right;
    current.right = dummy_.left;
    root_ = current;

    dummy_.right = null;
    dummy_.left = null;
  }

  V operator [](K key) {
    if (!isEmpty()) {
      splay_(key);
      if (root_.key.compareTo(key) == 0) return root_.value;
    }
    return null;
  }

  V remove(K key) {
    if (isEmpty()) return null;
    splay_(key);
    if (root_.key.compareTo(key) != 0) return null;
    V value = root_.value;

    count_--;
    // assert(count_ >= 0);
    if (root_.left === null) {
      root_ = root_.right;
    } else {
      SplayTreeNode<K, V> right = root_.right;
      root_ = root_.left;
      // Splay to make sure that the new root has an empty right child.
      splay_(key);
      // Insert the original right child as the right child of the new
      // root.
      root_.right = right;
    }
    return value;
  }

  void operator []=(K key, V value) {
    if (isEmpty()) {
      count_++;
      root_ = new SplayTreeNode(key, value);
      return;
    }
    // Splay on the key to move the last node on the search path for
    // the key to the root of the tree.
    splay_(key);
    if (root_.key.compareTo(key) == 0) {
      root_.value = value;
      return;
    }
    SplayTreeNode<K, V> node = new SplayTreeNode(key, value);
    // assert(count_ >= 0);
    count_++;
    if (key.compareTo(root_.key) > 0) {
      node.left = root_;
      node.right = root_.right;
      root_.right = null;
    } else {
      node.right = root_;
      node.left = root_.left;
      root_.left = null;
    }
    root_ = node;
  }

  V putIfAbsent(K key, V ifAbsent()) {
    if (containsKey(key)) return this[key];
    V value = ifAbsent();
    this[key] = value;
    return value;
  }

  bool isEmpty() {
    // assert(!((root_ === null) && (count_ != 0)));
    // assert(!((count_ == 0) && (root_ !== null)));
    return (root_ === null);
  }

  void forEach(void f(K key, V value)) {
    Array<SplayTreeNode<K, V>> array = new Array<SplayTreeNode<K, V>>();
    SplayTreeNode<K, V> current = root_;
    while (current != null) {
      if (current.left != null) {
        array.add(current);
        current = current.left;
      } else {
        f(current.key, current.value);
        while (current.right == null) {
          if (array.isEmpty()) return;
          current = array.removeLast();
          f(current.key, current.value);
        }
        current = current.right;
      }
    }
  }

  int get length() {
    return count_;
  }

  void clear() {
    root_ = null;
    count_ = 0;
  }

  bool containsKey(K key) {
    if (!isEmpty()) {
      splay_(key);
      if (root_.key.compareTo(key) == 0) return true;
    }
    return false;
  }

  bool containsValue(V value) {
    bool found = false;
    // Note: Worst performance you can get because we don't have
    // non-local return.
    // TODO: optimize this method with a similar code than forEach.
    forEach((Object k, Object v) { if (value == v) found = true; });
    return found;
  }

  Collection<K> getKeys() {
    Array<K> array = new Array<K>();
    forEach((K k, V v) { array.add(k); });
    return array;
  }

  Collection<V> getValues() {
    Array<V> array = new Array<V>();
    forEach((K k, V v) { array.add(v); });
    return array;
  }
}
