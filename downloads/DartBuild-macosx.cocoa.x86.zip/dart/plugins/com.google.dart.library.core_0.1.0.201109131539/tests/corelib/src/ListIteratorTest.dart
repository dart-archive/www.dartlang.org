// Copyright 2011 Google Inc. All Rights Reserved.

class ListIteratorTest {
  static testMain() {
    testSmallList();
    testLargeList();
    testEmptyList();
  }

  static void testThrows(Iterator<int> it) {
    Expect.equals(false, it.hasNext());
    var exception = null;
    try {
      it.next();
    } catch (NoMoreElementsException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
  }

  static int sum(int expected, Iterator<int> it) {
    int count = 0;
    while (it.hasNext()) {
      count += it.next();
    }
    Expect.equals(expected, count);
  }

  static void testSmallList() {
    List<int> list = new List<int>();
    list.addLast(1);
    list.addLast(2);
    list.addLast(3);

    Iterator<int> it = list.iterator();
    Expect.equals(true, it.hasNext());
    sum(6, it);
    testThrows(it);
  }

  static void testLargeList() {
    List<int> list = new List<int>();
    int count = 0;
    for (int i = 0; i < 100; i++) {
      count += i;
      list.addLast(i);
    }
    Iterator<int> it = list.iterator();
    Expect.equals(true, it.hasNext());
    sum(count, it);
    testThrows(it);
  }

  static void testEmptyList() {
    List<int> list = new List<int>();
    Iterator<int> it = list.iterator();
    Expect.equals(false, it.hasNext());
    sum(0, it);
    testThrows(it);
  }
}

main() {
  ListIteratorTest.testMain();
}
