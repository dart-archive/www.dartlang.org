// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test for testing out of range exceptions on arrays.

class IndexOutOfRangeExceptionTest {
  static testRead() {
    testArrayRead([], 0);
    testArrayRead([], -1);
    testArrayRead([], 1);

    var array = [1];
    testArrayRead(array, -1);
    testArrayRead(array, 1);

    array = new Array(1);
    testArrayRead(array, -1);
    testArrayRead(array, 1);

    array = new Array();
    testArrayRead(array, -1);
    testArrayRead(array, 0);
    testArrayRead(array, 1);
  }

  static testWrite() {
    testArrayWrite([], 0);
    testArrayWrite([], -1);
    testArrayWrite([], 1);

    var array = [1];
    testArrayWrite(array, -1);
    testArrayWrite(array, 1);

    array = new Array(1);
    testArrayWrite(array, -1);
    testArrayWrite(array, 1);

    array = new Array();
    testArrayWrite(array, -1);
    testArrayWrite(array, 0);
    testArrayWrite(array, 1);
  }

  static testMain() {
    testRead();
    testWrite();
  }

  static testArrayRead(array, index) {
    var exception = null;
    try {
      var e = array[index];
    } catch (IndexOutOfRangeException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
  }

  static testArrayWrite(array, index) {
    var exception = null;
    try {
      array[index] = null;
    } catch (IndexOutOfRangeException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
  }
}

main() {
  IndexOutOfRangeExceptionTest.testMain();
}
