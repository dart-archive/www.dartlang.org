// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for RegExp.stringMatch.

class RegExpStringMatchTest {
  static testMain() {
    Expect.equals('cat', new RegExp("(\\w+)", "").stringMatch("cat dog"));
    Expect.equals(null, new RegExp("foo", "").stringMatch("bar"));
  }
}

main() {
  RegExpStringMatchTest.testMain();
}
