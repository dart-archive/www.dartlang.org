// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test for Splaytrees.
// VMOptions=--expose_core_impl

class SplayTreeTest {

  static testMain() {
    SplayTree tree = new SplayTree();
    tree[1] = "first";
    tree[3] = "third";
    tree[5] = "fifth";
    tree[2] = "second";
    tree[4] = "fourth";

    var correctSolution = ["first", "second", "third", "fourth", "fifth"];

    tree.forEach((key, value) {
      Expect.equals(true, key >= 1);
      Expect.equals(true, key <= 5);
      Expect.equals(value, correctSolution[key - 1]);
    });
  }
}

main() {
  SplayTreeTest.testMain();
}
