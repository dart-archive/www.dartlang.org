// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for RegExp.group.

class RegExpGroupTest {
  static testMain() {
    var match = new RegExp("(a(b)((c|de)+))", "").firstMatch("abcde");
    Expect.equals('abcde', match.group(0));
    Expect.equals('abcde', match.group(1));
    Expect.equals('b', match.group(2));
    Expect.equals('cde', match[3]);
    Expect.equals('de', match[4]);
  }
}

main() {
  RegExpGroupTest.testMain();
}
