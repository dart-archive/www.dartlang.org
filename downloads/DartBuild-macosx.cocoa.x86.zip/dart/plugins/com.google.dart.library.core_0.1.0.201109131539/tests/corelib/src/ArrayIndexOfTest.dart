// Copyright 2011 Google Inc. All Rights Reserved.

class ArrayIndexOfTest {
  static testMain() {
    test(new Array<int>(5));
    var a = new Array<int>();
    a.length = 5;
    test(a);
  }

  static void test(Array<int> array) {
    array[0] = 1;
    array[1] = 2;
    array[2] = 3;
    array[3] = 4;
    array[4] = 1;

    Expect.equals(3, array.indexOf(4, 0));
    Expect.equals(0, array.indexOf(1, 0));
    Expect.equals(4, array.lastIndexOf(1, array.length - 1));

    Expect.equals(4, array.indexOf(1, 1));
    Expect.equals(-1, array.lastIndexOf(4, 2));

    Expect.equals(3, array.indexOf(4, 2));
    Expect.equals(3, array.indexOf(4, -5));
    Expect.equals(-1, array.indexOf(4, 50));

    Expect.equals(-1, array.lastIndexOf(4, 2));
    Expect.equals(-1, array.lastIndexOf(4, -5));
    Expect.equals(3, array.lastIndexOf(4, 50));
  }
}

main() {
  ArrayIndexOfTest.testMain();
}
