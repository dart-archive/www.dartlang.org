// Copyright 2011 Google Inc. All Rights Reserved.

class ArrayTest {

  static testMain() {
    testArray();
    testExpandableArray();
  }

  static void expectValues(array, val1, val2, val3, val4) {
    Expect.equals(true, array.length == 4);
    Expect.equals(true, array.length == 4);
    Expect.equals(true, !array.isEmpty());
    Expect.equals(array[0], val1);
    Expect.equals(array[1], val2);
    Expect.equals(array[2], val3);
    Expect.equals(array[3], val4);
  }

  static void testClosures(Array array) {
    testFilter(val) { return val == 3; }
    Collection filtered = array.filter(testFilter);
    Expect.equals(filtered.length, 1);

    testEvery(val) { return val != 11; }
    bool test = array.every(testEvery);
    Expect.equals(true, test);

    testSome(val) { return val == 1; }
    test = array.some(testSome);
    Expect.equals(true, test);

    testSomeFirst(val) { return val == 0; }
    test = array.some(testSomeFirst);
    Expect.equals(true, test);

    testSomeLast(val) { return val == (array.length - 1); }
    test = array.some(testSomeLast);
    Expect.equals(true, test);
  }

  static void testArray() {
    Array array = new Array(4);
    Expect.equals(array.length, 4);
    array[0] = 4;
    expectValues(array, 4, null, null, null);
    String val = "fisk";
    array[1] = val;
    expectValues(array, 4, val, null, null);
    double d = 2.0;
    array[3] = d;
    expectValues(array, 4, val, null, d);

    for (int i = 0; i < array.length; i++) {
      array[i] = i;
    }

    for (int i = 0; i < 4; i++) {
      Expect.equals(array[i], i);
    }

    testClosures(array);

    var exception = null;
    try {
      array.clear();
    } catch (UnsupportedOperationException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
  }

  static void testExpandableArray() {
    Array array = new Array();
    Expect.equals(true, array.isEmpty());
    Expect.equals(array.length, 0);
    array.add(4);
    Expect.equals(1, array.length);
    Expect.equals(true, !array.isEmpty());
    Expect.equals(array.length, 1);
    Expect.equals(array.length, 1);
    Expect.equals(array.removeLast(), 4);

    for (int i = 0; i < 10; i++) {
      array.add(i);
    }

    Expect.equals(array.length, 10);
    for (int i = 0; i < 10; i++) {
      Expect.equals(array[i], i);
    }

    testClosures(array);

    Expect.equals(array.removeLast(), 9);
    array.clear();
    Expect.equals(array.length, 0);
    Expect.equals(array.length, 0);
    Expect.equals(true, array.isEmpty());
  }
}

main() {
  ArrayTest.testMain();
}
