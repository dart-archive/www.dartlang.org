// Copyright 2011 Google Inc. All Rights Reserved.

class ArrayFromArrayTest {

  static testMain() {
    var array = [1, 2, 4];

    var sub = new Array.fromArray(array, 0, 3);
    Expect.equals(3, sub.length);
    Expect.equals(1, sub[0]);
    Expect.equals(2, sub[1]);
    Expect.equals(4, sub[2]);

    sub = new Array.fromArray(array, 1, 3);
    Expect.equals(2, sub.length);
    Expect.equals(2, sub[0]);
    Expect.equals(4, sub[1]);

    sub = new Array.fromArray(array, 2, 3);
    Expect.equals(1, sub.length);
    Expect.equals(4, sub[0]);

    sub = new Array.fromArray(array, 0, 0);
    Expect.equals(0, sub.length);

    sub = new Array.fromArray(array, 3, 3);
    Expect.equals(0, sub.length);

    sub = new Array.fromArray(array, 0, 1);
    Expect.equals(1, sub.length);
    Expect.equals(1, sub[0]);

    sub = new Array.fromArray(array, 0, 2);
    Expect.equals(2, sub.length);
    Expect.equals(1, sub[0]);
    Expect.equals(2, sub[1]);

    sub = new Array.fromArray(array, 1, 2);
    Expect.equals(1, sub.length);
    Expect.equals(2, sub[0]);

    sub = new Array.fromArray(array, -1, 2);
    Expect.equals(2, sub.length);
    Expect.equals(1, sub[0]);
    Expect.equals(2, sub[1]);

    sub = new Array.fromArray(array, 1, 5);
    Expect.equals(2, sub.length);
    Expect.equals(2, sub[0]);
    Expect.equals(4, sub[1]);

    array = [];
    sub = new Array.fromArray(array, 1, 5);
    Expect.equals(0, sub.length);

    sub = new Array.fromArray(array, 0, 0);
    Expect.equals(0, sub.length);

    sub = new Array.fromArray(array, 0, 1);
    Expect.equals(0, sub.length);

    // Test that the original array is unchanged after modifications
    // to the array.
    array = [1, 2, 4];
    sub = new Array.fromArray(array, 0, 3);
    sub[0] = 42;
    Expect.equals(1, array[0]);
    Expect.equals(42, sub[0]);

    sub.add(42);
    Expect.equals(4, sub.length);
    Expect.equals(3, array.length);

    array.add(43);
    Expect.equals(4, sub.length);
    Expect.equals(4, array.length);

    Expect.equals(42, sub[3]);
    Expect.equals(43, array[3]);
  }
}

main() {
  ArrayFromArrayTest.testMain();
}
