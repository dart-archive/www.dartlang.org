// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for testing class 'Strings'.

class StringsTest {

  StringsTest() {}

  toString() {
    return "Strings Tester";
  }
  static testCreation() {
    String s = "Hello";
    Array<int> a = new Array(s.length);
    for (int i = 0; i < a.length; i++) {
      a[i] = s.charCodeAt(i);
    }
    String s2 = new String.fromCharCodes(a);
    Expect.equals(s, s2);
  }

  static void testMain() {
    testCreation();
  }
}


main() {
  StringsTest.testMain();
}
