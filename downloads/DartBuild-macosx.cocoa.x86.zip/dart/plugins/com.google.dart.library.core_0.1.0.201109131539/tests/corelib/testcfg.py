# Copyright 2010 Google Inc. All Rights Reserved.

import testing

def GetConfiguration(context, root):
  return testing.StandardTestConfiguration(context, root)
