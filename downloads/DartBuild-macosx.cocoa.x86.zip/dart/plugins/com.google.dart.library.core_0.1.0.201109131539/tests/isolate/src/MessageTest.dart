// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for testing serialization of messages.
// VMOptions=--enable_type_checks --enable_asserts

// ---------------------------------------------------------------------------
// Message passing test.
// ---------------------------------------------------------------------------

class MessageTest {
  static void testMain() {
    PingPongClient.test();
  }

  static final Array array1 = const ["Hello", "World", "Hello", 0xfffffffffff];
  static final Array array2 = const [null, array1, array1, array1, array1];
  static final Array array3 = const [array2, 2.0, true, false, 0xfffffffffff];
  static final Map map1 = const {
    "a=1" : 1, "b=2" : 2, "c=3" : 3,
  };
  static final Map map2 = const {
    "array1" : array1, "array2" : array2, "array3" : array3,
  };
  static final Array array4 = const [map1, map2];
  static final Array elms = const [
      array1, array2, array3, array4,
  ];

  static void VerifyMap(Map expected, Map actual) {
    Expect.equals(true, expected is Map);
    Expect.equals(true, actual is Map);
    Expect.equals(expected.length, actual.length);
    testForEachMap(key, value) {
      if (value is Array) {
        VerifyArray(value, actual[key]);
      } else {
        Expect.equals(value, actual[key]);
      }
    }
    expected.forEach(testForEachMap);
  }

  static void VerifyArray(Array expected, Array actual) {
    for (int i = 0; i < expected.length; i++) {
      if (expected[i] is Array) {
        VerifyArray(expected[i], actual[i]);
      } else if (expected[i] is Map) {
        VerifyMap(expected[i], actual[i]);
      } else {
        Expect.equals(expected[i], actual[i]);
      }
    }
  }

  static void VerifyObject(int index, var actual) {
    var expected = elms[index];
    Expect.equals(true, expected is Array);
    Expect.equals(true, actual is Array);
    Expect.equals(expected.length, actual.length);
    VerifyArray(expected, actual);
  }
}

class PingPongClient {
  static void test() {
    new PingPongServer().spawn().then((SendPort remote) {

      // Send objects and receive them back.
      for (int i = 0; i < MessageTest.elms.length; i++) {
        var sentObject = MessageTest.elms[i];
        // TODO(asiva): remove this local var idx once thew new for-loop
        // semantics for closures is implemented.
        var idx = i;
        remote.call(sentObject).receive(
            (var receivedObject, SendPort replyTo) {
              MessageTest.VerifyObject(idx, receivedObject);
            });
      }

      // Send recursive objects and receive them back.
      Array local_array1 = ["Hello", "World", "Hello", 0xffffffffff];
      Array local_array2 = [null, local_array1, local_array1 ];
      Array local_array3 = [local_array2, 2.0, true, false, 0xffffffffff];
      Array sendObject = new Array(5);
      sendObject[0] = local_array1;
      sendObject[1] = sendObject;
      sendObject[2] = local_array2;
      sendObject[3] = sendObject;
      sendObject[4] = local_array3;
      remote.call(sendObject).receive(
          (var replyObject, SendPort replyTo) {
            Expect.equals(true, sendObject is Array);
            Expect.equals(true, replyObject is Array);
            Expect.equals(sendObject.length, replyObject.length);
            Expect.equals(true, replyObject[1] === replyObject);
            Expect.equals(true, replyObject[3] === replyObject);
            Expect.equals(true, replyObject[0] === replyObject[2][1]);
            Expect.equals(true, replyObject[0] === replyObject[2][2]);
            Expect.equals(true, replyObject[2] === replyObject[4][0]);
            Expect.equals(true, replyObject[0][0] === replyObject[0][2]);
            // Bigint literals are not canonicalized so do a == check.
            Expect.equals(true, replyObject[0][3] == replyObject[4][4]);
          });

      // Shutdown the MessageServer.
      remote.call(-1).receive(
          (int message, SendPort replyTo) {
            Expect.equals(MessageTest.elms.length + 1, message);
          });
    });
  }
}

class PingPongServer extends Isolate {
  PingPongServer() : super() {}

  void main() {
    println("Starting server.");
    int count = 0;
    this.port.receive(
        (var message, SendPort replyTo) {
          if (message == -1) {
            this.port.close();
            println("Stopping server.");
            replyTo.send(count, null);
          } else {
            // Check if the received object is correct.
            if (count < MessageTest.elms.length) {
              MessageTest.VerifyObject(count, message);
            }
            // Bounce the received object back so that the sender
            // can make sure that the object matches.
            replyTo.send(message, null);
            count++;
          }
        });
  }
}

main() {
  MessageTest.testMain();
}
