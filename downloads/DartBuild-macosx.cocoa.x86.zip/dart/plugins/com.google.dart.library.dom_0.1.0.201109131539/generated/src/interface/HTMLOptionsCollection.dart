/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLOptionsCollection extends HTMLCollection {

  int get length();

  void set length(int value);

  int get selectedIndex();

  void set selectedIndex(int value);

  void remove(int index = null);
}
