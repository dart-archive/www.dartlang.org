/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLLabelElement extends HTMLElement {

  String get accessKey();

  void set accessKey(String value);

  HTMLElement get control();

  HTMLFormElement get form();

  String get htmlFor();

  void set htmlFor(String value);
}
