/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DatabaseCallback {

  bool handleEvent(DatabaseCallback_Database_OR_DatabaseSync database);
}

interface DatabaseCallback_Database_OR_DatabaseSync {}
interface Database extends DatabaseCallback_Database_OR_DatabaseSync;
interface DatabaseSync extends DatabaseCallback_Database_OR_DatabaseSync;
