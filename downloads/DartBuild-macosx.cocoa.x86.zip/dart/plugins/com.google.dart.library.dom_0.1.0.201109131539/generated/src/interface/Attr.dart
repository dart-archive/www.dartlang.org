/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface Attr extends Node {

  bool get isId();

  String get name();

  Element get ownerElement();

  bool get specified();

  String get value();

  void set value(String value);
}
