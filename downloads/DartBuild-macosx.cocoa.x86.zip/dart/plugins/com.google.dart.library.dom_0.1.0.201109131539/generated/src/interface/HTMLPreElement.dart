/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLPreElement extends HTMLElement {

  int get width();

  void set width(int value);

  bool get wrap();

  void set wrap(bool value);
}
