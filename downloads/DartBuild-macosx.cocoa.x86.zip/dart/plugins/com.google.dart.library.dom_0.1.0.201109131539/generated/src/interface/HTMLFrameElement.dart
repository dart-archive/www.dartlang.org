/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLFrameElement extends HTMLElement {

  Document get contentDocument();

  DOMWindow get contentWindow();

  String get frameBorder();

  void set frameBorder(String value);

  int get height();

  String get location();

  void set location(String value);

  String get longDesc();

  void set longDesc(String value);

  String get marginHeight();

  void set marginHeight(String value);

  String get marginWidth();

  void set marginWidth(String value);

  String get name();

  void set name(String value);

  bool get noResize();

  void set noResize(bool value);

  String get scrolling();

  void set scrolling(String value);

  String get src();

  void set src(String value);

  int get width();
}
