/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLHtmlElement extends HTMLElement {

  String get manifest();

  void set manifest(String value);

  String get version();

  void set version(String value);
}
