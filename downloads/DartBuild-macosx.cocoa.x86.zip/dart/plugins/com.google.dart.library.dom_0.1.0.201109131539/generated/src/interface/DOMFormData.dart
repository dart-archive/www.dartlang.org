/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface FormData {

  void append(String name = null, String value = null);
}

interface DOMFormData extends FormData {
}
