/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface EventTarget {

  void addEventListener(String type, EventListener listener, bool useCapture = null);

  bool dispatchEvent(Event evt);

  void removeEventListener(String type, EventListener listener, bool useCapture = null);

  // void addEventListener(String type, EventListener listener);
}
