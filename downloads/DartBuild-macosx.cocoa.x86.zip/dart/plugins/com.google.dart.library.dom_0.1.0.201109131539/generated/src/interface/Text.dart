/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface Text extends CharacterData {

  String get wholeText();

  Text replaceWholeText(String content = null);

  Text splitText(int offset = null);
}
