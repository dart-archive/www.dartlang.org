/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface CanvasRenderingContext2D extends CanvasRenderingContext {

  String get font();

  void set font(String value);

  num get globalAlpha();

  void set globalAlpha(num value);

  String get globalCompositeOperation();

  void set globalCompositeOperation(String value);

  String get lineCap();

  void set lineCap(String value);

  String get lineJoin();

  void set lineJoin(String value);

  num get lineWidth();

  void set lineWidth(num value);

  num get miterLimit();

  void set miterLimit(num value);

  num get shadowBlur();

  void set shadowBlur(num value);

  String get shadowColor();

  void set shadowColor(String value);

  num get shadowOffsetX();

  void set shadowOffsetX(num value);

  num get shadowOffsetY();

  void set shadowOffsetY(num value);

  String get textAlign();

  void set textAlign(String value);

  String get textBaseline();

  void set textBaseline(String value);

  void arc(num x, num y, num radius, num startAngle, num endAngle, bool anticlockwise);

  void arcTo(num x1, num y1, num x2, num y2, num radius);

  void beginPath();

  void bezierCurveTo(num cp1x, num cp1y, num cp2x, num cp2y, num x, num y);

  void clearRect(num x, num y, num w, num h);

  void clearShadow();

  void clip();

  void closePath();

  ImageData createImageData(CanvasRenderingContext2D_ImageData_OR_num imagedata_OR_sw, num sh = null);

  CanvasGradient createLinearGradient(num x0, num y0, num x1, num y1);

  CanvasPattern createPattern(CanvasRenderingContext2D_HTMLCanvasElement_OR_HTMLImageElement image, String repetition);

  CanvasGradient createRadialGradient(num x0, num y0, num r0, num x1, num y1, num r1);

  void drawImage(CanvasRenderingContext2D_HTMLCanvasElement_OR_HTMLImageElement image, num dx_OR_sx, num dy_OR_sy, num dw_OR_sw = null, num dh_OR_sh = null, num dx = null, num dy = null, num dw = null, num dh = null);

  void drawImageFromRect(HTMLImageElement image, num sx = null, num sy = null, num sw = null, num sh = null, num dx = null, num dy = null, num dw = null, num dh = null, String compositeOperation = null);

  void fill();

  void fillRect(num x, num y, num w, num h);

  void fillText(String text, num x, num y, num maxWidth = null);

  ImageData getImageData(num sx, num sy, num sw, num sh);

  bool isPointInPath(num x, num y);

  void lineTo(num x, num y);

  TextMetrics measureText(String text);

  void moveTo(num x, num y);

  void putImageData(ImageData imagedata, num dx, num dy, num dirtyX = null, num dirtyY = null, num dirtyWidth = null, num dirtyHeight = null);

  void quadraticCurveTo(num cpx, num cpy, num x, num y);

  void rect(num x, num y, num w, num h);

  void restore();

  void rotate(num angle);

  void save();

  void scale(num x, num y);

  void setAlpha(num alpha);

  void setCompositeOperation(String compositeOperation);

  void setFillColor(CanvasRenderingContext2D_String_OR_num c_OR_color_OR_grayLevel_OR_r, num alpha_OR_g_OR_m = null, num b_OR_y = null, num a_OR_k = null, num a = null);

  void setFillStyle(CanvasRenderingContext2D_CanvasGradient_OR_CanvasPattern_OR_String color_OR_gradient_OR_pattern);

  void setLineCap(String cap);

  void setLineJoin(String join);

  void setLineWidth(num width);

  void setMiterLimit(num limit);

  void setShadow(num width, num height, num blur, CanvasRenderingContext2D_String_OR_num c_OR_color_OR_grayLevel_OR_r = null, num alpha_OR_g_OR_m = null, num b_OR_y = null, num a_OR_k = null, num a = null);

  void setStrokeColor(CanvasRenderingContext2D_String_OR_num c_OR_color_OR_grayLevel_OR_r, num alpha_OR_g_OR_m = null, num b_OR_y = null, num a_OR_k = null, num a = null);

  void setStrokeStyle(CanvasRenderingContext2D_CanvasGradient_OR_CanvasPattern_OR_String color_OR_gradient_OR_pattern);

  void setTransform(num a, num b, num c, num d, num e, num f);

  void stroke();

  void strokeRect(num x, num y, num w_OR_width, num h_OR_height, num lineWidth = null);

  void strokeText(String text, num x, num y, num maxWidth = null);

  void transform(num a, num b, num c, num d, num e, num f);

  void translate(num x, num y);
}

interface CanvasRenderingContext2D_CanvasGradient_OR_CanvasPattern_OR_String {}
interface CanvasGradient extends CanvasRenderingContext2D_CanvasGradient_OR_CanvasPattern_OR_String;
interface CanvasPattern extends CanvasRenderingContext2D_CanvasGradient_OR_CanvasPattern_OR_String;
interface String extends CanvasRenderingContext2D_CanvasGradient_OR_CanvasPattern_OR_String;

interface CanvasRenderingContext2D_HTMLCanvasElement_OR_HTMLImageElement {}
interface HTMLCanvasElement extends CanvasRenderingContext2D_HTMLCanvasElement_OR_HTMLImageElement;
interface HTMLImageElement extends CanvasRenderingContext2D_HTMLCanvasElement_OR_HTMLImageElement;

interface CanvasRenderingContext2D_ImageData_OR_num {}
interface ImageData extends CanvasRenderingContext2D_ImageData_OR_num;
interface num extends CanvasRenderingContext2D_ImageData_OR_num;

interface CanvasRenderingContext2D_String_OR_num {}
interface String extends CanvasRenderingContext2D_String_OR_num;
interface num extends CanvasRenderingContext2D_String_OR_num;
