/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface SQLTransactionErrorCallback {

  bool handleEvent(SQLError error);
}
