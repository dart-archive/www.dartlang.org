// Copyright 2011 Google Inc. All Rights Reserved.

class BenchmarkSuiteObserver {
  BenchmarkSuiteObserver() {}

  void startAllBenchmarks() {}

  void endAllBenchmarks(int score) {}

  void startBenchmarkSuite(BenchmarkSuite suite) {}

  void endBenchmarkSuite(BenchmarkSuite suite, int time, Object error) {}

  void startBenchmark(Benchmark benchmark) {}

  void endBenchmark(BenchmarkResult result) {}

  bool get keepNodes() {
    return false;
  }

  int get minIterations() {
    return 5;
  }
}
