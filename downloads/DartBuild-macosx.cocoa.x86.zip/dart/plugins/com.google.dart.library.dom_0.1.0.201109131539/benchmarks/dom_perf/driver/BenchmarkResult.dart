// Copyright 2011 Google Inc. All Rights Reserved.

// Benchmark results hold the benchmark and the measured time used to run the
// benchmark. The benchmark score is computed later once a full benchmark suite
// has run to completion.
class BenchmarkResult {
  Benchmark benchmark;
  Array<int> times;
  String error;
  String html;
  int nNodes;
  double min;
  double max;
  double mean;
  int median;
  double sdev;
  double score;
  double sum;
  double variance;

  static int countNodes(HTMLElement parent) {
    int nDescendants = 0;
    for (HTMLElement child = parent.firstChild;
         child !== null;
         child = child.nextSibling) {
      nDescendants += countNodes(child);
    }
    return nDescendants + 1;
  }

  void init(Array<int> times, int nNodes, String html) {
    this.nNodes = nNodes;
    this.html = html;
    this.times = times;

    String name = benchmark.name;
    if (times.length == 0) {
      throw 'No results for ${name}';
    }

    Array<int> data = new Array<int>(times.length);
    data.copyFrom(times, 0, 0, times.length);

    // TODO: use generic statistical framework

    int count = data.length;
    // Sort the data so that all seemingly
    // insignificant values such as 0.000000003 will
    // be at the beginning of the array and their
    // contribution to the mean and variance of the
    // data will not be lost because of the precision
    // of the CPU.
    data.sort(sort(x,y) => x.compareTo(y));

    // Since the data is now sorted, the minimum value
    // is at the beginning of the array, the median
    // value is in the middle of the array, and the
    // maximum value is at the end of the array.
    min = data[0].toDouble();
    int middle = (data.length ~/ 2);

    if ((data.length % 2) != 0 || (middle == 0)) {
      median = data[middle];
    } else {
      median = (data[middle - 1] + data[middle]) / 2;
    }

    max = data[data.length - 1].toDouble();

    // Compute the mean and variance using a
    // numerically stable algorithm.
    double sqsum = 0.0;
    mean = data[0].toDouble();
    int nZeros = 0;
    for (int i = 1; i < data.length; ++i) {
      double x = data[i].toDouble();
      double delta = x - mean;
      double sweep = i.toDouble() + 1.0;
      mean += delta / sweep;
      sqsum += delta * delta * (i / sweep);
    }

    sum = mean * count;
    variance = sqsum / count;
    sdev = Math.sqrt(variance);
    score = 1000.0 / mean;
  }

  BenchmarkResult.fromError(this.benchmark, this.error) {
  }

  BenchmarkResult.fromResultAndContent(this.benchmark,
                                       Array<int> times,
                                       HTMLElement benchmarkContent) {
    int nNodes = 0;
    String html = '';
    if (benchmarkContent !== null) {
      nNodes = countNodes(benchmarkContent) - 1;
      if (nNodes > 0) {
        html = benchmarkContent.innerHTML;
      }
    }

    init(times, nNodes, html);
  }

  BenchmarkResult.fromResultAndNodes(this.benchmark,
                                     Array<int> times,
                                     int nNodes,
                                     String html) {
    init(times, nNodes, html);
  }

  String toString() {
    return
      'min: ${min} max: ${max} mean: ${mean} median: ${median} sdev: ${sdev}';
  }
}
