// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//
// DOMDivWalk
// Tests iteration of a DOM tree which is comprised of a hierarchical
// set of div sections.
//
// Two mechanisms are used to iterate the DOM tree:
//    - recursive iteration via Node.children
//    - document.getElementsByTagName
//
// Various tree sizes are tested:
//    - small, medium, and large DOMs
//
// Because this test is run repeatedly on the same DOM tree, the first
// iteration may cause creation of the JS DOM Objects, and subsequent
// iterations will use the cached instance of that JS Object.
//

// These tests try walking over different DOM trees full of divs
// First create a DDWalkTest, using the above values,
// then call GetBenchmark()
// TODO: switch to Dart docs style

class DDWalkTest {
  static final String STYLE_APPEND_DOM = 'DOM';
  static final String STYLE_APPEND_HTML = 'HTML';

  static final String STYLE_TRAVERSE_CHILDREN = 'recurseChildNodes';
  static final String STYLE_TRAVERSE_SIBLINGS = 'recurseSiblings';
  static final String STYLE_TRAVERSE_ELEMENTS = 'getElements';

  String _size;
  String _appendStyle;
  String _traverseStyle;
  int nodesFound;
  String name;
  HTMLElement domTree;

  DDWalkTest(this._size, this._appendStyle, this._traverseStyle) {
    nodesFound = 0;
    name = sizes.length > 1 ? '${size}, ' : '';
    name = name.concat('${_appendStyle}, ${_traverseStyle}');
  }

  void setupDOM() {
    domTree = getDOMTree().cloneNode(true);
    BenchmarkSuite.benchmarkContent.appendChild(domTree);
    nodesFound = 0;
  }

  void setupHTML() {
    BenchmarkSuite.benchmarkContent.innerHTML = getDOMTree().innerHTML;
    nodesFound = 0;
  }

  setup() {
    if (_appendStyle == STYLE_APPEND_DOM) {
      setupDOM();
    } else {
      setupHTML();
    }
  }

  void recurseChildNodes() {
    void walkSubtree(HTMLElement parent, int depth) {
      if (nodesFound == maxNodesFound) {
        return;
      } else {
        if (parent.nodeName == "SPAN" && depth > 0) {
          nodesFound++;
        }

        NodeList children = parent.childNodes;
        int nChildren = children.length;
        while (nChildren-- > 0) {
          HTMLElement child = children[nChildren];
          walkSubtree(child, depth + 1);
        }
      }
    }
    walkSubtree(BenchmarkSuite.benchmarkContent, 0);
  }

  void recurseSiblings() {
    void walkSubtree(HTMLElement parent, int depth) {
      if (nodesFound == maxNodesFound) {
        return;
      } else {
        if (parent.nodeName == "SPAN" && depth > 0) {
          nodesFound++;
        }

        for (var child = parent.firstChild;
             child !== null;
             child = child.nextSibling) {
          walkSubtree(child, depth + 1);
        }
      }
    }
    walkSubtree(BenchmarkSuite.benchmarkContent, 0);
  }

  void getElements() {
    final int kIterations = 10;
    for (int iterations = 0; iterations < kIterations; iterations++) {
      nodesFound = 0;
      Array<Node> items =
          BenchmarkSuite.benchmarkContent.getElementsByTagName("span");
      for (int index = 0, length = items.length; index < length; ++index) {
        HTMLElement item = items[index];
        String nodeName = item.nodeName;
        ++nodesFound;
        if (nodesFound == maxNodesFound) {
          return;
        }
      }
    }
  }

  void test() {
    switch (_traverseStyle) {
      case STYLE_TRAVERSE_CHILDREN:
        recurseChildNodes();
        break;
      case STYLE_TRAVERSE_SIBLINGS:
        recurseSiblings();
        break;
      case STYLE_TRAVERSE_ELEMENTS:
        getElements();
        break;
    }
  }

  void cleanup() {
    int expectedCount = expectedCounts[_size];
    if (nodesFound != expectedCount) {
      throw "Wrong number of nodes found: ${nodesFound} " +
          "expected: ${expectedCount}";
    }
  }

  Benchmark getBenchmark() {
    return new Benchmark(
        name,
        (x) { test(); },
        () => setup(),
        (x) { cleanup(); }
    );
  }

  HTMLElement getDOMTree() {
    HTMLElement domTree = trees[_size];

    if (null == domTree) {
      switch (_size) {
        case BenchmarkSuite.SIZE_SMALL:
          domTree = suite.generateSmallTree();
          break;
        case BenchmarkSuite.SIZE_MEDIUM:
          domTree = suite.generateMediumTree();
          break;
        case BenchmarkSuite.SIZE_LARGE:
          domTree = suite.generateLargeTree();
          break;
      }
      trees[_size] = domTree;
    }
    return domTree;
  }

  static Array<String> sizes;
  static Map<String, HTMLElement> trees;
  static Array<String> appendStyles;
  static Array<String> traverseStyles;
  static Map<String,int> expectedCounts;
  static int maxNodesFound;
  static BenchmarkSuite suite;

  static void main() {
    // Different sizes are possible, but we try to keep the runtime and memory
    // consumption reasonable.
    sizes = [BenchmarkSuite.SIZE_MEDIUM];
    appendStyles = [STYLE_APPEND_DOM, STYLE_APPEND_HTML];
    traverseStyles = [STYLE_TRAVERSE_CHILDREN,
                      STYLE_TRAVERSE_SIBLINGS,
                      STYLE_TRAVERSE_ELEMENTS];
    expectedCounts = {};
    expectedCounts[BenchmarkSuite.SIZE_SMALL]  = 90;
    expectedCounts[BenchmarkSuite.SIZE_MEDIUM] = 2106;
    expectedCounts[BenchmarkSuite.SIZE_LARGE] = 2000;

    trees = {};

    // Limits the number of nodes to this number
    // If we don't do this the tests can take too long to run
    maxNodesFound = 10000;

    // Generate the matrix of all benchmarks
    Array<Benchmark> benchmarks = new Array<Benchmark>();

    sizes.forEach((String size) {
        appendStyles.forEach((String appendStyle) {
            traverseStyles.forEach((String traverseStyle) {
                benchmarks.add(
                    new DDWalkTest(size, appendStyle, traverseStyle).
                         getBenchmark());
            });
        });
    });
    suite = new BenchmarkSuite("DOMDivWalk", benchmarks);
  }
}
