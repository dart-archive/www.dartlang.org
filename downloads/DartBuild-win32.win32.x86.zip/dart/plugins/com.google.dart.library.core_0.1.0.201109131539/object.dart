// Copyright 2011 Google Inc. All Rights Reserved.
// Dart core library.

class Object native "Object" {

  const Object();

  bool operator ==(Object other) {
    return this === other;
  }

  String toString() {
    return "Object";
  }

  /**
   * Return this object without type information.
   */
  get dynamic() { return this; }
}
