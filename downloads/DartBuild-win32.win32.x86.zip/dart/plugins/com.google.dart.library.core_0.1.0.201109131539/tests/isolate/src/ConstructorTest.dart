// Copyright 2011 Google Inc. All Rights Reserved.

class ConstructorTest extends Isolate {
  final int field;
  ConstructorTest() : super(), field = 499;

  void main() {
    this.port.receive((ignoredMessage, reply) {
      reply.send(field, null);
      this.port.close();
    });
  }

  static void testMain() {
    ConstructorTest test = new ConstructorTest();
    test.spawn().then((SendPort port) {
      ReceivePort reply = port.call("ignored");
      reply.receive((message, replyPort) {
        Expect.equals(499, message);
      });
    });
  }
}

main() {
  ConstructorTest.testMain();
}
