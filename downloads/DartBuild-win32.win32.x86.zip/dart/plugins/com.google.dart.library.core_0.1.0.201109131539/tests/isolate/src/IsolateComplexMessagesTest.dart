// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for testing isolate communication with
// complex messages.


class IsolateComplexMessagesTest {

  static void testMain() {
    LogClient.test();
  }
}


// ---------------------------------------------------------------------------
// Log server test.
// ---------------------------------------------------------------------------

class LogClient {
  static void test() {
    new LogIsolate().spawn().then((SendPort remote) {

      remote.send(1, null);
      remote.send("Hello", null);
      remote.send("World", null);
      remote.send(const [null, 1, 2, 3, 4], null);
      remote.send(const [1, 2.0, true, false, 0xffffffffff], null);
      remote.send(const ["Hello", "World", 0xffffffffff], null);
      // Shutdown the LogRunner.
      remote.call(-1).receive((int message, SendPort replyTo) {
        Expect.equals(6, message);
      });
    });
  }
}


class LogIsolate extends Isolate {
  LogIsolate() : super() { }

  void main() {
    println("Starting log server.");

    int count = 0;

    this.port.receive((var message, SendPort replyTo) {
      if (message == -1) {
        this.port.close();
        println("Stopping log server.");
        replyTo.send(count, null);
      } else {
        println("Log ($count) $message");
        switch (count) {
          case 0:
            Expect.equals(1, message);
            break;
          case 1:
            Expect.equals("Hello", message);
            break;
          case 2:
            Expect.equals("World", message);
            break;
          case 3:
            Expect.equals(5, message.length);
            Expect.equals(null, message[0]);
            Expect.equals(1, message[1]);
            Expect.equals(2, message[2]);
            Expect.equals(3, message[3]);
            Expect.equals(4, message[4]);
            break;
          case 4:
            Expect.equals(5, message.length);
            Expect.equals(1, message[0]);
            Expect.equals(2.0, message[1]);
            Expect.equals(true, message[2]);
            Expect.equals(false, message[3]);
            Expect.equals(0xffffffffff, message[4]);
            break;
          case 5:
            Expect.equals(3, message.length);
            Expect.equals("Hello", message[0]);
            Expect.equals("World", message[1]);
            Expect.equals(0xffffffffff, message[2]);
            break;
        }
        count++;
      }
    });
  }
}

main() {
  IsolateComplexMessagesTest.testMain();
}
