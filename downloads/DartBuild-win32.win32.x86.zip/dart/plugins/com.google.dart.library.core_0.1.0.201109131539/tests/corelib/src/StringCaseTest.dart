// Copyright 2011 Google Inc. All Rights Reserved.

class StringCaseTest {

  static testMain() {
    testLowerUpper();
  }

  static testLowerUpper() {
    var a = "Stop! Smell the Roses.";
    var allLower = "stop! smell the roses.";
    var allUpper = "STOP! SMELL THE ROSES.";
    Expect.equals(allUpper, a.toUpperCase());
    Expect.equals(allLower, a.toLowerCase());
  }
}

main() {
  StringCaseTest.testMain();
}
