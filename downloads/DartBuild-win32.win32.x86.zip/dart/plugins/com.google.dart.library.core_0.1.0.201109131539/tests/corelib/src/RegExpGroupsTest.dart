// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test program for RegExp.groups.

class RegExpGroupsTest {
  static testMain() {
    var match = new RegExp("(a(b)((c|de)+))", "").firstMatch("abcde");
    var groups = match.groups([0, 4, 2, 3]);
    Expect.equals('abcde', groups[0]);
    Expect.equals('de', groups[1]);
    Expect.equals('b', groups[2]);
    Expect.equals('cde', groups[3]);
  }
}

main() {
  RegExpGroupsTest.testMain();
}
