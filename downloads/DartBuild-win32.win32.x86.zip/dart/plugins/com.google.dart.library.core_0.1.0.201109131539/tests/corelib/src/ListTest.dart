// Copyright 2011 Google Inc. All Rights Reserved.

class ListTest {

  static testMain() {
    List list = new List();
    checkList(list, 0, 0);

    list.addFirst(1);
    checkList(list, 1, 1);

    list.addLast(10);
    checkList(list, 2, 11);

    Expect.equals(10, list.removeLast());
    checkList(list, 1, 1);

    list.addLast(10);
    Expect.equals(1, list.removeFirst());
    checkList(list, 1, 10);

    list.addFirst(1);
    list.addLast(100);
    list.addLast(1000);
    Expect.equals(1000, list.removeLast());
    list.addLast(1000);
    checkList(list, 4, 1111);

    list.removeFirst();
    checkList(list, 3, 1110);

    bool is10(int value) {
      return (value == 10);
    }

    List other = list.filter(is10);
    checkList(other, 1, 10);

    Expect.equals(true, list.some(is10));

    bool isInstanceOfInt(int value) {
      return (value is int);
    }

    Expect.equals(true, list.every(isInstanceOfInt));

    Expect.equals(false, list.every(is10));

    bool is1(int value) {
      return (value == 1);
    }
    Expect.equals(false, list.some(is1));

    list.clear();
    Expect.equals(0, list.length);

    var exception = null;
    try {
      list.removeFirst();
    } catch (EmptyListException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
    Expect.equals(0, list.length);

    exception = null;
    try {
      list.removeLast();
    } catch (EmptyListException e) {
      exception = e;
    }
    Expect.equals(true, exception != null);
    Expect.equals(0, list.length);

    list.addFirst(1);
    list.addFirst(2);
    Expect.equals(2, list.first());
    Expect.equals(1, list.last());

    list.addLast(3);
    Expect.equals(3, list.last());
    bool isGreaterThanOne(int value) {
      return (value > 1);
    }

    other = list.filter(isGreaterThanOne);
    checkList(other, 2, 5);

    testAddAll();
  }

  static void checkList(List list, int expectedSize, int expectedSum) {
    Expect.equals(expectedSize, list.length);
    int sum = 0;
    void sumElements(int value) {
      sum += value;
    }
    list.forEach(sumElements);
    Expect.equals(expectedSum, sum);
  }

  static testAddAll() {
    Set<int> set = new Set<int>.from([1, 2, 4]);

    List<int> list1 = new List<int>.from(set);
    List<int> list2 = new List<int>();
    List<int> list3 = new List<int>();

    list2.addAll(set);
    list3.addAll(list1);

    Expect.equals(3, set.length);
    Expect.equals(3, list1.length);
    Expect.equals(3, list2.length);
    Expect.equals(3, list3.length);

    int sum = 0;
    void f(e) { sum += e; };

    set.forEach(f);
    Expect.equals(7, sum);
    sum = 0;

    list1.forEach(f);
    Expect.equals(7, sum);
    sum = 0;

    list2.forEach(f);
    Expect.equals(7, sum);
    sum = 0;

    list3.forEach(f);
    Expect.equals(7, sum);
    sum = 0;

    set = new Set<int>.from([]);
    list1 = new List<int>.from(set);
    list2 = new List<int>();
    list3 = new List<int>();

    list2.addAll(set);
    list3.addAll(list1);

    Expect.equals(0, set.length);
    Expect.equals(0, list1.length);
    Expect.equals(0, list2.length);
    Expect.equals(0, list3.length);

    testListElements();
  }

  static testListElements() {
    DoubleLinkedList<int> list1 = new DoubleLinkedList<int>.from([1, 2, 4]);
    DoubleLinkedList<int> list2 = new DoubleLinkedList<int>();
    list2.addAll(list1);

    Expect.equals(list1.length, list2.length);
    DoubleLinkedListEntry<int> entry1 = list1.firstEntry();
    DoubleLinkedListEntry<int> entry2 = list2.firstEntry();
    while (entry1 != null) {
      Expect.equals(true, entry1 !== entry2);
      entry1 = entry1.nextEntry();
      entry2 = entry2.nextEntry();
    }
    Expect.equals(null, entry2);
  }
}

main() {
  ListTest.testMain();
}
