// Copyright 2011 Google Inc. All Rights Reserved.
// Test that an array literal is expandable and modifiable.

class ArrayLiteralTest {

  static void testMain() {
    var array = [1, 2, 3];
    Expect.equals(3, array.length);
    array.add(4);
    Expect.equals(4, array.length);
    array.addAll([5, 6]);
    Expect.equals(6, array.length);
    array[0] = 0;
    Expect.equals(0, array[0]);
  }
}

main() {
  ArrayLiteralTest.testMain();
}
