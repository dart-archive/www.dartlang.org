// Copyright 2011 Google Inc. All Rights Reserved.

class ConstHelper {
  static String getConstId(var o) native;

  static String getConstMapId(Map map) native {
    StringBuffer sb = new StringBuffer();
    sb.add("m");
    bool first = true;
    for (String key in map.getKeys()) {
      if (first) {
        first = false;
      } else {
        sb.add(",");
      }
      sb.add(getConstId(key));
      sb.add(",");
      sb.add(getConstId(map[key]));
    }
    return sb.toString();
  }
}
