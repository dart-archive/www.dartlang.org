// Copyright 2011 Google Inc. All Rights Reserved.

class SendPortImpl implements SendPort {

  void send(var message, SendPort replyTo) {
    if (PromiseQueue.isEmpty()) {
      this._sendNow(message, replyTo);
    } else {
      _enqueueSend(message, replyTo);
    }
  }

  void _enqueueSend(var message, SendPort replyTo) {
    PromiseQueue.enqueue().then((ignored) {
      this._sendNow(message, replyTo);
    });
  }

  void _sendNow(var message, SendPort replyTo) native;

  ReceivePortSingleShotImpl call(var message) {
    final result = new ReceivePortSingleShotImpl();
    this.send(message, result.toSendPort());
    return result;
  }

  ReceivePortSingleShotImpl _callNow(var message) {
    final result = new ReceivePortSingleShotImpl();
    this._sendNow(message, result.toSendPort());
    return result;
  }

  bool operator==(var other) native;

  int hashCode() native;

}


class ReceivePortFactory {

  factory ReceivePort() {
    return new ReceivePortImpl();
  }

  factory ReceivePort.singleShot() {
    return new ReceivePortSingleShotImpl();
  }

}


class ReceivePortImpl implements ReceivePort {

  factory ReceivePortImpl() native;

  void receive(void onMessage(var message, SendPort replyTo)) native;

  void close() native;

  SendPort toSendPort() native;
}


class ReceivePortSingleShotImpl implements ReceivePort {

  ReceivePortSingleShotImpl() : port_ = new ReceivePortImpl() { }

  void receive(void callback(var message, SendPort replyTo)) {
    port_.receive((var message, SendPort replyTo) {
      port_.close();
      callback(message, replyTo);
    });
  }

  void close() {
    port_.close();
  }

  SendPort toSendPort() {
    return port_.toSendPort();
  }

  final ReceivePortImpl port_;

}


class IsolateNatives {
  static SendPort start(Isolate isolate, bool light) native;
  static Function bind(Function f) native;
  static void setExitHandler(void handler()) native;
}


class _IsolateJsUtil {
  static void _promiseQueueProcess() native {
    PromiseQueue.process();
  }

  static void _invokeRun(isolate, port) native {
    isolate._run(port);
  }

  static SendPort _toSendPort(port) native {
    return port.toSendPort();
  }

  static _callJsFun2(jsFun, arg1, arg2) native;

  static void _mapForEach(map, jsFun) native {
    map.forEach((key, value) {
      _callJsFun2(jsFun, key, value);
    });
  }

  static HashMap _newHashMap() native {
    return new HashMap();
  }

  static Map _newMapLiteral() native {
    return new LinkedHashMap();
  }

  static Array _mapKeysAsArray(Map map) native {
    return new Array.from(map.getKeys());
  }

  static int _collectionCount(Collection c) {
    return c.length;
  }

  static void _callDartFun0(void thunk()) native {
    thunk();
  }
}
