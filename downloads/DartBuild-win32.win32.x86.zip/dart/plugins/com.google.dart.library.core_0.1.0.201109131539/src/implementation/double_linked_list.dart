// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * An entry in a doubly linked list. It contains a pointer to the next
 * entry, the previous entry, and the boxed element.
 */
class DoubleLinkedListEntryImplementation<E>
    implements DoubleLinkedListEntry<E> {
  DoubleLinkedListEntryImplementation<E> _previous;
  DoubleLinkedListEntryImplementation<E> _next;
  E _element;

  DoubleLinkedListEntryImplementation(E e) {
    _element = e;
  }

  void _link(DoubleLinkedListEntryImplementation<E> p,
             DoubleLinkedListEntryImplementation<E> n) {
    _next = n;
    _previous = p;
    p._next = this;
    n._previous = this;
  }

  void append(E e) {
    new DoubleLinkedListEntryImplementation<E>(e)._link(this, _next);
  }

  void prepend(E e) {
    new DoubleLinkedListEntryImplementation<E>(e)._link(_previous, this);
  }

  E remove() {
    _previous._next = _next;
    _next._previous = _previous;
    _next = null;
    _previous = null;
    return _element;
  }

  DoubleLinkedListEntry<E> _asNonSentinelEntry() {
    return this;
  }

  DoubleLinkedListEntry<E> previousEntry() {
    return _previous._asNonSentinelEntry();
  }

  DoubleLinkedListEntry<E> nextEntry() {
    return _next._asNonSentinelEntry();
  }

  E get element() {
    return _element;
  }

  void set element(E e) {
    _element = e;
  }
}

/**
 * A sentinel in a double linked list is used to manipulate the list
 * at both ends. A double linked list has exactly one sentinel, which
 * is the only entry when the list is constructed. Initially, a
 * sentinel has its next and previous entry point to itself. A
 * sentinel does not box any user element.
 */
class _ListEntrySentinel<E> extends DoubleLinkedListEntryImplementation<E> {
  _ListEntrySentinel() : super(null) {
    _link(this, this);
  }

  E remove() {
    throw const EmptyListException();
  }

  DoubleLinkedListEntry<E> _asNonSentinelEntry() {
    return null;
  }

  void set element(E e) {
    // This setter is unreachable.
    assert(false);
  }

  E get element() {
    throw const EmptyListException();
  }
}

/**
 * Implementation of a double linked list that box list elements into
 * DoubleLinkedListEntry objects.
 */
class DoubleLinkedListImplementation<E> implements DoubleLinkedList<E> {
  _ListEntrySentinel<E> _sentinel;

  DoubleLinkedListImplementation() {
    _sentinel = new _ListEntrySentinel<E>();
  }

  // TODO(ahe): Bug 5257789.
  factory DoubleLinkedListImplementation/* <E> */.from(Iterable/* <E> */ other) {
    List/* <E> */ list = new DoubleLinkedListImplementation();
    for (final e in other) {
      list.addLast(e);
    }
    return list;
  }

  void addLast(E value) {
    _sentinel.prepend(value);
  }

  void addFirst(E value) {
    _sentinel.append(value);
  }

  void add(E value) {
    addLast(value);
  }

  void addAll(Collection<E> collection) {
    for (final e in collection) {
      add(e);
    }
  }

  E removeLast() {
    return _sentinel._previous.remove();
  }

  E removeFirst() {
    return _sentinel._next.remove();
  }

  E first() {
    return _sentinel._next.element;
  }

  E last() {
    return _sentinel._previous.element;
  }

  DoubleLinkedListEntry<E> lastEntry() {
    return _sentinel.previousEntry();
  }

  DoubleLinkedListEntry<E> firstEntry() {
    return _sentinel.nextEntry();
  }

  int get length() {
    int counter = 0;
    forEach(void _(E element) { counter++; });
    return counter;
  }

  bool isEmpty() {
    return (_sentinel._next === _sentinel);
  }

  void clear() {
    _sentinel._next = _sentinel;
    _sentinel._previous = _sentinel;
  }

  void forEach(void f(E element)) {
    DoubleLinkedListEntryImplementation<E> entry = _sentinel._next;
    while (entry !== _sentinel) {
      f(entry._element);
      entry = entry._next;
    }
  }

  void forEachEntry(void f(DoubleLinkedListEntry<E> element)) {
    DoubleLinkedListEntryImplementation<E> entry = _sentinel._next;
    while (entry !== _sentinel) {
      f(entry);
      entry = entry._next;
    }
  }

  bool every(bool f(E element)) {
    DoubleLinkedListEntryImplementation<E> entry = _sentinel._next;
    while (entry !== _sentinel) {
      if (!f(entry._element)) return false;
      entry = entry._next;
    }
    return true;
  }

  bool some(bool f(E element)) {
    DoubleLinkedListEntryImplementation<E> entry = _sentinel._next;
    while (entry !== _sentinel) {
      if (f(entry._element)) return true;
      entry = entry._next;
    }
    return false;
  }

  DoubleLinkedList<E> filter(bool f(E element)) {
    DoubleLinkedList<E> other = new DoubleLinkedList<E>();
    DoubleLinkedListEntryImplementation<E> entry = _sentinel._next;
    while (entry !== _sentinel) {
      if (f(entry._element)) other.addLast(entry._element);
      entry = entry._next;
    }
    return other;
  }

  _DoubleLinkedListIteratorImplementation<E> iterator() {
    return new _DoubleLinkedListIteratorImplementation<E>(_sentinel);
  }
}

class _DoubleLinkedListIteratorImplementation<E> implements Iterator<E> {
  final _ListEntrySentinel<E> _sentinel;
  DoubleLinkedListEntryImplementation<E> _currentEntry;

  _DoubleLinkedListIteratorImplementation(_ListEntrySentinel this._sentinel) {
    _currentEntry = _sentinel;
  }

  bool hasNext() {
    return _currentEntry._next !== _sentinel;
  }

  E next() {
    if (!hasNext()) {
      throw const NoMoreElementsException();
    }
    _currentEntry = _currentEntry._next;
    return _currentEntry.element;
  }
}
