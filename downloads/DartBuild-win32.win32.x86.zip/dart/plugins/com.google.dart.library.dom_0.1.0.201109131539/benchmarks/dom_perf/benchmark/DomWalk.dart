// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// DOMWalk - a benchmark for walking the DOM
//
// This benchmark tests different mechanisms for touching every element
// in a section of the DOM. The elements are created from Dart causing
// them to be pre-wrapped.
//
// Tests small iterations and large iterations to see if there is a difference.

class DomWalk {
  // We use two mechanisms to walk the DOM, and then
  // verify that both yield the same result.
  static int numNodes;

  // We create a table to iterate as part of this test.
  // For now it's just a big table with lots of elements.
  static HTMLElement createTable(int height, int width) {
    HTMLTableElement table = document.getElementById('fake_dom');
    if (null != table) {
      // Clear out existing table.
      while (table.rows.length > 0) {
        table.deleteRow(0);
      }
    } else {
      table = document.createElement('table');
      table.id = 'fake_dom';
      table.border = '1';

      for (int row = 0; row < height; row++) {
        HTMLElement rowObject = document.createElement('tr');
        for (int column = 0; column < width; column++) {
          HTMLElement colObject = document.createElement('td');
          Text text = document.createTextNode(row.toString() + '.' +
                                              column.toString());
          colObject.appendChild(text);
          rowObject.appendChild(colObject);
        }
        table.appendChild(rowObject);
      }
      HTMLElement content = document.getElementById('benchmark_content');
      content.appendChild(table);
      String html = content.innerHTML;
      int contentWidth = content.clientWidth;
    }
    return table;
  }

  static HTMLElement setupSmall() {
    // Creates a table with 100 nodes.
    return createTable(10, 10);
  }

  static HTMLElement setupLarge() {
    // Creates a table with 4000 nodes.
    return createTable(200, 200);
  }

  // Walks the DOM via getElementsByTagName.
  static int byTagName(HTMLElement table) {
    NodeList items = table.getElementsByTagName('*');
    HTMLElement item;
    int length = items.length;
    for (int index = 0; index < length; index++) {
      item = items[index];
    }

    // Return the number of nodes seen.
    return items.length;
  }

  static void byTagNameDriver(int loops) {
    HTMLElement table = document.getElementById('benchmark_content');
    for (int loop = 0; loop < loops; loop++) {
      numNodes = byTagName(table);
    }
  }

  static void byTagNameSmall() {
    // This test runs in a short time.  We loop a few times in order to avoid
    // small time measurements.
    byTagNameDriver(1000);
  }

  static void byTagNameLarge() {
    // Only iterate once over the large DOM structures.
    byTagNameDriver(1);
  }

  static int recursive(HTMLElement node) {
    // Count Element Nodes only.
    int count = (node.nodeType == Node.ELEMENT_NODE) ? 1 : 0;

    HTMLElement child = node.firstChild;
    while (null != child) {
      count += recursive(child);
      child = child.nextSibling;
    }

    return count;
  }

  // Walks the DOM via a recursive walk.
  static void recursiveDriver(int loops) {
    HTMLElement table = document.getElementById('benchmark_content');
    for (int loop = 0; loop < loops; loop++) {
      int count = recursive(table) - 1;  // don't count the root node.
      if (count != numNodes || count == 0) {
        throw 'DOMWalk failed!  Expected ${numNodes} nodes but '+
            'found ${count}.';
      }
    }
  }

  static void recursiveSmall() {
    // This test runs in a short time.  We loop a few times in order to avoid
    // small time measurements.
    recursiveDriver(200);
  }

  static void recursiveLarge() {
    // Only iterate once over the large DOM structures.
    recursiveDriver(1);
  }

  static void main() {
    numNodes = 0;

    new BenchmarkSuite('DOMWalk', [
        new Benchmark('DOMWalkByTag (100 nodes)',
                      (x) { byTagNameSmall(); },
                      () => setupSmall()),
        new Benchmark('DOMWalkRecursive (100 nodes)',
                      (x) { recursiveSmall(); },
                      () => setupSmall()),
        new Benchmark('DOMWalkByTag (4000 nodes)',
                      (x) { byTagNameLarge(); },
                      () => setupLarge()),
        new Benchmark('DOMWalkRecursive (4000 nodes)',
                      (x) { recursiveLarge(); },
                      () => setupLarge())
    ]);
  }
}
