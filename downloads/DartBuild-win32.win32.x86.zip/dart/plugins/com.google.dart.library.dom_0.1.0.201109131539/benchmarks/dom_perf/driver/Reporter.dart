// Copyright 2011 Google Inc. All Rights Reserved.

class Reporter extends BenchmarkSuiteObserver {
  static bool submitReport;
  static String reportTags;
  static String reportUrl;

  Map<String, Object> currentSuite;
  Array<Map<String, Object>> stats;

  Reporter() : super() {
    reportTags = '';
  }

  void report(int score) {
    Env.log('total score is ${score}');

    if (DomBenchmark.isGolemRun) {
        // Prepare flattened version.
        Map<String, num> results = new Map<String, num>();
        for (Map<String, Object> suite in stats) {
            Array<Map<String, Object>> benches = suite['Benchmarks'];
            for (Map<String, Object> b in benches) {
                results[b['name']] = b['score'];
            }
        }
        final String data = BenchUtil.formatGolemData("DomPerf", results);
        // And report it to the Golem.
        window.location.assign('../return?${data}');
    } else {
        Env.log(BenchUtil.serialize(stats));
    }
  }

  void startAllBenchmarks() {
    stats = new Array<Map<String, Object>>();
  }

  void endAllBenchmarks(int time) {
    report(time);
  }

  void startBenchmarkSuite(BenchmarkSuite suite) {
    currentSuite = new Map<String, Object>();
    currentSuite['name'] = suite.name;
    currentSuite['Benchmarks'] = new Array<Map<String,Object>>();
    stats.add(currentSuite);
  }

  void endBenchmarkSuite(BenchmarkSuite suite, int time, Object error) {
    currentSuite['score'] = time != null ? time : 0;
  }

  void endBenchmark(BenchmarkResult result) {
    Map<String,Object> benchmark = new Map<String,String>();
    benchmark['name'] = result.benchmark.name;
    benchmark['min'] = result.min;
    benchmark['max'] = result.max;
    benchmark['mean'] = result.mean;
    benchmark['median'] = result.median;
    benchmark['score'] = result.score;
    benchmark['runs'] = result.times.length;

    currentSuite['Benchmarks'].dynamic.add(benchmark);
  }
}
