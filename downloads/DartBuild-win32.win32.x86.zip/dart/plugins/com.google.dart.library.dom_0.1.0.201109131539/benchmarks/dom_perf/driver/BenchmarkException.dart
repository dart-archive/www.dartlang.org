// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//
class BenchmarkException {
  final String _message;
  final String _bench;

  BenchmarkException(this._message, this._bench) {
  }

  String toString() {
    return _bench + ': ' + _message;
  }
}
