/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface MediaStreamTrack {

  bool get enabled();

  void set enabled(bool value);

  String get kind();

  String get label();
}
