/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface TouchEvent extends UIEvent {

  bool get altKey();

  TouchList get changedTouches();

  bool get ctrlKey();

  bool get metaKey();

  bool get shiftKey();

  TouchList get targetTouches();

  TouchList get touches();

  void initTouchEvent(TouchList touches = null, TouchList targetTouches = null, TouchList changedTouches = null, String type = null, DOMWindow view = null, int screenX = null, int screenY = null, int clientX = null, int clientY = null, bool ctrlKey = null, bool altKey = null, bool shiftKey = null, bool metaKey = null);
}
