/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLCollection extends Array<Node> {

  int get length();

  Node item(int index);

  Node namedItem(String name = null);
}
