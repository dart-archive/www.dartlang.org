/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface CanvasPixelArray extends Array<int> {

  int get length();

  int item(int index);
}
