/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLStyleElement extends HTMLElement /*, common.LinkStyle */ {

  bool get disabled();

  void set disabled(bool value);

  String get media();

  void set media(String value);

  StyleSheet get sheet();

  String get type();

  void set type(String value);
}
