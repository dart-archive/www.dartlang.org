/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLTitleElement extends HTMLElement {

  String get text();

  void set text(String value);
}
