/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface StorageInfo {

  static final int PERSISTENT = 1;

  static final int TEMPORARY = 0;

  void queryUsageAndQuota(int storageType, StorageInfoUsageCallback usageCallback = null, StorageInfoErrorCallback errorCallback = null);

  void requestQuota(int storageType, int newQuotaInBytes, StorageInfoQuotaCallback quotaCallback = null, StorageInfoErrorCallback errorCallback = null);
}
