/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLLIElement extends HTMLElement {

  String get type();

  void set type(String value);

  int get value();

  void set value(int value);
}
