/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface InspectorFrontendHost {

  void bringToFront();

  void closeWindow();

  void copyText(String text);

  void disconnectFromBackend();

  String hiddenPanels();

  void inspectedURLChanged(String newURL);

  void loaded();

  String localizedStringsURL();

  void moveWindowBy(num x, num y);

  String platform();

  String port();

  void recordActionTaken(int actionCode);

  void recordPanelShown(int panelCode);

  void recordSettingChanged(int settingChanged);

  void requestAttachWindow();

  void requestDetachWindow();

  void saveAs(String fileName, String content);

  void sendMessageToBackend(String message);

  void setAttachedWindowHeight(int height);

  void setExtensionAPI(String script);

  void showContextMenu(MouseEvent event, Object items);
}
