/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface MediaQueryList {

  bool get matches();

  String get media();

  void addListener(MediaQueryListListener listener = null);

  void removeListener(MediaQueryListListener listener = null);
}
