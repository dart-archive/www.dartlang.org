/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface ProcessingInstruction extends Node /*, common.LinkStyle */ {

  String get data();

  void set data(String value);

  StyleSheet get sheet();

  String get target();
}
