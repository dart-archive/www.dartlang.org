// Copyright 2011 Google Inc. All Rights Reserved.

class IFrameObserver extends BenchmarkSuiteObserver {
  DOMWindow target;
  bool _keepNodes;

  // TODO: use keepNodes when we can serialize arbitrary strings.
  IFrameObserver(this.target, bool keepNodes) :
     super(), this._keepNodes = false {
  }

  void startAllBenchmarks() {
  }

  void endAllBenchmarks(int score) {
  }

  void startBenchmarkSuite(BenchmarkSuite suite) {
    Env.postMessage(target, BenchUtil.serialize({
        'cmd': 'suite_start',
        'suite': BenchmarkSuite.iSuite
    }));
  }

  void endBenchmarkSuite(BenchmarkSuite suite, int time, Object error) {
    Env.postMessage(target, BenchUtil.serialize({
        'cmd': 'suite_end',
        'suite': BenchmarkSuite.iSuite,
        'time': null != time ? time : 0,
        'error': null != error ? error : ''
    }));
  }

  void startBenchmark(Benchmark benchmark) {
    Env.postMessage(target, BenchUtil.serialize({
        'cmd': 'benchmark_start',
        'suite': BenchmarkSuite.iSuite,
        'benchmark': BenchmarkSuite.iBenchmark
    }));
  }

  void endBenchmark(BenchmarkResult result) {
    Map<String, Object> msg = {
        'cmd': 'benchmark_end',
        'suite': BenchmarkSuite.iSuite,
        'benchmark': BenchmarkSuite.iBenchmark,
        'results': result.times === null ? 0 : result.times.length
        };

    if (result.times !== null) {
      for (int i = 0; i < result.times.length; i++) {
        msg['times${i}'] = result.times[i];
      }
    }

    if (result.error !== null) {
      msg['error'] = result.error;
    } else {
      if (_keepNodes) {
        msg['nodes'] = result.nNodes;
        msg['nodesHtml'] = result.html;
      } else {
        msg['nodes'] = 0;
        msg['nodesHtml'] = '';
      }
    }

    Env.postMessage(target, BenchUtil.serialize(msg));
  }

  bool get keepNodes() {
    return _keepNodes;
  }
}

class IFrameDomPerf {
  static DOMWindow parent;

  static void main() {
    Env.addListener((event) {
      iframeEventProcessor(event);
    });

    window.onload = (event) {
      BenchmarkSuite.loadAllSuites(true);
      runIFrame();
    };
  }

  static runFromIFrame(BenchmarkSuite oldSuite,
                       BenchmarkSuite newSuite,
                       HTMLElement benchmarkContentHolder,
                       Object benchmarkContent,
                       DOMWindow window,
                       bool keepNodes) {
    int nBenchmarks = oldSuite.benchmarks.length;

    BenchmarkSuite.benchmarkContentHolder = benchmarkContentHolder;
    benchmarkContentHolder.removeChild(benchmarkContent);
    BenchmarkSuite.benchmarkContentOrig = benchmarkContent;
    BenchmarkSuite.runner = new IFrameObserver(window.parent, keepNodes);
    newSuite.runWindow = window;

    Env.later(() { BenchmarkSuite.runNextBenchmark(); });
  }


  static void runIFrame() {
    parent = window.parent;

    Env.postMessage(parent, BenchUtil.serialize({'cmd': 'iframe_ready'}));
  }

  static void iframeEventProcessor(var event) {
    Map<String, Object> msg = BenchUtil.deserialize(event.data);
    String cmd = msg['cmd'];

    if (cmd == 'run_suite') {
      int iSuite = msg['suite'];
      bool keepNodes = msg['keep_nodes'] == 1;

      BenchmarkSuite newSuite = BenchmarkSuite.suites[0];
      BenchmarkSuite oldSuite = BenchmarkSuite.suites[iSuite];

      HTMLElement benchmarkContentHolder = Env.byId('benchmark_content_holder');
      HTMLElement benchmarkContent = Env.byId('benchmark_content');

      BenchmarkSuite.iSuite = iSuite;
      BenchmarkSuite.iBenchmark = 0;
      BenchmarkSuite.runningSuite = BenchmarkSuite.suites[iSuite];

      Env.later(() {
          runFromIFrame(oldSuite, newSuite,
                        benchmarkContentHolder,
                        benchmarkContent,
                        window,
                        keepNodes);
      });
    }
  }
}
