// Copyright 2011 Google Inc. All Rights Reserved.

typedef Object SetupFn();
typedef Object RunFn(Object);
typedef void CleanupFn(Object);

class Benchmark {
  final String name;
  final int timeToRunInMs;
  final RunFn run;
  final SetupFn setup;
  final CleanupFn cleanup;
  final bool shareSetup;

  BenchmarkSuite suite;
  HTMLInputElement check;
  HTMLTableRowElement row;
  bool enabled;

  Benchmark(String name,
            RunFn run,
            SetupFn setup = null,
            CleanupFn cleanup = null,
            bool shareSetup = false)
     : name = name,
       timeToRunInMs = 500,
       run = run,
       setup = setup,
       cleanup = cleanup,
       shareSetup = shareSetup,
       enabled = true {}
}
