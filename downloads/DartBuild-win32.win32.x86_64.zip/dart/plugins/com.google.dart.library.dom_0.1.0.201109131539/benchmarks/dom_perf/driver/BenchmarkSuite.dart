// Copyright 2011 Google Inc. All Rights Reserved.

class BenchmarkSuite {
  String name;
  Array<Benchmark> benchmarks;
  HTMLElement check;
  var row;
  var cell;
  DOMWindow runWindow;
  Array<double> results;
  bool running;

  static BenchmarkSuiteObserver runner;
  static Date start;
  static Array<BenchmarkSuite> _suites;
  static BenchmarkSuite runningSuite;
  static final String version = '1';
  static int iSuite;
  static int iBenchmark;
  static HTMLIFrameElement iFrame;
  static HTMLElement benchmarkContentOrig;
  static HTMLElement benchmarkContent;
  static HTMLElement benchmarkContentHolder;
  static Array<int> reuseTimes;
  static Array<num> scores;

  BenchmarkSuite(this.name, this.benchmarks) :
    this.results = new Array<double>() {

    for (int i = 0; i < benchmarks.length; i++) {
      benchmarks[i].suite = this;
    }

    suites.add(this);
  }

  static Array<BenchmarkSuite> get suites() {
    if (_suites === null) {
      _suites = new Array<BenchmarkSuite>();
    }
    return _suites;
  }

  static void setBenchmarkContent(HTMLElement content) {
    benchmarkContentHolder = content.parentNode;
    benchmarkContentHolder.removeChild(content);
    benchmarkContentOrig = content;
  }

  static void runSuites(BenchmarkSuiteObserver _runner) {
    scores = new Array<num>();
    runner = _runner;
    iSuite = 0;
    iBenchmark = 0;
    runner.startAllBenchmarks();
    Env.later(() { runNextSuite(); }, 100);
  }

  static BenchmarkSuite findSuiteByCheck(HTMLElement check) {
    BenchmarkSuite result = null;
    suites.forEach((BenchmarkSuite suite) {
      if (suite.check === check) {
        result = suite;
      }
    });
    return result;
  }

  static Benchmark findBenchByCheck(HTMLElement check) {
    Benchmark result = null;
    suites.forEach((BenchmarkSuite suite) {
      suite.benchmarks.forEach((Benchmark bench) {
        if (bench.check === check) {
          result = bench;
        }
      });
    });
    return result;
  }

  static void runNextSuite() {
    if (iSuite < suites.length) {
      BenchmarkSuite suite = suites[iSuite];
      iBenchmark = 0;
      runner.startBenchmarkSuite(suite);
      iFrame = document.createElement('iframe');
      iFrame.src = 'runFromIFrame.html';
      benchmarkContentHolder.appendChild(iFrame);
    } else {
      if (scores.length > 0) {
        runner.endAllBenchmarks(
            Math2.round(Math2.geometricMean(scores)));
      } else {
        runner.endAllBenchmarks(0);
      }
      runner = null;
    }
  }

  // Counts the total number of registered benchmarks.
  // Useful for showing progress as a percentage.
  static int countBenchmarks() {
    int  result = 0;
    suites.forEach((suite) {
      suite.benchmarks.forEach((benchmark) {
        if (benchmark.enabled) {
          result++;
        }
      });
    });
    return result;
  }

  static void runNextBenchmark() {
     BenchmarkSuite suite = runningSuite;

     for (; iBenchmark < suite.benchmarks.length; iBenchmark++) {
       if (suite.benchmarks[iBenchmark].enabled) {
         break;
       }
     }

     if (iBenchmark < suite.benchmarks.length) {
       Benchmark benchmark = suite.benchmarks[iBenchmark];
       Array<int> times = reuseTimes !== null ?
           reuseTimes
           :
           new Array<int>();
       BenchmarkResult result = suite.runSingle(benchmark, times);

       if (result.error !== null || times.length >= runner.minIterations) {
         runner.endBenchmark(result);
         if (result.error === null) {
           suite.results.add(result.score);
         }
         reuseTimes = null;
         iBenchmark++;
       } else {
         reuseTimes = times;
       }
       Env.later(() { runNextBenchmark(); }, 10);
     } else {
       if (suite.results.length > 0) {
         double mean = Math2.geometricMean(suite.results);
         runner.endBenchmarkSuite(suite, Math2.round(mean), null);
       } else {
         runner.endBenchmarkSuite(suite, 0, "No results");
       }
       suite.running = false;
     }
  }

  // Runs a single benchmark and computes the average time it takes to run a
  // single iteration.
  BenchmarkResult runSingle(Benchmark benchmark,
                            Array<int> times) {
    int elapsed = 0;
    int start = BenchUtil.now;
    Interval runInterval = new Interval();
    var setupReturn = null;
    var runReturn = null;
    int time;
    int totalTime = 0;
    int nZeros = 0;
    Object error = null;
    Profiler profiler = Env.profiler;

    for (int n = 0; null == error && totalTime < benchmark.timeToRunInMs;  n++) {
      if (benchmarkContent !== null) {
        benchmarkContentHolder.removeChild(benchmarkContent);
      }

      benchmarkContent = benchmarkContentOrig.cloneNode(true);
      benchmarkContentHolder.appendChild(benchmarkContent);

      try {
        if (benchmark.setup !== null) {
          if (setupReturn === null || !benchmark.shareSetup) {
            setupReturn = (benchmark.setup)();
          }
        }
        profiler.start();
        runInterval.start();
        runReturn = (benchmark.run)(setupReturn);
        runInterval.stop();
        profiler.stop();

        time = runInterval.elapsedMillisec;
        if (time > 0) {
          times.add(time);
          elapsed += time;
        } else {
          times.add(0);
        }

        if (benchmark.cleanup !== null) {
          (benchmark.cleanup)(runReturn);
        }

      } catch (var e) {
        error = e;
        Env.log(e);
      }
      totalTime = BenchUtil.now - start;
    }

    HTMLElement content = runner.keepNodes ? benchmarkContent : null;
    BenchmarkResult result = error ?
        new BenchmarkResult.fromError(benchmark, error) :
        new BenchmarkResult.fromResultAndContent(benchmark, times, content);

    if (benchmarkContent !== null) {
      benchmarkContentHolder.removeChild(benchmarkContent);
      benchmarkContent = null;
    }
    return result;
  }

  void _generateTree(HTMLElement parent, int width, int depth) {
    String id = parent.id;

    if (depth !== 0) {
      int middle = width ~/ 2;
      for (int i = 0; i < width; i++) {
        if (i == middle) {
          HTMLElement divNode = document.createElement("div");
          // TODO:[dave] this causes us to have potentially very long
          // ids. We might want to encode these values into a smaller string
          divNode.id = "${id}:(${i}, 0)";
          parent.appendChild(divNode);
          _generateTree(divNode, width, depth - 1);
        } else {
          HTMLElement p = parent;
          for (int j = 0; j < i; j++) {
            HTMLElement divNode = document.createElement("div");
            divNode.id = "${id}:(${i},${j})";
            p.appendChild(divNode);
            p = divNode;
          }
          HTMLElement span = document.createElement("span");
          span.appendChild(document.createTextNode(p.id));
          p.appendChild(span);
        }
      }
    }
  }

  // Generates a DOM tree (doesn't insert it into the document).
  // The width and depth arguments help shape the "bushiness"
  // of the full tree. The approach is to recursively generate
  // a set of subtrees. At each root we generate width trees,
  // of increasing depth, from 1 to width.  Then we recurse
  // from the middle child of this subtree. We do this up to depth times.
  // reps allows us to duplicate a set of trees,
  // without additional recursions.
  HTMLElement generateDOMTree(int width, int depth, int reps) {
    HTMLElement top = document.createElement("div");
    top.id = "test";
    for (int i = 0; i < reps; i++) {
      HTMLElement divNode = document.createElement("div");
      divNode.id = "test${i}";
      _generateTree(divNode, width, depth);
      top.appendChild(divNode);
    }
    return top;
  }

  static final String SIZE_SMALL = 'small';
  static final String SIZE_MEDIUM = 'medium';
  static final String SIZE_LARGE = 'large';

  // Generate a small sized tree.
  // 92 span leaves, max depth: 23, avg depth: 14.
  HTMLElement generateSmallTree() {
    return generateDOMTree(14, 12, 10);
  }

  // Generate a medium sized tree.
  // 1320 span leaves, max depth: 27, avg depth: 16.
  HTMLElement generateMediumTree() {
    return generateDOMTree(19, 13, 9);
  }

  // Generate a large sized tree.
  // 2600 span leaves, max depth: 55, avg depth: 30.
  HTMLElement generateLargeTree() {
    return generateDOMTree(26, 26, 4);
  }

  static void loadAllSuites(bool inFrame) {
    // Load all known benchmarks.
    Accessors.main();
    CloneNodes.main();
    CreateNodes.main();
    DDWalkTest.main();
    DomTable.main();
    DomWalk.main();
    Events.main();
    GetElement.main();
    GridSort.main();

    if (!inFrame) {
      DomBenchmark.load();
    }
  }
}
