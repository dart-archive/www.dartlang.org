// Copyright 2011 Google Inc. All Rights Reserved.

class DomPerf {
  static void main() {
    Env.addListener((MessageEvent event) {
      mainEventProcessor(event);
    });

    Env.whenLoaded(() {
      Env.byId("statusProgress_button").onclick = (event) { run(); };
      BenchmarkSuite.loadAllSuites(false);
      run();
    });
  }

  static void mainEventProcessor(MessageEvent event) {
    Map<String, Object> msg = BenchUtil.deserialize(event.data);
    String cmd = msg['cmd'];

    switch (cmd) {
      case 'iframe_ready':
        Env.postMessage(BenchmarkSuite.iFrame.contentWindow,
                        BenchUtil.serialize({
                            'cmd': 'run_suite',
                            'suite': BenchmarkSuite.iSuite,
                            'keep_nodes':
                              benchmarkRunner.keepNodes ? 1 : 0
                            }));
        break;

      case 'suite_start':
        int iSuite = msg['suite'];
        benchmarkRunner.startBenchmarkSuite(BenchmarkSuite.suites[iSuite]);
        break;

      case 'suite_end':
        int iSuite = msg['suite'];
        int score = msg['time'];

        benchmarkRunner.endBenchmarkSuite(BenchmarkSuite.suites[iSuite],
                                          score,
                                          msg['error']);
        BenchmarkSuite.scores.add(score);
        BenchmarkSuite.benchmarkContentHolder.
            removeChild(BenchmarkSuite.iFrame);
        Env.later(() {
          BenchmarkSuite.iSuite++;
          BenchmarkSuite.runNextSuite();
        });
        break;

      case 'benchmark_start':
        int iSuite = msg['suite'];
        int iBenchmark = msg['benchmark'];
        benchmarkRunner.startBenchmark(
            BenchmarkSuite.suites[iSuite].benchmarks[iBenchmark]);
        break;

      case 'benchmark_end':
        int iSuite = msg['suite'];
        int iBenchmark = msg['benchmark'];

        String error = msg['error'];
        BenchmarkResult result;
        Benchmark benchmark =
            BenchmarkSuite.suites[iSuite].benchmarks[iBenchmark];

        if (null != error) {
          result = new BenchmarkResult.fromError(benchmark, error);
        } else {
          Array<int> times = new Array<int>();
          int results = msg['results'];
          for (int i = 0; i < results; i++) {
            times.add(msg["times${i}"]);
          }

          result = new BenchmarkResult.fromResultAndNodes(
              benchmark,
              times,
              msg['nodes'],
              msg['nodesHtml']);
        }
        benchmarkRunner.endBenchmark(result);
        break;
      default:
        throw 'Unknown command: ${cmd}';
    }
  }

  static void run() {
    benchmarkRunner = new DomBenchmark(new Reporter());
    DomBenchmark.run(benchmarkRunner);
  }

  static DomBenchmark benchmarkRunner;
  static Reporter reporter;
}
