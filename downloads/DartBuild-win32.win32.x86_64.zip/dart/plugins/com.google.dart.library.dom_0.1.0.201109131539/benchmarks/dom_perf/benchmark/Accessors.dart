// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Accessors - measure access get/set properties on various objects.

// Accessors are generally pretty quick.  We loop on each accessor
// many times in order to crank up the time of the microbenchmark
// so that measurements are more substantial.  Values were chosen
// to make Firefox3 performance land in the 100-300ms range.

class Accessors {
  static final int BIG_COUNT = 1500000;
  static final int LITTLE_COUNT = 300000;
  static final int TINY_COUNT = 30000;
  static final int VERY_TINY_COUNT = 5000;

  static void windowGet() {
    final int nLoops = LITTLE_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      window.length;
    }
  }

  static void windowSet() {
    final int nLoops = BIG_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      window.name = "title";
    }
  }

  // Following 2 tests do not work in original form, as
  // we don't have implicit root object yet.
  static void rootGetModified() {
    final int nLoops = LITTLE_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      // TODO: write me correctly
      document.title;
    }
  }

  static void rootSetModified() {
    int nLoops = LITTLE_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      // TODO: write me correctly
      document.title = "name";
    }
  }

  static void documentGet() {
    final int nLoops = LITTLE_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      document.nodeType;
    }
  }

  static void documentSet() {
    final int nLoops = VERY_TINY_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      document.title = "name";
    }
  }

  static HTMLElement domObjectSetup() {
    HTMLElement o1 = document.createElement('span');
    HTMLElement o2 = document.createElement('span');
    o1.appendChild(o2);
    BenchmarkSuite.benchmarkContent.appendChild(o1);
    return o1;
  }

  static void domObjectGet(var o1) {
    final int nLoops = LITTLE_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      o1.nodeType;
    }
  }

  static void domObjectSet(var o1) {
    final int nLoops = LITTLE_COUNT;
    String title = "title";
    for (int loop = 0; loop < nLoops; loop++) {
      o1.title = title;
    }
  }

  static Array nodeListSetup() {
    HTMLElement o1 = document.createElement('span');
    HTMLElement o2 = document.createElement('span');
    o1.appendChild(o2);
    BenchmarkSuite.benchmarkContent.appendChild(o1);
    return o1.childNodes;
  }

  static void nodeListGet(var o1) {
    final int nLoops = LITTLE_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      o1.length;
    }
  }

  static HTMLElement cssSetup() {
    HTMLElement span = document.createElement('span');
    span.appendChild(document.createTextNode('test'));
    span.style.setProperty('font-weight', 'bold', '');
    BenchmarkSuite.benchmarkContent.appendChild(span);
    return span;
  }

  static void cssGet(var span) {
    final int nLoops = LITTLE_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      span.style.getPropertyValue("font-weight");
    }
  }

  static void cssSet(var span) {
    final int nLoops = TINY_COUNT;
    for (int loop = 0; loop < nLoops; loop++) {
      span.style.setProperty('font-weight', 'bold', '');
    }
  }

  static DOMWindow window;
  static Document document;
  static BenchmarkSuite suite;

  static void main() {
    suite = new BenchmarkSuite('Accessors', [
        new Benchmark('CSS Style Get',
                      (x) { cssGet(x); },
                      () => cssSetup()),
        new Benchmark('CSS Style Set',
                      (x) { cssSet(x); },
                      () => cssSetup()),
        new Benchmark('Document Get NodeType',
                      (x) { documentGet(); }),
        new Benchmark('Document Set Title',
                      (x) { documentSet(); }),
        new Benchmark('Nodelist Get Length',
                      (x) { nodeListGet(x); },
                      () => nodeListSetup()),
        new Benchmark('Span Get NodeType',
                      (x) { domObjectGet(x); },
                      () => domObjectSetup()),
        new Benchmark('Span Set Title',
                      (x) { domObjectSet(x); },
                      () => domObjectSetup()),
        new Benchmark('Root Get Length (modified)',
                      (x) { rootGetModified(); }),
        new Benchmark('Root Set Title (modified)',
                      (x) { rootSetModified(); }),
        new Benchmark('Window Get Length',
                      (x) { windowGet(); }),
        new Benchmark('Window Set Name',
                      (x) { windowSet(); })
    ]);
  }
}
