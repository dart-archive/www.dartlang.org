// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//
// Events test - test the hooking and dispatch of events.
//
// This is a fairly simple test for measuring event peformance.
// We create a DOM structure (a set of nested divs) to test with.
//
// The Hooking test measures the time to register onclick handlers for
// each node in the structure.  This simulates conditions where applications
// register event handlers on many nodes programatically.
//
// The Dispatch test measures the time to dispatch events to each node
// in the structure.  In this case, we register the event handler as part
// of the HTML for the structure, and then simply simulate onclick events
// to each node.
//

class EventsTest {
  int rows;
  int cols;
  int cellCount;
  Array<Array> proxies; // Contains tuples (handle, column).
  Array<String> randomIds;

  EventsTest(this.rows, this.cols) :
    cellCount = 0, // Track the number of cells created in our dom tree.
    proxies = new Array<Array>(),
    randomIds = new Array<String>() {
  }

  // Create a DOM structure and optionally register event handlers on
  // each node. Create the structure by setting innerHTML so that the
  // DOM nodes are not pre-wrapped for Dart access.
  String createTableOrig(bool addEventListeners) {
    String htmlString = '<div>';
    for (int i = 0; i < rows; i++) {
      htmlString += createRowOrig(i, cols, addEventListeners);
    }
    return htmlString + '</div>';
  }

  HTMLElement createTable(bool addEventListeners) {
    HTMLElement table = document.createElement('div');
    for (int i = 0; i < rows; i++) {
      table.appendChild(createRow(i, cols, addEventListeners));
    }
    return table;
  }

  // Returns an html string for a div with a row/column based id, with an
  // optional onclick handler.
  String createCellOrig(int rowId, int colId, bool addEventListeners) {
    String str = '<div id="r${rowId}c${colId}"';
    if (addEventListeners) {
      str += ' onclick="Events.eventClickHandler();"';
    }
    str += '>${cellCount}</div>';
    cellCount++;
    return str;
  }

  HTMLElement createCell(int rowId, int colId, bool addEventListeners) {
    HTMLTableElement div = document.createElement('div');
    div.id = 'r${rowId}c${colId}';
    if (addEventListeners) {
      div.addEventListener('click', (e) { Events.eventClickHandler(); }, false);
    }
    div.innerHTML = '${cellCount}';
    cellCount++;
    return div;
  }

  // Returns an html string with an outer div containing [cols] inner divs,
  // optionally having an onclick handler.
  String createRowOrig(int rowId, int cols, bool addEventListeners) {
    String htmlString = '<div id="r${rowId}">';
    for (int i = 0; i < cols; i++) {
      htmlString += createCell(rowId, i, addEventListeners);
    }
    return htmlString + '</div>';
  }

  HTMLElement createRow(int rowId, int cols, bool addEventListeners) {
    HTMLElement div = document.createElement('div');
    div.id = 'r${rowId}';
    for (int i = 0; i < cols; i++) {
      div.appendChild(createCell(rowId, i, addEventListeners));
    }
    return div;
  }

  // Prepares for testing with elements that have no pre-defined onclick
  // handlers.
  HTMLElement setupOrig() {
    cellCount = 0;
    Events.counter = 0;
    HTMLElement rootElement = document.getElementById('benchmark_content');
    rootElement.innerHTML = createTableOrig(false);
    return rootElement;
  }

  HTMLElement setup() {
    cellCount = 0;
    Events.counter = 0;
    HTMLElement rootElement = document.getElementById('benchmark_content');
    rootElement.appendChild(createTable(false));
    return rootElement;
  }

  // Similar to Setup, but with onclick handlers already defined in the html.
  HTMLElement setupWithListenersOrig() {
    cellCount = 0;
    Events.counter = 0;
    HTMLElement rootElement = document.getElementById('benchmark_content');
    rootElement.innerHTML = createTableOrig(true);
    return rootElement;
  }

  // Similar to Setup, but with onclick handlers already defined in the html.
  HTMLElement setupWithListeners() {
    cellCount = 0;
    Events.counter = 0;
    HTMLElement rootElement = document.getElementById('benchmark_content');
    rootElement.appendChild(createTable(true));
    return rootElement;
  }

  // Sets up for testing performance of removing event handlers.
  void setupForTeardown() {
    randomIds = new Array<String>();
    setupWithListeners();
    Array<String> tmp = new Array<String>();
    for (int row = 0; row < rows; row++) {
      for (int col = 0; col < cols; col++) {
        randomIds.add('r${row}c${col}');
      }
    }
    BenchUtil.shuffle(randomIds);
  }

  void hookTest() {
    int nodeCount = 0;
    int rowId = 0;

    while (true) {
      HTMLElement row = document.getElementById('r${rowId}');
      if (null == row) {
        break;
      }

      int colId = 0;

      while (true) {
        HTMLElement col = document.getElementById('r${rowId}c${colId}');
        if (null == col) {
          break;
        }
        col.addEventListener('click', Events.eventClickHandlerFn, false);
        colId++;
        nodeCount++;
      }
      rowId++;
    }

    if (nodeCount != rows * cols) {
      throw 'ERROR - did not iterate all nodes';
    }
  }

  void hookTestProxy() {
    int nodeCount = 0;

    int rowId = 0;
    while (true) {
      HTMLElement row = document.getElementById('r${rowId}');
      if (null == row) {
        break;
      }

      int colId = 0;
      while (true) {
        HTMLElement col = document.getElementById('r${rowId}c${colId}');
        if (null == col) {
          break;
        }

        Function proxy = () {};
        proxies.add([proxy, col]);
        col.addEventListener('click', proxy, false);
        colId++;
        nodeCount++;
      }

      rowId++;
    }

    if (nodeCount != rows * cols) {
      throw 'ERROR - did not iterate all nodes';
    }
  }

  // Tests firing the events for each element in our dom.
  void dispatchTest() {
    int nodeCount = 0;

    int rowId = 0;
    while (true) {
      HTMLElement row = document.getElementById('r${rowId}');
      if (null == row) {
        break;
      }

      int colId = 0;
      while (true) {
        HTMLElement col = document.getElementById('r${rowId}c${colId}');
        if (null == col) {
          break;
        }

       MouseEvent event = document.createEvent('MouseEvents');
       event.initMouseEvent('click', true, true, window,
                            0, 0, 0, 0, 0,
                            false, false, false, false, 0, null);
       col.dispatchEvent(event);

       colId++;
       nodeCount++;
      }

      rowId++;
    }

    if (Events.counter != rows * cols) {
       throw 'ERROR - did not fire events on all nodes! '+Events.counter;
    }
  }

  // Tests removing event handlers.
  void teardownTest() {
    int nodeCount = 0;
    for (int i = 0; i < randomIds.length; i++) {
      HTMLElement col = document.getElementById(randomIds[i]);
      col.removeEventListener('click', Events.eventClickHandlerFn, false);
      nodeCount++;
    }

    if (nodeCount != rows * cols) {
       throw 'ERROR - did not remove listeners from all nodes! ${nodeCount}';
    }
  }

  // Removes event handlers and their associated proxy objects.
  void proxyCleanup() {
    for (int i = 0; i < proxies.length; i++) {
      Function proxy = proxies[i][0];
      HTMLElement col = proxies[i][1];
      col.removeEventListener('click', proxy, false);
    }
    proxies = new Array<Array>();
  }
}

class Events {
  static int counter;

  static Document document;

  static void eventClickHandler() {
    counter++;
  }

  static Function eventClickHandlerFn;

  static void main() {
    counter = 0;

    eventClickHandlerFn = (e) { eventClickHandler(); };

    EventsTest smallTest = new EventsTest(100, 10);
    EventsTest largeTest = new EventsTest(100, 50);
    EventsTest extraLargeTest = new EventsTest(200, 20);

    // We cannot reproduce exact semantics of creation of unwrapped
    // elements in Dart.
    new BenchmarkSuite('Events (modified!)', [
        new Benchmark('Event Hooking (1000 nodes)',
                      (x) { smallTest.hookTest(); },
                      () => smallTest.setup()),
        new Benchmark('Event Dispatch (1000 nodes)',
                      (x) { smallTest.dispatchTest(); },
                      () => smallTest.setupWithListeners()),
        new Benchmark('Event Hooking (5000 nodes)',
                      (x) { largeTest.hookTest(); },
                      () => largeTest.setup()),
        new Benchmark('Event Hooking Proxy (4000 nodes)',
                      (x) {  extraLargeTest.hookTestProxy(); },
                      () => extraLargeTest.setup(),
                      (x) { extraLargeTest.proxyCleanup(); }),
        new Benchmark('Event Dispatch (5000 nodes)',
                      (x) { largeTest.dispatchTest(); },
                      () => largeTest.setupWithListeners()),
        new Benchmark('Event Teardown (5000 nodes)',
                      (x) { largeTest.teardownTest(); },
                      () => largeTest.setupForTeardown()),
        new Benchmark('Event Teardown (4000 nodes)',
                      (x) { extraLargeTest.teardownTest(); },
                      () => extraLargeTest.setupForTeardown())

    ]);
  }
}
