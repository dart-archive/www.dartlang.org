// Copyright 2011 Google Inc. All Rights Reserved.

// A utility object for measuring time intervals.

class Interval {
  int _start, _stop;

  Interval() {
  }

  void start() {
    _start = BenchUtil.now;
  }

  void stop() {
    _stop = BenchUtil.now;
  }

  // Microseconds from between start() and stop().
  int get elapsedMicrosec() {
    return (_stop - _start) * 1000;
  }

  // Milliseconds from between start() and stop().
  int get elapsedMillisec() {
    return (_stop - _start);
  }
}
