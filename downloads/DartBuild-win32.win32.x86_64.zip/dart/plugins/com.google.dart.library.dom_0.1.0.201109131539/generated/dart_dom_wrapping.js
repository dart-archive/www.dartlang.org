// DO NOT EDIT
// Auto-generated Dart DOM implementation.


function native__AbstractWorkerWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AbstractWorkerWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AbstractWorkerWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AbstractWorkerWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AbstractWorkerWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AbstractWorkerWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AbstractWorkerWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ArrayBufferWrappingImplementation__get__byteLength(_this) {
  try {
    return __dom_wrap(_this.byteLength);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ArrayBufferViewWrappingImplementation__get__buffer(_this) {
  try {
    return __dom_wrap(_this.buffer);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ArrayBufferViewWrappingImplementation__get__byteLength(_this) {
  try {
    return __dom_wrap(_this.byteLength);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ArrayBufferViewWrappingImplementation__get__byteOffset(_this) {
  try {
    return __dom_wrap(_this.byteOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AttrWrappingImplementation__get__isId(_this) {
  try {
    return __dom_wrap(_this.isId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AttrWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AttrWrappingImplementation__get__ownerElement(_this) {
  try {
    return __dom_wrap(_this.ownerElement);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AttrWrappingImplementation__get__specified(_this) {
  try {
    return __dom_wrap(_this.specified);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AttrWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__AttrWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BarInfoWrappingImplementation__get__visible(_this) {
  try {
    return __dom_wrap(_this.visible);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeLoadEventWrappingImplementation__get__url(_this) {
  try {
    return __dom_wrap(_this.url);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeLoadEventWrappingImplementation__initBeforeLoadEvent(_this) {
  try {
    return __dom_wrap(_this.initBeforeLoadEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeLoadEventWrappingImplementation__initBeforeLoadEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initBeforeLoadEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeLoadEventWrappingImplementation__initBeforeLoadEvent_3(_this, type, canBubble) {
  try {
    return __dom_wrap(_this.initBeforeLoadEvent(__dom_unwrap(type), __dom_unwrap(canBubble)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeLoadEventWrappingImplementation__initBeforeLoadEvent_4(_this, type, canBubble, cancelable) {
  try {
    return __dom_wrap(_this.initBeforeLoadEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeLoadEventWrappingImplementation__initBeforeLoadEvent_5(_this, type, canBubble, cancelable, url) {
  try {
    return __dom_wrap(_this.initBeforeLoadEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(url)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeProcessEventWrappingImplementation__get__text(_this) {
  try {
    return __dom_wrap(_this.text);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeProcessEventWrappingImplementation__set__text(_this, value) {
  try {
    _this.text = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeProcessEventWrappingImplementation__initBeforeProcessEvent(_this) {
  try {
    return __dom_wrap(_this.initBeforeProcessEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeProcessEventWrappingImplementation__initBeforeProcessEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initBeforeProcessEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeProcessEventWrappingImplementation__initBeforeProcessEvent_3(_this, type, canBubble) {
  try {
    return __dom_wrap(_this.initBeforeProcessEvent(__dom_unwrap(type), __dom_unwrap(canBubble)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BeforeProcessEventWrappingImplementation__initBeforeProcessEvent_4(_this, type, canBubble, cancelable) {
  try {
    return __dom_wrap(_this.initBeforeProcessEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BlobWrappingImplementation__get__size(_this) {
  try {
    return __dom_wrap(_this.size);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__BlobWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSCharsetRuleWrappingImplementation__get__encoding(_this) {
  try {
    return __dom_wrap(_this.encoding);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSCharsetRuleWrappingImplementation__set__encoding(_this, value) {
  try {
    _this.encoding = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSFontFaceRuleWrappingImplementation__get__style(_this) {
  try {
    return __dom_wrap(_this.style);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSImportRuleWrappingImplementation__get__href(_this) {
  try {
    return __dom_wrap(_this.href);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSImportRuleWrappingImplementation__get__media(_this) {
  try {
    return __dom_wrap(_this.media);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSImportRuleWrappingImplementation__get__styleSheet(_this) {
  try {
    return __dom_wrap(_this.styleSheet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSMediaRuleWrappingImplementation__get__cssRules(_this) {
  try {
    return __dom_wrap(_this.cssRules);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSMediaRuleWrappingImplementation__get__media(_this) {
  try {
    return __dom_wrap(_this.media);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSMediaRuleWrappingImplementation__deleteRule(_this) {
  try {
    return __dom_wrap(_this.deleteRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSMediaRuleWrappingImplementation__deleteRule_2(_this, index) {
  try {
    return __dom_wrap(_this.deleteRule(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSMediaRuleWrappingImplementation__insertRule(_this) {
  try {
    return __dom_wrap(_this.insertRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSMediaRuleWrappingImplementation__insertRule_2(_this, rule) {
  try {
    return __dom_wrap(_this.insertRule(__dom_unwrap(rule)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSMediaRuleWrappingImplementation__insertRule_3(_this, rule, index) {
  try {
    return __dom_wrap(_this.insertRule(__dom_unwrap(rule), __dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPageRuleWrappingImplementation__get__selectorText(_this) {
  try {
    return __dom_wrap(_this.selectorText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPageRuleWrappingImplementation__set__selectorText(_this, value) {
  try {
    _this.selectorText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPageRuleWrappingImplementation__get__style(_this) {
  try {
    return __dom_wrap(_this.style);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__get__primitiveType(_this) {
  try {
    return __dom_wrap(_this.primitiveType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__getCounterValue(_this) {
  try {
    return __dom_wrap(_this.getCounterValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__getFloatValue(_this) {
  try {
    return __dom_wrap(_this.getFloatValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__getFloatValue_2(_this, unitType) {
  try {
    return __dom_wrap(_this.getFloatValue(__dom_unwrap(unitType)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__getRGBColorValue(_this) {
  try {
    return __dom_wrap(_this.getRGBColorValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__getRectValue(_this) {
  try {
    return __dom_wrap(_this.getRectValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__getStringValue(_this) {
  try {
    return __dom_wrap(_this.getStringValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__setFloatValue(_this) {
  try {
    return __dom_wrap(_this.setFloatValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__setFloatValue_2(_this, unitType) {
  try {
    return __dom_wrap(_this.setFloatValue(__dom_unwrap(unitType)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__setFloatValue_3(_this, unitType, floatValue) {
  try {
    return __dom_wrap(_this.setFloatValue(__dom_unwrap(unitType), __dom_unwrap(floatValue)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__setStringValue(_this) {
  try {
    return __dom_wrap(_this.setStringValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__setStringValue_2(_this, stringType) {
  try {
    return __dom_wrap(_this.setStringValue(__dom_unwrap(stringType)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSPrimitiveValueWrappingImplementation__setStringValue_3(_this, stringType, stringValue) {
  try {
    return __dom_wrap(_this.setStringValue(__dom_unwrap(stringType), __dom_unwrap(stringValue)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSRuleWrappingImplementation__get__cssText(_this) {
  try {
    return __dom_wrap(_this.cssText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSRuleWrappingImplementation__set__cssText(_this, value) {
  try {
    _this.cssText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSRuleWrappingImplementation__get__parentRule(_this) {
  try {
    return __dom_wrap(_this.parentRule);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSRuleWrappingImplementation__get__parentStyleSheet(_this) {
  try {
    return __dom_wrap(_this.parentStyleSheet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSRuleWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSRuleListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSRuleListWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSRuleListWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__get__cssText(_this) {
  try {
    return __dom_wrap(_this.cssText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__set__cssText(_this, value) {
  try {
    _this.cssText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__get__parentRule(_this) {
  try {
    return __dom_wrap(_this.parentRule);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__getPropertyCSSValue(_this) {
  try {
    return __dom_wrap(_this.getPropertyCSSValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__getPropertyCSSValue_2(_this, propertyName) {
  try {
    return __dom_wrap(_this.getPropertyCSSValue(__dom_unwrap(propertyName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__getPropertyPriority(_this) {
  try {
    return __dom_wrap(_this.getPropertyPriority());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__getPropertyPriority_2(_this, propertyName) {
  try {
    return __dom_wrap(_this.getPropertyPriority(__dom_unwrap(propertyName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__getPropertyShorthand(_this) {
  try {
    return __dom_wrap(_this.getPropertyShorthand());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__getPropertyShorthand_2(_this, propertyName) {
  try {
    return __dom_wrap(_this.getPropertyShorthand(__dom_unwrap(propertyName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__getPropertyValue(_this) {
  try {
    return __dom_wrap(_this.getPropertyValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__getPropertyValue_2(_this, propertyName) {
  try {
    return __dom_wrap(_this.getPropertyValue(__dom_unwrap(propertyName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__isPropertyImplicit(_this) {
  try {
    return __dom_wrap(_this.isPropertyImplicit());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__isPropertyImplicit_2(_this, propertyName) {
  try {
    return __dom_wrap(_this.isPropertyImplicit(__dom_unwrap(propertyName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__removeProperty(_this) {
  try {
    return __dom_wrap(_this.removeProperty());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__removeProperty_2(_this, propertyName) {
  try {
    return __dom_wrap(_this.removeProperty(__dom_unwrap(propertyName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__setProperty(_this) {
  try {
    return __dom_wrap(_this.setProperty());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__setProperty_2(_this, propertyName) {
  try {
    return __dom_wrap(_this.setProperty(__dom_unwrap(propertyName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__setProperty_3(_this, propertyName, value) {
  try {
    return __dom_wrap(_this.setProperty(__dom_unwrap(propertyName), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleDeclarationWrappingImplementation__setProperty_4(_this, propertyName, value, priority) {
  try {
    return __dom_wrap(_this.setProperty(__dom_unwrap(propertyName), __dom_unwrap(value), __dom_unwrap(priority)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleRuleWrappingImplementation__get__selectorText(_this) {
  try {
    return __dom_wrap(_this.selectorText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleRuleWrappingImplementation__set__selectorText(_this, value) {
  try {
    _this.selectorText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleRuleWrappingImplementation__get__style(_this) {
  try {
    return __dom_wrap(_this.style);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__get__cssRules(_this) {
  try {
    return __dom_wrap(_this.cssRules);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__get__ownerRule(_this) {
  try {
    return __dom_wrap(_this.ownerRule);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__get__rules(_this) {
  try {
    return __dom_wrap(_this.rules);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__addRule(_this) {
  try {
    return __dom_wrap(_this.addRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__addRule_2(_this, selector) {
  try {
    return __dom_wrap(_this.addRule(__dom_unwrap(selector)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__addRule_3(_this, selector, style) {
  try {
    return __dom_wrap(_this.addRule(__dom_unwrap(selector), __dom_unwrap(style)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__addRule_4(_this, selector, style, index) {
  try {
    return __dom_wrap(_this.addRule(__dom_unwrap(selector), __dom_unwrap(style), __dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__deleteRule(_this) {
  try {
    return __dom_wrap(_this.deleteRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__deleteRule_2(_this, index) {
  try {
    return __dom_wrap(_this.deleteRule(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__insertRule(_this) {
  try {
    return __dom_wrap(_this.insertRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__insertRule_2(_this, rule) {
  try {
    return __dom_wrap(_this.insertRule(__dom_unwrap(rule)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__insertRule_3(_this, rule, index) {
  try {
    return __dom_wrap(_this.insertRule(__dom_unwrap(rule), __dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__removeRule(_this) {
  try {
    return __dom_wrap(_this.removeRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSStyleSheetWrappingImplementation__removeRule_2(_this, index) {
  try {
    return __dom_wrap(_this.removeRule(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSValueWrappingImplementation__get__cssText(_this) {
  try {
    return __dom_wrap(_this.cssText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSValueWrappingImplementation__set__cssText(_this, value) {
  try {
    _this.cssText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSValueWrappingImplementation__get__cssValueType(_this) {
  try {
    return __dom_wrap(_this.cssValueType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSValueListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSValueListWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CSSValueListWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasGradientWrappingImplementation__addColorStop(_this) {
  try {
    return __dom_wrap(_this.addColorStop());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasGradientWrappingImplementation__addColorStop_2(_this, offset) {
  try {
    return __dom_wrap(_this.addColorStop(__dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasGradientWrappingImplementation__addColorStop_3(_this, offset, color) {
  try {
    return __dom_wrap(_this.addColorStop(__dom_unwrap(offset), __dom_unwrap(color)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasPixelArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasPixelArrayWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContextWrappingImplementation__get__canvas(_this) {
  try {
    return __dom_wrap(_this.canvas);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__font(_this) {
  try {
    return __dom_wrap(_this.font);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__font(_this, value) {
  try {
    _this.font = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__globalAlpha(_this) {
  try {
    return __dom_wrap(_this.globalAlpha);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__globalAlpha(_this, value) {
  try {
    _this.globalAlpha = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__globalCompositeOperation(_this) {
  try {
    return __dom_wrap(_this.globalCompositeOperation);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__globalCompositeOperation(_this, value) {
  try {
    _this.globalCompositeOperation = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__lineCap(_this) {
  try {
    return __dom_wrap(_this.lineCap);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__lineCap(_this, value) {
  try {
    _this.lineCap = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__lineJoin(_this) {
  try {
    return __dom_wrap(_this.lineJoin);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__lineJoin(_this, value) {
  try {
    _this.lineJoin = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__lineWidth(_this) {
  try {
    return __dom_wrap(_this.lineWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__lineWidth(_this, value) {
  try {
    _this.lineWidth = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__miterLimit(_this) {
  try {
    return __dom_wrap(_this.miterLimit);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__miterLimit(_this, value) {
  try {
    _this.miterLimit = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__shadowBlur(_this) {
  try {
    return __dom_wrap(_this.shadowBlur);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__shadowBlur(_this, value) {
  try {
    _this.shadowBlur = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__shadowColor(_this) {
  try {
    return __dom_wrap(_this.shadowColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__shadowColor(_this, value) {
  try {
    _this.shadowColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__shadowOffsetX(_this) {
  try {
    return __dom_wrap(_this.shadowOffsetX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__shadowOffsetX(_this, value) {
  try {
    _this.shadowOffsetX = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__shadowOffsetY(_this) {
  try {
    return __dom_wrap(_this.shadowOffsetY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__shadowOffsetY(_this, value) {
  try {
    _this.shadowOffsetY = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__textAlign(_this) {
  try {
    return __dom_wrap(_this.textAlign);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__textAlign(_this, value) {
  try {
    _this.textAlign = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__get__textBaseline(_this) {
  try {
    return __dom_wrap(_this.textBaseline);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__set__textBaseline(_this, value) {
  try {
    _this.textBaseline = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__arc(_this, x, y, radius, startAngle, endAngle, anticlockwise) {
  try {
    return __dom_wrap(_this.arc(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(radius), __dom_unwrap(startAngle), __dom_unwrap(endAngle), __dom_unwrap(anticlockwise)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__arcTo(_this, x1, y1, x2, y2, radius) {
  try {
    return __dom_wrap(_this.arcTo(__dom_unwrap(x1), __dom_unwrap(y1), __dom_unwrap(x2), __dom_unwrap(y2), __dom_unwrap(radius)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__beginPath(_this) {
  try {
    return __dom_wrap(_this.beginPath());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__bezierCurveTo(_this, cp1x, cp1y, cp2x, cp2y, x, y) {
  try {
    return __dom_wrap(_this.bezierCurveTo(__dom_unwrap(cp1x), __dom_unwrap(cp1y), __dom_unwrap(cp2x), __dom_unwrap(cp2y), __dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__clearRect(_this, x, y, w, h) {
  try {
    return __dom_wrap(_this.clearRect(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(w), __dom_unwrap(h)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__clearShadow(_this) {
  try {
    return __dom_wrap(_this.clearShadow());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__clip(_this) {
  try {
    return __dom_wrap(_this.clip());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__closePath(_this) {
  try {
    return __dom_wrap(_this.closePath());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__createImageData(_this, imagedata_OR_sw) {
  try {
    return __dom_wrap(_this.createImageData(__dom_unwrap(imagedata_OR_sw)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__createImageData_2(_this, imagedata_OR_sw, sh) {
  try {
    return __dom_wrap(_this.createImageData(__dom_unwrap(imagedata_OR_sw), __dom_unwrap(sh)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__createLinearGradient(_this, x0, y0, x1, y1) {
  try {
    return __dom_wrap(_this.createLinearGradient(__dom_unwrap(x0), __dom_unwrap(y0), __dom_unwrap(x1), __dom_unwrap(y1)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__createPattern(_this, image, repetition) {
  try {
    return __dom_wrap(_this.createPattern(__dom_unwrap(image), __dom_unwrap(repetition)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__createPattern_2(_this, image, repetition) {
  try {
    return __dom_wrap(_this.createPattern(__dom_unwrap(image), __dom_unwrap(repetition)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__createRadialGradient(_this, x0, y0, r0, x1, y1, r1) {
  try {
    return __dom_wrap(_this.createRadialGradient(__dom_unwrap(x0), __dom_unwrap(y0), __dom_unwrap(r0), __dom_unwrap(x1), __dom_unwrap(y1), __dom_unwrap(r1)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImage(_this, image, dx_OR_sx, dy_OR_sy) {
  try {
    return __dom_wrap(_this.drawImage(__dom_unwrap(image), __dom_unwrap(dx_OR_sx), __dom_unwrap(dy_OR_sy)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImage_2(_this, image, dx_OR_sx, dy_OR_sy, dw_OR_sw, dh_OR_sh) {
  try {
    return __dom_wrap(_this.drawImage(__dom_unwrap(image), __dom_unwrap(dx_OR_sx), __dom_unwrap(dy_OR_sy), __dom_unwrap(dw_OR_sw), __dom_unwrap(dh_OR_sh)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImage_3(_this, image, dx_OR_sx, dy_OR_sy, dw_OR_sw, dh_OR_sh, dx, dy, dw, dh) {
  try {
    return __dom_wrap(_this.drawImage(__dom_unwrap(image), __dom_unwrap(dx_OR_sx), __dom_unwrap(dy_OR_sy), __dom_unwrap(dw_OR_sw), __dom_unwrap(dh_OR_sh), __dom_unwrap(dx), __dom_unwrap(dy), __dom_unwrap(dw), __dom_unwrap(dh)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImage_4(_this, image, dx_OR_sx, dy_OR_sy) {
  try {
    return __dom_wrap(_this.drawImage(__dom_unwrap(image), __dom_unwrap(dx_OR_sx), __dom_unwrap(dy_OR_sy)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImage_5(_this, image, dx_OR_sx, dy_OR_sy, dw_OR_sw, dh_OR_sh) {
  try {
    return __dom_wrap(_this.drawImage(__dom_unwrap(image), __dom_unwrap(dx_OR_sx), __dom_unwrap(dy_OR_sy), __dom_unwrap(dw_OR_sw), __dom_unwrap(dh_OR_sh)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImage_6(_this, image, dx_OR_sx, dy_OR_sy, dw_OR_sw, dh_OR_sh, dx, dy, dw, dh) {
  try {
    return __dom_wrap(_this.drawImage(__dom_unwrap(image), __dom_unwrap(dx_OR_sx), __dom_unwrap(dy_OR_sy), __dom_unwrap(dw_OR_sw), __dom_unwrap(dh_OR_sh), __dom_unwrap(dx), __dom_unwrap(dy), __dom_unwrap(dw), __dom_unwrap(dh)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect(_this, image) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_2(_this, image, sx) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_3(_this, image, sx, sy) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx), __dom_unwrap(sy)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_4(_this, image, sx, sy, sw) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx), __dom_unwrap(sy), __dom_unwrap(sw)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_5(_this, image, sx, sy, sw, sh) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx), __dom_unwrap(sy), __dom_unwrap(sw), __dom_unwrap(sh)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_6(_this, image, sx, sy, sw, sh, dx) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx), __dom_unwrap(sy), __dom_unwrap(sw), __dom_unwrap(sh), __dom_unwrap(dx)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_7(_this, image, sx, sy, sw, sh, dx, dy) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx), __dom_unwrap(sy), __dom_unwrap(sw), __dom_unwrap(sh), __dom_unwrap(dx), __dom_unwrap(dy)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_8(_this, image, sx, sy, sw, sh, dx, dy, dw) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx), __dom_unwrap(sy), __dom_unwrap(sw), __dom_unwrap(sh), __dom_unwrap(dx), __dom_unwrap(dy), __dom_unwrap(dw)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_9(_this, image, sx, sy, sw, sh, dx, dy, dw, dh) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx), __dom_unwrap(sy), __dom_unwrap(sw), __dom_unwrap(sh), __dom_unwrap(dx), __dom_unwrap(dy), __dom_unwrap(dw), __dom_unwrap(dh)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__drawImageFromRect_10(_this, image, sx, sy, sw, sh, dx, dy, dw, dh, compositeOperation) {
  try {
    return __dom_wrap(_this.drawImageFromRect(__dom_unwrap(image), __dom_unwrap(sx), __dom_unwrap(sy), __dom_unwrap(sw), __dom_unwrap(sh), __dom_unwrap(dx), __dom_unwrap(dy), __dom_unwrap(dw), __dom_unwrap(dh), __dom_unwrap(compositeOperation)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__fill(_this) {
  try {
    return __dom_wrap(_this.fill());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__fillRect(_this, x, y, w, h) {
  try {
    return __dom_wrap(_this.fillRect(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(w), __dom_unwrap(h)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__fillText(_this, text, x, y) {
  try {
    return __dom_wrap(_this.fillText(__dom_unwrap(text), __dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__fillText_2(_this, text, x, y, maxWidth) {
  try {
    return __dom_wrap(_this.fillText(__dom_unwrap(text), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(maxWidth)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__getImageData(_this, sx, sy, sw, sh) {
  try {
    return __dom_wrap(_this.getImageData(__dom_unwrap(sx), __dom_unwrap(sy), __dom_unwrap(sw), __dom_unwrap(sh)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__isPointInPath(_this, x, y) {
  try {
    return __dom_wrap(_this.isPointInPath(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__lineTo(_this, x, y) {
  try {
    return __dom_wrap(_this.lineTo(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__measureText(_this, text) {
  try {
    return __dom_wrap(_this.measureText(__dom_unwrap(text)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__moveTo(_this, x, y) {
  try {
    return __dom_wrap(_this.moveTo(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__putImageData(_this, imagedata, dx, dy) {
  try {
    return __dom_wrap(_this.putImageData(__dom_unwrap(imagedata), __dom_unwrap(dx), __dom_unwrap(dy)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__putImageData_2(_this, imagedata, dx, dy, dirtyX, dirtyY, dirtyWidth, dirtyHeight) {
  try {
    return __dom_wrap(_this.putImageData(__dom_unwrap(imagedata), __dom_unwrap(dx), __dom_unwrap(dy), __dom_unwrap(dirtyX), __dom_unwrap(dirtyY), __dom_unwrap(dirtyWidth), __dom_unwrap(dirtyHeight)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__quadraticCurveTo(_this, cpx, cpy, x, y) {
  try {
    return __dom_wrap(_this.quadraticCurveTo(__dom_unwrap(cpx), __dom_unwrap(cpy), __dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__rect(_this, x, y, w, h) {
  try {
    return __dom_wrap(_this.rect(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(w), __dom_unwrap(h)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__restore(_this) {
  try {
    return __dom_wrap(_this.restore());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__rotate(_this, angle) {
  try {
    return __dom_wrap(_this.rotate(__dom_unwrap(angle)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__save(_this) {
  try {
    return __dom_wrap(_this.save());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__scale(_this, x, y) {
  try {
    return __dom_wrap(_this.scale(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setAlpha(_this, alpha) {
  try {
    return __dom_wrap(_this.setAlpha(__dom_unwrap(alpha)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setCompositeOperation(_this, compositeOperation) {
  try {
    return __dom_wrap(_this.setCompositeOperation(__dom_unwrap(compositeOperation)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillColor(_this, c_OR_color_OR_grayLevel_OR_r) {
  try {
    return __dom_wrap(_this.setFillColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillColor_2(_this, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m) {
  try {
    return __dom_wrap(_this.setFillColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillColor_3(_this, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m, b_OR_y, a_OR_k) {
  try {
    return __dom_wrap(_this.setFillColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m), __dom_unwrap(b_OR_y), __dom_unwrap(a_OR_k)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillColor_4(_this, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m, b_OR_y, a_OR_k, a) {
  try {
    return __dom_wrap(_this.setFillColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m), __dom_unwrap(b_OR_y), __dom_unwrap(a_OR_k), __dom_unwrap(a)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillColor_5(_this, c_OR_color_OR_grayLevel_OR_r) {
  try {
    return __dom_wrap(_this.setFillColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillColor_6(_this, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m) {
  try {
    return __dom_wrap(_this.setFillColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillStyle(_this, color_OR_gradient_OR_pattern) {
  try {
    return __dom_wrap(_this.setFillStyle(__dom_unwrap(color_OR_gradient_OR_pattern)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillStyle_2(_this, color_OR_gradient_OR_pattern) {
  try {
    return __dom_wrap(_this.setFillStyle(__dom_unwrap(color_OR_gradient_OR_pattern)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillStyle_3(_this, color_OR_gradient_OR_pattern) {
  try {
    return __dom_wrap(_this.setFillStyle(__dom_unwrap(color_OR_gradient_OR_pattern)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setLineCap(_this, cap) {
  try {
    return __dom_wrap(_this.setLineCap(__dom_unwrap(cap)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setLineJoin(_this, join) {
  try {
    return __dom_wrap(_this.setLineJoin(__dom_unwrap(join)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setLineWidth(_this, width) {
  try {
    return __dom_wrap(_this.setLineWidth(__dom_unwrap(width)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setMiterLimit(_this, limit) {
  try {
    return __dom_wrap(_this.setMiterLimit(__dom_unwrap(limit)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setShadow(_this, width, height, blur) {
  try {
    return __dom_wrap(_this.setShadow(__dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(blur)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setShadow_2(_this, width, height, blur, c_OR_color_OR_grayLevel_OR_r) {
  try {
    return __dom_wrap(_this.setShadow(__dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(blur), __dom_unwrap(c_OR_color_OR_grayLevel_OR_r)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setShadow_3(_this, width, height, blur, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m) {
  try {
    return __dom_wrap(_this.setShadow(__dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(blur), __dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setShadow_4(_this, width, height, blur, c_OR_color_OR_grayLevel_OR_r) {
  try {
    return __dom_wrap(_this.setShadow(__dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(blur), __dom_unwrap(c_OR_color_OR_grayLevel_OR_r)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setShadow_5(_this, width, height, blur, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m) {
  try {
    return __dom_wrap(_this.setShadow(__dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(blur), __dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setShadow_6(_this, width, height, blur, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m, b_OR_y, a_OR_k) {
  try {
    return __dom_wrap(_this.setShadow(__dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(blur), __dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m), __dom_unwrap(b_OR_y), __dom_unwrap(a_OR_k)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setShadow_7(_this, width, height, blur, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m, b_OR_y, a_OR_k, a) {
  try {
    return __dom_wrap(_this.setShadow(__dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(blur), __dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m), __dom_unwrap(b_OR_y), __dom_unwrap(a_OR_k), __dom_unwrap(a)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeColor(_this, c_OR_color_OR_grayLevel_OR_r) {
  try {
    return __dom_wrap(_this.setStrokeColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeColor_2(_this, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m) {
  try {
    return __dom_wrap(_this.setStrokeColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeColor_3(_this, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m, b_OR_y, a_OR_k) {
  try {
    return __dom_wrap(_this.setStrokeColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m), __dom_unwrap(b_OR_y), __dom_unwrap(a_OR_k)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeColor_4(_this, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m, b_OR_y, a_OR_k, a) {
  try {
    return __dom_wrap(_this.setStrokeColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m), __dom_unwrap(b_OR_y), __dom_unwrap(a_OR_k), __dom_unwrap(a)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeColor_5(_this, c_OR_color_OR_grayLevel_OR_r) {
  try {
    return __dom_wrap(_this.setStrokeColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeColor_6(_this, c_OR_color_OR_grayLevel_OR_r, alpha_OR_g_OR_m) {
  try {
    return __dom_wrap(_this.setStrokeColor(__dom_unwrap(c_OR_color_OR_grayLevel_OR_r), __dom_unwrap(alpha_OR_g_OR_m)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeStyle(_this, color_OR_gradient_OR_pattern) {
  try {
    return __dom_wrap(_this.setStrokeStyle(__dom_unwrap(color_OR_gradient_OR_pattern)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeStyle_2(_this, color_OR_gradient_OR_pattern) {
  try {
    return __dom_wrap(_this.setStrokeStyle(__dom_unwrap(color_OR_gradient_OR_pattern)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeStyle_3(_this, color_OR_gradient_OR_pattern) {
  try {
    return __dom_wrap(_this.setStrokeStyle(__dom_unwrap(color_OR_gradient_OR_pattern)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setTransform(_this, a, b, c, d, e, f) {
  try {
    return __dom_wrap(_this.setTransform(__dom_unwrap(a), __dom_unwrap(b), __dom_unwrap(c), __dom_unwrap(d), __dom_unwrap(e), __dom_unwrap(f)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__stroke(_this) {
  try {
    return __dom_wrap(_this.stroke());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__strokeRect(_this, x, y, w_OR_width, h_OR_height) {
  try {
    return __dom_wrap(_this.strokeRect(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(w_OR_width), __dom_unwrap(h_OR_height)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__strokeRect_2(_this, x, y, w_OR_width, h_OR_height, lineWidth) {
  try {
    return __dom_wrap(_this.strokeRect(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(w_OR_width), __dom_unwrap(h_OR_height), __dom_unwrap(lineWidth)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__strokeText(_this, text, x, y) {
  try {
    return __dom_wrap(_this.strokeText(__dom_unwrap(text), __dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__strokeText_2(_this, text, x, y, maxWidth) {
  try {
    return __dom_wrap(_this.strokeText(__dom_unwrap(text), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(maxWidth)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__transform(_this, a, b, c, d, e, f) {
  try {
    return __dom_wrap(_this.transform(__dom_unwrap(a), __dom_unwrap(b), __dom_unwrap(c), __dom_unwrap(d), __dom_unwrap(e), __dom_unwrap(f)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__translate(_this, x, y) {
  try {
    return __dom_wrap(_this.translate(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__get__data(_this) {
  try {
    return __dom_wrap(_this.data);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__set__data(_this, value) {
  try {
    _this.data = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__appendData(_this) {
  try {
    return __dom_wrap(_this.appendData());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__appendData_2(_this, data) {
  try {
    return __dom_wrap(_this.appendData(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__deleteData(_this) {
  try {
    return __dom_wrap(_this.deleteData());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__deleteData_2(_this, offset) {
  try {
    return __dom_wrap(_this.deleteData(__dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__deleteData_3(_this, offset, count) {
  try {
    return __dom_wrap(_this.deleteData(__dom_unwrap(offset), __dom_unwrap(count)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__insertData(_this) {
  try {
    return __dom_wrap(_this.insertData());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__insertData_2(_this, offset) {
  try {
    return __dom_wrap(_this.insertData(__dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__insertData_3(_this, offset, data) {
  try {
    return __dom_wrap(_this.insertData(__dom_unwrap(offset), __dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__replaceData(_this) {
  try {
    return __dom_wrap(_this.replaceData());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__replaceData_2(_this, offset) {
  try {
    return __dom_wrap(_this.replaceData(__dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__replaceData_3(_this, offset, count_OR_length) {
  try {
    return __dom_wrap(_this.replaceData(__dom_unwrap(offset), __dom_unwrap(count_OR_length)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__replaceData_4(_this, offset, count_OR_length, data) {
  try {
    return __dom_wrap(_this.replaceData(__dom_unwrap(offset), __dom_unwrap(count_OR_length), __dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__substringData(_this) {
  try {
    return __dom_wrap(_this.substringData());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__substringData_2(_this, offset) {
  try {
    return __dom_wrap(_this.substringData(__dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CharacterDataWrappingImplementation__substringData_3(_this, offset, count) {
  try {
    return __dom_wrap(_this.substringData(__dom_unwrap(offset), __dom_unwrap(count)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectWrappingImplementation__get__bottom(_this) {
  try {
    return __dom_wrap(_this.bottom);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectWrappingImplementation__get__left(_this) {
  try {
    return __dom_wrap(_this.left);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectWrappingImplementation__get__right(_this) {
  try {
    return __dom_wrap(_this.right);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectWrappingImplementation__get__top(_this) {
  try {
    return __dom_wrap(_this.top);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectListWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClientRectListWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__get__dropEffect(_this) {
  try {
    return __dom_wrap(_this.dropEffect);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__set__dropEffect(_this, value) {
  try {
    _this.dropEffect = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__get__effectAllowed(_this) {
  try {
    return __dom_wrap(_this.effectAllowed);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__set__effectAllowed(_this, value) {
  try {
    _this.effectAllowed = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__get__files(_this) {
  try {
    return __dom_wrap(_this.files);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__get__items(_this) {
  try {
    return __dom_wrap(_this.items);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__clearData(_this) {
  try {
    return __dom_wrap(_this.clearData());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__clearData_2(_this, type) {
  try {
    return __dom_wrap(_this.clearData(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__getData(_this, type) {
  try {
    return __dom_wrap(_this.getData(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__setData(_this, type, data) {
  try {
    return __dom_wrap(_this.setData(__dom_unwrap(type), __dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ClipboardWrappingImplementation__setDragImage(_this, image, x, y) {
  try {
    return __dom_wrap(_this.setDragImage(__dom_unwrap(image), __dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__get__reason(_this) {
  try {
    return __dom_wrap(_this.reason);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__get__wasClean(_this) {
  try {
    return __dom_wrap(_this.wasClean);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__initCloseEvent(_this) {
  try {
    return __dom_wrap(_this.initCloseEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__initCloseEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initCloseEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__initCloseEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initCloseEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__initCloseEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initCloseEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__initCloseEvent_5(_this, typeArg, canBubbleArg, cancelableArg, wasCleanArg) {
  try {
    return __dom_wrap(_this.initCloseEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(wasCleanArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__initCloseEvent_6(_this, typeArg, canBubbleArg, cancelableArg, wasCleanArg, codeArg) {
  try {
    return __dom_wrap(_this.initCloseEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(wasCleanArg), __dom_unwrap(codeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CloseEventWrappingImplementation__initCloseEvent_7(_this, typeArg, canBubbleArg, cancelableArg, wasCleanArg, codeArg, reasonArg) {
  try {
    return __dom_wrap(_this.initCloseEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(wasCleanArg), __dom_unwrap(codeArg), __dom_unwrap(reasonArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CompositionEventWrappingImplementation__get__data(_this) {
  try {
    return __dom_wrap(_this.data);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CompositionEventWrappingImplementation__initCompositionEvent(_this) {
  try {
    return __dom_wrap(_this.initCompositionEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CompositionEventWrappingImplementation__initCompositionEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initCompositionEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CompositionEventWrappingImplementation__initCompositionEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initCompositionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CompositionEventWrappingImplementation__initCompositionEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initCompositionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CompositionEventWrappingImplementation__initCompositionEvent_5(_this, typeArg, canBubbleArg, cancelableArg, viewArg) {
  try {
    return __dom_wrap(_this.initCompositionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(viewArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CompositionEventWrappingImplementation__initCompositionEvent_6(_this, typeArg, canBubbleArg, cancelableArg, viewArg, dataArg) {
  try {
    return __dom_wrap(_this.initCompositionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(viewArg), __dom_unwrap(dataArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__get__memory(_this) {
  try {
    return __dom_wrap(_this.memory);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__assert(_this, condition) {
  try {
    return __dom_wrap(_this.assert(__dom_unwrap(condition)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__count(_this) {
  try {
    return __dom_wrap(_this.count());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__debug(_this) {
  try {
    return __dom_wrap(_this.debug());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__dir(_this) {
  try {
    return __dom_wrap(_this.dir());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__dirxml(_this) {
  try {
    return __dom_wrap(_this.dirxml());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__error(_this) {
  try {
    return __dom_wrap(_this.error());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__group(_this) {
  try {
    return __dom_wrap(_this.group());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__groupCollapsed(_this) {
  try {
    return __dom_wrap(_this.groupCollapsed());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__groupEnd(_this) {
  try {
    return __dom_wrap(_this.groupEnd());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__info(_this) {
  try {
    return __dom_wrap(_this.info());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__log(_this) {
  try {
    return __dom_wrap(_this.log());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__markTimeline(_this) {
  try {
    return __dom_wrap(_this.markTimeline());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__time(_this) {
  try {
    return __dom_wrap(_this.time());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__time_2(_this, title) {
  try {
    return __dom_wrap(_this.time(__dom_unwrap(title)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__timeEnd(_this, title) {
  try {
    return __dom_wrap(_this.timeEnd(__dom_unwrap(title)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__timeStamp(_this) {
  try {
    return __dom_wrap(_this.timeStamp());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__trace(_this) {
  try {
    return __dom_wrap(_this.trace());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ConsoleWrappingImplementation__warn(_this) {
  try {
    return __dom_wrap(_this.warn());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CoordinatesWrappingImplementation__get__accuracy(_this) {
  try {
    return __dom_wrap(_this.accuracy);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CoordinatesWrappingImplementation__get__altitude(_this) {
  try {
    return __dom_wrap(_this.altitude);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CoordinatesWrappingImplementation__get__altitudeAccuracy(_this) {
  try {
    return __dom_wrap(_this.altitudeAccuracy);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CoordinatesWrappingImplementation__get__heading(_this) {
  try {
    return __dom_wrap(_this.heading);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CoordinatesWrappingImplementation__get__latitude(_this) {
  try {
    return __dom_wrap(_this.latitude);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CoordinatesWrappingImplementation__get__longitude(_this) {
  try {
    return __dom_wrap(_this.longitude);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CoordinatesWrappingImplementation__get__speed(_this) {
  try {
    return __dom_wrap(_this.speed);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CounterWrappingImplementation__get__identifier(_this) {
  try {
    return __dom_wrap(_this.identifier);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CounterWrappingImplementation__get__listStyle(_this) {
  try {
    return __dom_wrap(_this.listStyle);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CounterWrappingImplementation__get__separator(_this) {
  try {
    return __dom_wrap(_this.separator);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CryptoWrappingImplementation__getRandomValues(_this, array) {
  try {
    return __dom_wrap(_this.getRandomValues(__dom_unwrap(array)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CustomEventWrappingImplementation__get__detail(_this) {
  try {
    return __dom_wrap(_this.detail);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CustomEventWrappingImplementation__initCustomEvent(_this) {
  try {
    return __dom_wrap(_this.initCustomEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CustomEventWrappingImplementation__initCustomEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initCustomEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CustomEventWrappingImplementation__initCustomEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initCustomEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CustomEventWrappingImplementation__initCustomEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initCustomEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CustomEventWrappingImplementation__initCustomEvent_5(_this, typeArg, canBubbleArg, cancelableArg, detailArg) {
  try {
    return __dom_wrap(_this.initCustomEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(detailArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__oncached(_this) {
  try {
    return __dom_wrap(_this.oncached);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__set__oncached(_this, value) {
  try {
    _this.oncached = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__onchecking(_this) {
  try {
    return __dom_wrap(_this.onchecking);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__set__onchecking(_this, value) {
  try {
    _this.onchecking = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__ondownloading(_this) {
  try {
    return __dom_wrap(_this.ondownloading);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__set__ondownloading(_this, value) {
  try {
    _this.ondownloading = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__onnoupdate(_this) {
  try {
    return __dom_wrap(_this.onnoupdate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__set__onnoupdate(_this, value) {
  try {
    _this.onnoupdate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__onobsolete(_this) {
  try {
    return __dom_wrap(_this.onobsolete);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__set__onobsolete(_this, value) {
  try {
    _this.onobsolete = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__onprogress(_this) {
  try {
    return __dom_wrap(_this.onprogress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__set__onprogress(_this, value) {
  try {
    _this.onprogress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__onupdateready(_this) {
  try {
    return __dom_wrap(_this.onupdateready);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__set__onupdateready(_this, value) {
  try {
    _this.onupdateready = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__get__status(_this) {
  try {
    return __dom_wrap(_this.status);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__swapCache(_this) {
  try {
    return __dom_wrap(_this.swapCache());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMApplicationCacheWrappingImplementation__update(_this) {
  try {
    return __dom_wrap(_this.update());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMExceptionWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMFileSystemWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMFileSystemWrappingImplementation__get__root(_this) {
  try {
    return __dom_wrap(_this.root);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMFileSystemSyncWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMFileSystemSyncWrappingImplementation__get__root(_this) {
  try {
    return __dom_wrap(_this.root);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMFormDataWrappingImplementation__append(_this) {
  try {
    return __dom_wrap(_this.append());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMFormDataWrappingImplementation__append_2(_this, name) {
  try {
    return __dom_wrap(_this.append(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMFormDataWrappingImplementation__append_3(_this, name, value) {
  try {
    return __dom_wrap(_this.append(__dom_unwrap(name), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createCSSStyleSheet(_this) {
  try {
    return __dom_wrap(_this.createCSSStyleSheet());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createCSSStyleSheet_2(_this, title) {
  try {
    return __dom_wrap(_this.createCSSStyleSheet(__dom_unwrap(title)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createCSSStyleSheet_3(_this, title, media) {
  try {
    return __dom_wrap(_this.createCSSStyleSheet(__dom_unwrap(title), __dom_unwrap(media)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createDocument(_this) {
  try {
    return __dom_wrap(_this.createDocument());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createDocument_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.createDocument(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createDocument_3(_this, namespaceURI, qualifiedName) {
  try {
    return __dom_wrap(_this.createDocument(__dom_unwrap(namespaceURI), __dom_unwrap(qualifiedName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createDocument_4(_this, namespaceURI, qualifiedName, doctype) {
  try {
    return __dom_wrap(_this.createDocument(__dom_unwrap(namespaceURI), __dom_unwrap(qualifiedName), __dom_unwrap(doctype)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createDocumentType(_this) {
  try {
    return __dom_wrap(_this.createDocumentType());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createDocumentType_2(_this, qualifiedName) {
  try {
    return __dom_wrap(_this.createDocumentType(__dom_unwrap(qualifiedName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createDocumentType_3(_this, qualifiedName, publicId) {
  try {
    return __dom_wrap(_this.createDocumentType(__dom_unwrap(qualifiedName), __dom_unwrap(publicId)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createDocumentType_4(_this, qualifiedName, publicId, systemId) {
  try {
    return __dom_wrap(_this.createDocumentType(__dom_unwrap(qualifiedName), __dom_unwrap(publicId), __dom_unwrap(systemId)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createHTMLDocument(_this) {
  try {
    return __dom_wrap(_this.createHTMLDocument());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__createHTMLDocument_2(_this, title) {
  try {
    return __dom_wrap(_this.createHTMLDocument(__dom_unwrap(title)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__hasFeature(_this) {
  try {
    return __dom_wrap(_this.hasFeature());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__hasFeature_2(_this, feature) {
  try {
    return __dom_wrap(_this.hasFeature(__dom_unwrap(feature)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMImplementationWrappingImplementation__hasFeature_3(_this, feature, version) {
  try {
    return __dom_wrap(_this.hasFeature(__dom_unwrap(feature), __dom_unwrap(version)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeWrappingImplementation__get__description(_this) {
  try {
    return __dom_wrap(_this.description);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeWrappingImplementation__get__enabledPlugin(_this) {
  try {
    return __dom_wrap(_this.enabledPlugin);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeWrappingImplementation__get__suffixes(_this) {
  try {
    return __dom_wrap(_this.suffixes);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeArrayWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeArrayWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeArrayWrappingImplementation__namedItem(_this) {
  try {
    return __dom_wrap(_this.namedItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMMimeTypeArrayWrappingImplementation__namedItem_2(_this, name) {
  try {
    return __dom_wrap(_this.namedItem(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMParserWrappingImplementation__parseFromString(_this) {
  try {
    return __dom_wrap(_this.parseFromString());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMParserWrappingImplementation__parseFromString_2(_this, str) {
  try {
    return __dom_wrap(_this.parseFromString(__dom_unwrap(str)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMParserWrappingImplementation__parseFromString_3(_this, str, contentType) {
  try {
    return __dom_wrap(_this.parseFromString(__dom_unwrap(str), __dom_unwrap(contentType)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginWrappingImplementation__get__description(_this) {
  try {
    return __dom_wrap(_this.description);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginWrappingImplementation__get__filename(_this) {
  try {
    return __dom_wrap(_this.filename);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginWrappingImplementation__namedItem(_this) {
  try {
    return __dom_wrap(_this.namedItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginWrappingImplementation__namedItem_2(_this, name) {
  try {
    return __dom_wrap(_this.namedItem(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginArrayWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginArrayWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginArrayWrappingImplementation__namedItem(_this) {
  try {
    return __dom_wrap(_this.namedItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginArrayWrappingImplementation__namedItem_2(_this, name) {
  try {
    return __dom_wrap(_this.namedItem(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginArrayWrappingImplementation__refresh(_this) {
  try {
    return __dom_wrap(_this.refresh());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMPluginArrayWrappingImplementation__refresh_2(_this, reload) {
  try {
    return __dom_wrap(_this.refresh(__dom_unwrap(reload)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__anchorNode(_this) {
  try {
    return __dom_wrap(_this.anchorNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__anchorOffset(_this) {
  try {
    return __dom_wrap(_this.anchorOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__baseNode(_this) {
  try {
    return __dom_wrap(_this.baseNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__baseOffset(_this) {
  try {
    return __dom_wrap(_this.baseOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__extentNode(_this) {
  try {
    return __dom_wrap(_this.extentNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__extentOffset(_this) {
  try {
    return __dom_wrap(_this.extentOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__focusNode(_this) {
  try {
    return __dom_wrap(_this.focusNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__focusOffset(_this) {
  try {
    return __dom_wrap(_this.focusOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__isCollapsed(_this) {
  try {
    return __dom_wrap(_this.isCollapsed);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__rangeCount(_this) {
  try {
    return __dom_wrap(_this.rangeCount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__addRange(_this) {
  try {
    return __dom_wrap(_this.addRange());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__addRange_2(_this, range) {
  try {
    return __dom_wrap(_this.addRange(__dom_unwrap(range)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__collapse(_this) {
  try {
    return __dom_wrap(_this.collapse());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__collapse_2(_this, node) {
  try {
    return __dom_wrap(_this.collapse(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__collapse_3(_this, node, index) {
  try {
    return __dom_wrap(_this.collapse(__dom_unwrap(node), __dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__collapseToEnd(_this) {
  try {
    return __dom_wrap(_this.collapseToEnd());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__collapseToStart(_this) {
  try {
    return __dom_wrap(_this.collapseToStart());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__containsNode(_this) {
  try {
    return __dom_wrap(_this.containsNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__containsNode_2(_this, node) {
  try {
    return __dom_wrap(_this.containsNode(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__containsNode_3(_this, node, allowPartial) {
  try {
    return __dom_wrap(_this.containsNode(__dom_unwrap(node), __dom_unwrap(allowPartial)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__deleteFromDocument(_this) {
  try {
    return __dom_wrap(_this.deleteFromDocument());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__empty(_this) {
  try {
    return __dom_wrap(_this.empty());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__extend(_this) {
  try {
    return __dom_wrap(_this.extend());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__extend_2(_this, node) {
  try {
    return __dom_wrap(_this.extend(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__extend_3(_this, node, offset) {
  try {
    return __dom_wrap(_this.extend(__dom_unwrap(node), __dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__getRangeAt(_this) {
  try {
    return __dom_wrap(_this.getRangeAt());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__getRangeAt_2(_this, index) {
  try {
    return __dom_wrap(_this.getRangeAt(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__modify(_this) {
  try {
    return __dom_wrap(_this.modify());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__modify_2(_this, alter) {
  try {
    return __dom_wrap(_this.modify(__dom_unwrap(alter)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__modify_3(_this, alter, direction) {
  try {
    return __dom_wrap(_this.modify(__dom_unwrap(alter), __dom_unwrap(direction)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__modify_4(_this, alter, direction, granularity) {
  try {
    return __dom_wrap(_this.modify(__dom_unwrap(alter), __dom_unwrap(direction), __dom_unwrap(granularity)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__removeAllRanges(_this) {
  try {
    return __dom_wrap(_this.removeAllRanges());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__selectAllChildren(_this) {
  try {
    return __dom_wrap(_this.selectAllChildren());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__selectAllChildren_2(_this, node) {
  try {
    return __dom_wrap(_this.selectAllChildren(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__setBaseAndExtent(_this) {
  try {
    return __dom_wrap(_this.setBaseAndExtent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__setBaseAndExtent_2(_this, baseNode) {
  try {
    return __dom_wrap(_this.setBaseAndExtent(__dom_unwrap(baseNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__setBaseAndExtent_3(_this, baseNode, baseOffset) {
  try {
    return __dom_wrap(_this.setBaseAndExtent(__dom_unwrap(baseNode), __dom_unwrap(baseOffset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__setBaseAndExtent_4(_this, baseNode, baseOffset, extentNode) {
  try {
    return __dom_wrap(_this.setBaseAndExtent(__dom_unwrap(baseNode), __dom_unwrap(baseOffset), __dom_unwrap(extentNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__setBaseAndExtent_5(_this, baseNode, baseOffset, extentNode, extentOffset) {
  try {
    return __dom_wrap(_this.setBaseAndExtent(__dom_unwrap(baseNode), __dom_unwrap(baseOffset), __dom_unwrap(extentNode), __dom_unwrap(extentOffset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__setPosition(_this) {
  try {
    return __dom_wrap(_this.setPosition());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__setPosition_2(_this, node) {
  try {
    return __dom_wrap(_this.setPosition(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSelectionWrappingImplementation__setPosition_3(_this, node, offset) {
  try {
    return __dom_wrap(_this.setPosition(__dom_unwrap(node), __dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSettableTokenListWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMSettableTokenListWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMTokenListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMTokenListWrappingImplementation__add(_this, token) {
  try {
    return __dom_wrap(_this.add(__dom_unwrap(token)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMTokenListWrappingImplementation__contains(_this, token) {
  try {
    return __dom_wrap(_this.contains(__dom_unwrap(token)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMTokenListWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMTokenListWrappingImplementation__remove(_this, token) {
  try {
    return __dom_wrap(_this.remove(__dom_unwrap(token)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMTokenListWrappingImplementation__toggle(_this, token) {
  try {
    return __dom_wrap(_this.toggle(__dom_unwrap(token)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMURLWrappingImplementation__createObjectURL(_this, blob) {
  try {
    return __dom_wrap(_this.createObjectURL(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMURLWrappingImplementation__revokeObjectURL(_this, url) {
  try {
    return __dom_wrap(_this.revokeObjectURL(__dom_unwrap(url)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__applicationCache(_this) {
  try {
    return __dom_wrap(_this.applicationCache);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__clientInformation(_this) {
  try {
    return __dom_wrap(_this.clientInformation);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__clientInformation(_this, value) {
  try {
    _this.clientInformation = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__closed(_this) {
  try {
    return __dom_wrap(_this.closed);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__console(_this) {
  try {
    return __dom_wrap(_this.console);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__console(_this, value) {
  try {
    _this.console = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__crypto(_this) {
  try {
    return __dom_wrap(_this.crypto);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__defaultStatus(_this) {
  try {
    return __dom_wrap(_this.defaultStatus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__defaultStatus(_this, value) {
  try {
    _this.defaultStatus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__devicePixelRatio(_this) {
  try {
    return __dom_wrap(_this.devicePixelRatio);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__devicePixelRatio(_this, value) {
  try {
    _this.devicePixelRatio = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__document(_this) {
  try {
    return __dom_wrap(_this.document);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__event(_this) {
  try {
    return __dom_wrap(_this.event);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__event(_this, value) {
  try {
    _this.event = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__frameElement(_this) {
  try {
    return __dom_wrap(_this.frameElement);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__frames(_this) {
  try {
    return __dom_wrap(_this.frames);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__frames(_this, value) {
  try {
    _this.frames = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__history(_this) {
  try {
    return __dom_wrap(_this.history);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__history(_this, value) {
  try {
    _this.history = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__innerHeight(_this) {
  try {
    return __dom_wrap(_this.innerHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__innerHeight(_this, value) {
  try {
    _this.innerHeight = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__innerWidth(_this) {
  try {
    return __dom_wrap(_this.innerWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__innerWidth(_this, value) {
  try {
    _this.innerWidth = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__length(_this, value) {
  try {
    _this.length = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__localStorage(_this) {
  try {
    return __dom_wrap(_this.localStorage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__location(_this) {
  try {
    return __dom_wrap(_this.location);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__location(_this, value) {
  try {
    _this.location = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__locationbar(_this) {
  try {
    return __dom_wrap(_this.locationbar);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__locationbar(_this, value) {
  try {
    _this.locationbar = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__menubar(_this) {
  try {
    return __dom_wrap(_this.menubar);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__menubar(_this, value) {
  try {
    _this.menubar = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__navigator(_this) {
  try {
    return __dom_wrap(_this.navigator);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__navigator(_this, value) {
  try {
    _this.navigator = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__offscreenBuffering(_this) {
  try {
    return __dom_wrap(_this.offscreenBuffering);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__offscreenBuffering(_this, value) {
  try {
    _this.offscreenBuffering = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onbeforeunload(_this) {
  try {
    return __dom_wrap(_this.onbeforeunload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onbeforeunload(_this, value) {
  try {
    _this.onbeforeunload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onblur(_this) {
  try {
    return __dom_wrap(_this.onblur);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onblur(_this, value) {
  try {
    _this.onblur = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__oncanplay(_this) {
  try {
    return __dom_wrap(_this.oncanplay);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__oncanplay(_this, value) {
  try {
    _this.oncanplay = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__oncanplaythrough(_this) {
  try {
    return __dom_wrap(_this.oncanplaythrough);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__oncanplaythrough(_this, value) {
  try {
    _this.oncanplaythrough = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onchange(_this) {
  try {
    return __dom_wrap(_this.onchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onchange(_this, value) {
  try {
    _this.onchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onclick(_this) {
  try {
    return __dom_wrap(_this.onclick);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onclick(_this, value) {
  try {
    _this.onclick = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__oncontextmenu(_this) {
  try {
    return __dom_wrap(_this.oncontextmenu);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__oncontextmenu(_this, value) {
  try {
    _this.oncontextmenu = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondblclick(_this) {
  try {
    return __dom_wrap(_this.ondblclick);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondblclick(_this, value) {
  try {
    _this.ondblclick = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondevicemotion(_this) {
  try {
    return __dom_wrap(_this.ondevicemotion);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondevicemotion(_this, value) {
  try {
    _this.ondevicemotion = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondeviceorientation(_this) {
  try {
    return __dom_wrap(_this.ondeviceorientation);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondeviceorientation(_this, value) {
  try {
    _this.ondeviceorientation = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondrag(_this) {
  try {
    return __dom_wrap(_this.ondrag);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondrag(_this, value) {
  try {
    _this.ondrag = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondragend(_this) {
  try {
    return __dom_wrap(_this.ondragend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondragend(_this, value) {
  try {
    _this.ondragend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondragenter(_this) {
  try {
    return __dom_wrap(_this.ondragenter);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondragenter(_this, value) {
  try {
    _this.ondragenter = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondragleave(_this) {
  try {
    return __dom_wrap(_this.ondragleave);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondragleave(_this, value) {
  try {
    _this.ondragleave = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondragover(_this) {
  try {
    return __dom_wrap(_this.ondragover);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondragover(_this, value) {
  try {
    _this.ondragover = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondragstart(_this) {
  try {
    return __dom_wrap(_this.ondragstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondragstart(_this, value) {
  try {
    _this.ondragstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondrop(_this) {
  try {
    return __dom_wrap(_this.ondrop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondrop(_this, value) {
  try {
    _this.ondrop = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ondurationchange(_this) {
  try {
    return __dom_wrap(_this.ondurationchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ondurationchange(_this, value) {
  try {
    _this.ondurationchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onemptied(_this) {
  try {
    return __dom_wrap(_this.onemptied);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onemptied(_this, value) {
  try {
    _this.onemptied = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onended(_this) {
  try {
    return __dom_wrap(_this.onended);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onended(_this, value) {
  try {
    _this.onended = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onfocus(_this) {
  try {
    return __dom_wrap(_this.onfocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onfocus(_this, value) {
  try {
    _this.onfocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onhashchange(_this) {
  try {
    return __dom_wrap(_this.onhashchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onhashchange(_this, value) {
  try {
    _this.onhashchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__oninput(_this) {
  try {
    return __dom_wrap(_this.oninput);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__oninput(_this, value) {
  try {
    _this.oninput = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__oninvalid(_this) {
  try {
    return __dom_wrap(_this.oninvalid);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__oninvalid(_this, value) {
  try {
    _this.oninvalid = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onkeydown(_this) {
  try {
    return __dom_wrap(_this.onkeydown);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onkeydown(_this, value) {
  try {
    _this.onkeydown = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onkeypress(_this) {
  try {
    return __dom_wrap(_this.onkeypress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onkeypress(_this, value) {
  try {
    _this.onkeypress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onkeyup(_this) {
  try {
    return __dom_wrap(_this.onkeyup);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onkeyup(_this, value) {
  try {
    _this.onkeyup = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onload(_this) {
  try {
    return __dom_wrap(_this.onload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onload(_this, value) {
  try {
    _this.onload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onloadeddata(_this) {
  try {
    return __dom_wrap(_this.onloadeddata);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onloadeddata(_this, value) {
  try {
    _this.onloadeddata = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onloadedmetadata(_this) {
  try {
    return __dom_wrap(_this.onloadedmetadata);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onloadedmetadata(_this, value) {
  try {
    _this.onloadedmetadata = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onloadstart(_this) {
  try {
    return __dom_wrap(_this.onloadstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onloadstart(_this, value) {
  try {
    _this.onloadstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onmessage(_this) {
  try {
    return __dom_wrap(_this.onmessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onmessage(_this, value) {
  try {
    _this.onmessage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onmousedown(_this) {
  try {
    return __dom_wrap(_this.onmousedown);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onmousedown(_this, value) {
  try {
    _this.onmousedown = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onmousemove(_this) {
  try {
    return __dom_wrap(_this.onmousemove);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onmousemove(_this, value) {
  try {
    _this.onmousemove = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onmouseout(_this) {
  try {
    return __dom_wrap(_this.onmouseout);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onmouseout(_this, value) {
  try {
    _this.onmouseout = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onmouseover(_this) {
  try {
    return __dom_wrap(_this.onmouseover);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onmouseover(_this, value) {
  try {
    _this.onmouseover = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onmouseup(_this) {
  try {
    return __dom_wrap(_this.onmouseup);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onmouseup(_this, value) {
  try {
    _this.onmouseup = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onmousewheel(_this) {
  try {
    return __dom_wrap(_this.onmousewheel);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onmousewheel(_this, value) {
  try {
    _this.onmousewheel = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onoffline(_this) {
  try {
    return __dom_wrap(_this.onoffline);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onoffline(_this, value) {
  try {
    _this.onoffline = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ononline(_this) {
  try {
    return __dom_wrap(_this.ononline);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ononline(_this, value) {
  try {
    _this.ononline = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onpagehide(_this) {
  try {
    return __dom_wrap(_this.onpagehide);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onpagehide(_this, value) {
  try {
    _this.onpagehide = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onpageshow(_this) {
  try {
    return __dom_wrap(_this.onpageshow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onpageshow(_this, value) {
  try {
    _this.onpageshow = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onpause(_this) {
  try {
    return __dom_wrap(_this.onpause);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onpause(_this, value) {
  try {
    _this.onpause = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onplay(_this) {
  try {
    return __dom_wrap(_this.onplay);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onplay(_this, value) {
  try {
    _this.onplay = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onplaying(_this) {
  try {
    return __dom_wrap(_this.onplaying);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onplaying(_this, value) {
  try {
    _this.onplaying = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onpopstate(_this) {
  try {
    return __dom_wrap(_this.onpopstate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onpopstate(_this, value) {
  try {
    _this.onpopstate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onprogress(_this) {
  try {
    return __dom_wrap(_this.onprogress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onprogress(_this, value) {
  try {
    _this.onprogress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onratechange(_this) {
  try {
    return __dom_wrap(_this.onratechange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onratechange(_this, value) {
  try {
    _this.onratechange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onreset(_this) {
  try {
    return __dom_wrap(_this.onreset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onreset(_this, value) {
  try {
    _this.onreset = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onresize(_this) {
  try {
    return __dom_wrap(_this.onresize);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onresize(_this, value) {
  try {
    _this.onresize = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onscroll(_this) {
  try {
    return __dom_wrap(_this.onscroll);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onscroll(_this, value) {
  try {
    _this.onscroll = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onsearch(_this) {
  try {
    return __dom_wrap(_this.onsearch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onsearch(_this, value) {
  try {
    _this.onsearch = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onseeked(_this) {
  try {
    return __dom_wrap(_this.onseeked);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onseeked(_this, value) {
  try {
    _this.onseeked = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onseeking(_this) {
  try {
    return __dom_wrap(_this.onseeking);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onseeking(_this, value) {
  try {
    _this.onseeking = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onselect(_this) {
  try {
    return __dom_wrap(_this.onselect);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onselect(_this, value) {
  try {
    _this.onselect = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onstalled(_this) {
  try {
    return __dom_wrap(_this.onstalled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onstalled(_this, value) {
  try {
    _this.onstalled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onstorage(_this) {
  try {
    return __dom_wrap(_this.onstorage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onstorage(_this, value) {
  try {
    _this.onstorage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onsubmit(_this) {
  try {
    return __dom_wrap(_this.onsubmit);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onsubmit(_this, value) {
  try {
    _this.onsubmit = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onsuspend(_this) {
  try {
    return __dom_wrap(_this.onsuspend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onsuspend(_this, value) {
  try {
    _this.onsuspend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ontimeupdate(_this) {
  try {
    return __dom_wrap(_this.ontimeupdate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ontimeupdate(_this, value) {
  try {
    _this.ontimeupdate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ontouchcancel(_this) {
  try {
    return __dom_wrap(_this.ontouchcancel);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ontouchcancel(_this, value) {
  try {
    _this.ontouchcancel = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ontouchend(_this) {
  try {
    return __dom_wrap(_this.ontouchend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ontouchend(_this, value) {
  try {
    _this.ontouchend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ontouchmove(_this) {
  try {
    return __dom_wrap(_this.ontouchmove);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ontouchmove(_this, value) {
  try {
    _this.ontouchmove = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__ontouchstart(_this) {
  try {
    return __dom_wrap(_this.ontouchstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__ontouchstart(_this, value) {
  try {
    _this.ontouchstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onunload(_this) {
  try {
    return __dom_wrap(_this.onunload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onunload(_this, value) {
  try {
    _this.onunload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onvolumechange(_this) {
  try {
    return __dom_wrap(_this.onvolumechange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onvolumechange(_this, value) {
  try {
    _this.onvolumechange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onwaiting(_this) {
  try {
    return __dom_wrap(_this.onwaiting);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onwaiting(_this, value) {
  try {
    _this.onwaiting = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onwebkitanimationend(_this) {
  try {
    return __dom_wrap(_this.onwebkitanimationend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onwebkitanimationend(_this, value) {
  try {
    _this.onwebkitanimationend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onwebkitanimationiteration(_this) {
  try {
    return __dom_wrap(_this.onwebkitanimationiteration);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onwebkitanimationiteration(_this, value) {
  try {
    _this.onwebkitanimationiteration = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onwebkitanimationstart(_this) {
  try {
    return __dom_wrap(_this.onwebkitanimationstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onwebkitanimationstart(_this, value) {
  try {
    _this.onwebkitanimationstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__onwebkittransitionend(_this) {
  try {
    return __dom_wrap(_this.onwebkittransitionend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__onwebkittransitionend(_this, value) {
  try {
    _this.onwebkittransitionend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__opener(_this) {
  try {
    return __dom_wrap(_this.opener);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__opener(_this, value) {
  try {
    _this.opener = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__outerHeight(_this) {
  try {
    return __dom_wrap(_this.outerHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__outerHeight(_this, value) {
  try {
    _this.outerHeight = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__outerWidth(_this) {
  try {
    return __dom_wrap(_this.outerWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__outerWidth(_this, value) {
  try {
    _this.outerWidth = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__pageXOffset(_this) {
  try {
    return __dom_wrap(_this.pageXOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__pageYOffset(_this) {
  try {
    return __dom_wrap(_this.pageYOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__parent(_this) {
  try {
    return __dom_wrap(_this.parent);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__parent(_this, value) {
  try {
    _this.parent = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__performance(_this) {
  try {
    return __dom_wrap(_this.performance);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__performance(_this, value) {
  try {
    _this.performance = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__personalbar(_this) {
  try {
    return __dom_wrap(_this.personalbar);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__personalbar(_this, value) {
  try {
    _this.personalbar = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__screen(_this) {
  try {
    return __dom_wrap(_this.screen);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__screen(_this, value) {
  try {
    _this.screen = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__screenLeft(_this) {
  try {
    return __dom_wrap(_this.screenLeft);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__screenLeft(_this, value) {
  try {
    _this.screenLeft = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__screenTop(_this) {
  try {
    return __dom_wrap(_this.screenTop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__screenTop(_this, value) {
  try {
    _this.screenTop = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__screenX(_this) {
  try {
    return __dom_wrap(_this.screenX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__screenX(_this, value) {
  try {
    _this.screenX = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__screenY(_this) {
  try {
    return __dom_wrap(_this.screenY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__screenY(_this, value) {
  try {
    _this.screenY = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__scrollX(_this) {
  try {
    return __dom_wrap(_this.scrollX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__scrollX(_this, value) {
  try {
    _this.scrollX = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__scrollY(_this) {
  try {
    return __dom_wrap(_this.scrollY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__scrollY(_this, value) {
  try {
    _this.scrollY = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__scrollbars(_this) {
  try {
    return __dom_wrap(_this.scrollbars);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__scrollbars(_this, value) {
  try {
    _this.scrollbars = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__self(_this) {
  try {
    return __dom_wrap(_this.self);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__self(_this, value) {
  try {
    _this.self = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__sessionStorage(_this) {
  try {
    return __dom_wrap(_this.sessionStorage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__status(_this) {
  try {
    return __dom_wrap(_this.status);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__status(_this, value) {
  try {
    _this.status = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__statusbar(_this) {
  try {
    return __dom_wrap(_this.statusbar);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__statusbar(_this, value) {
  try {
    _this.statusbar = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__styleMedia(_this) {
  try {
    return __dom_wrap(_this.styleMedia);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__toolbar(_this) {
  try {
    return __dom_wrap(_this.toolbar);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__toolbar(_this, value) {
  try {
    _this.toolbar = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__top(_this) {
  try {
    return __dom_wrap(_this.top);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__set__top(_this, value) {
  try {
    _this.top = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__webkitNotifications(_this) {
  try {
    return __dom_wrap(_this.webkitNotifications);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__window(_this) {
  try {
    return __dom_wrap(_this.window);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__alert(_this) {
  try {
    return __dom_wrap(_this.alert());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__alert_2(_this, message) {
  try {
    return __dom_wrap(_this.alert(__dom_unwrap(message)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__atob(_this) {
  try {
    return __dom_wrap(_this.atob());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__atob_2(_this, string) {
  try {
    return __dom_wrap(_this.atob(__dom_unwrap(string)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__blur(_this) {
  try {
    return __dom_wrap(_this.blur());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__btoa(_this) {
  try {
    return __dom_wrap(_this.btoa());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__btoa_2(_this, string) {
  try {
    return __dom_wrap(_this.btoa(__dom_unwrap(string)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__captureEvents(_this) {
  try {
    return __dom_wrap(_this.captureEvents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__clearInterval(_this) {
  try {
    return __dom_wrap(_this.clearInterval());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__clearInterval_2(_this, handle) {
  try {
    return __dom_wrap(_this.clearInterval(__dom_unwrap(handle)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__clearTimeout(_this) {
  try {
    return __dom_wrap(_this.clearTimeout());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__clearTimeout_2(_this, handle) {
  try {
    return __dom_wrap(_this.clearTimeout(__dom_unwrap(handle)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__close(_this) {
  try {
    return __dom_wrap(_this.close());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__confirm(_this) {
  try {
    return __dom_wrap(_this.confirm());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__confirm_2(_this, message) {
  try {
    return __dom_wrap(_this.confirm(__dom_unwrap(message)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__createFileReader(_this) {
  try {
    return __dom_wrap(_this.createFileReader());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__createWebKitCSSMatrix(_this) {
  try {
    return __dom_wrap(_this.createWebKitCSSMatrix());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__createWebKitCSSMatrix_2(_this, cssValue) {
  try {
    return __dom_wrap(_this.createWebKitCSSMatrix(__dom_unwrap(cssValue)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__createWebKitPoint(_this, x, y) {
  try {
    return __dom_wrap(_this.createWebKitPoint(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__createXMLHttpRequest(_this) {
  try {
    return __dom_wrap(_this.createXMLHttpRequest());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__find(_this) {
  try {
    return __dom_wrap(_this.find());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__find_2(_this, string) {
  try {
    return __dom_wrap(_this.find(__dom_unwrap(string)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__find_3(_this, string, caseSensitive) {
  try {
    return __dom_wrap(_this.find(__dom_unwrap(string), __dom_unwrap(caseSensitive)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__find_4(_this, string, caseSensitive, backwards) {
  try {
    return __dom_wrap(_this.find(__dom_unwrap(string), __dom_unwrap(caseSensitive), __dom_unwrap(backwards)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__find_5(_this, string, caseSensitive, backwards, wrap) {
  try {
    return __dom_wrap(_this.find(__dom_unwrap(string), __dom_unwrap(caseSensitive), __dom_unwrap(backwards), __dom_unwrap(wrap)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__find_6(_this, string, caseSensitive, backwards, wrap, wholeWord) {
  try {
    return __dom_wrap(_this.find(__dom_unwrap(string), __dom_unwrap(caseSensitive), __dom_unwrap(backwards), __dom_unwrap(wrap), __dom_unwrap(wholeWord)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__find_7(_this, string, caseSensitive, backwards, wrap, wholeWord, searchInFrames) {
  try {
    return __dom_wrap(_this.find(__dom_unwrap(string), __dom_unwrap(caseSensitive), __dom_unwrap(backwards), __dom_unwrap(wrap), __dom_unwrap(wholeWord), __dom_unwrap(searchInFrames)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__find_8(_this, string, caseSensitive, backwards, wrap, wholeWord, searchInFrames, showDialog) {
  try {
    return __dom_wrap(_this.find(__dom_unwrap(string), __dom_unwrap(caseSensitive), __dom_unwrap(backwards), __dom_unwrap(wrap), __dom_unwrap(wholeWord), __dom_unwrap(searchInFrames), __dom_unwrap(showDialog)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__focus(_this) {
  try {
    return __dom_wrap(_this.focus());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__getComputedStyle(_this) {
  try {
    return __dom_wrap(_this.getComputedStyle());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__getComputedStyle_2(_this, element) {
  try {
    return __dom_wrap(_this.getComputedStyle(__dom_unwrap(element)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__getComputedStyle_3(_this, element, pseudoElement) {
  try {
    return __dom_wrap(_this.getComputedStyle(__dom_unwrap(element), __dom_unwrap(pseudoElement)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__getSelection(_this) {
  try {
    return __dom_wrap(_this.getSelection());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__matchMedia(_this, query) {
  try {
    return __dom_wrap(_this.matchMedia(__dom_unwrap(query)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__moveBy(_this, x, y) {
  try {
    return __dom_wrap(_this.moveBy(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__moveTo(_this, x, y) {
  try {
    return __dom_wrap(_this.moveTo(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__open(_this, url, target) {
  try {
    return __dom_wrap(_this.open(__dom_unwrap(url), __dom_unwrap(target)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__open_2(_this, url, target, features) {
  try {
    return __dom_wrap(_this.open(__dom_unwrap(url), __dom_unwrap(target), __dom_unwrap(features)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__postMessage(_this, message) {
  try {
    return __dom_wrap(_this.postMessage(__dom_unwrap(message)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__postMessage_2(_this, message, messagePort, targetOrigin) {
  try {
    return __dom_wrap(_this.postMessage(__dom_unwrap(message), __dom_unwrap(messagePort), __dom_unwrap(targetOrigin)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__print(_this) {
  try {
    return __dom_wrap(_this.print());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__prompt(_this) {
  try {
    return __dom_wrap(_this.prompt());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__prompt_2(_this, message) {
  try {
    return __dom_wrap(_this.prompt(__dom_unwrap(message)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__prompt_3(_this, message, defaultValue) {
  try {
    return __dom_wrap(_this.prompt(__dom_unwrap(message), __dom_unwrap(defaultValue)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__releaseEvents(_this) {
  try {
    return __dom_wrap(_this.releaseEvents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__resizeBy(_this, x, y) {
  try {
    return __dom_wrap(_this.resizeBy(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__resizeTo(_this, width, height) {
  try {
    return __dom_wrap(_this.resizeTo(__dom_unwrap(width), __dom_unwrap(height)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__scroll(_this, x, y) {
  try {
    return __dom_wrap(_this.scroll(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__scrollBy(_this, x, y) {
  try {
    return __dom_wrap(_this.scrollBy(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__scrollTo(_this, x, y) {
  try {
    return __dom_wrap(_this.scrollTo(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__setInterval(_this, handler, timeout) {
  try {
    return __dom_wrap(_this.setInterval(__dom_unwrap(handler), __dom_unwrap(timeout)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__setTimeout(_this) {
  try {
    return __dom_wrap(_this.setTimeout());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__setTimeout_2(_this, handler) {
  try {
    return __dom_wrap(_this.setTimeout(__dom_unwrap(handler)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__setTimeout_3(_this, handler, timeout) {
  try {
    return __dom_wrap(_this.setTimeout(__dom_unwrap(handler), __dom_unwrap(timeout)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__showModalDialog(_this, url) {
  try {
    return __dom_wrap(_this.showModalDialog(__dom_unwrap(url)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__showModalDialog_2(_this, url, dialogArgs) {
  try {
    return __dom_wrap(_this.showModalDialog(__dom_unwrap(url), __dom_unwrap(dialogArgs)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__showModalDialog_3(_this, url, dialogArgs, featureArgs) {
  try {
    return __dom_wrap(_this.showModalDialog(__dom_unwrap(url), __dom_unwrap(dialogArgs), __dom_unwrap(featureArgs)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__stop(_this) {
  try {
    return __dom_wrap(_this.stop());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitCancelRequestAnimationFrame(_this, id) {
  try {
    return __dom_wrap(_this.webkitCancelRequestAnimationFrame(__dom_unwrap(id)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitConvertPointFromNodeToPage(_this) {
  try {
    return __dom_wrap(_this.webkitConvertPointFromNodeToPage());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitConvertPointFromNodeToPage_2(_this, node) {
  try {
    return __dom_wrap(_this.webkitConvertPointFromNodeToPage(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitConvertPointFromNodeToPage_3(_this, node, p) {
  try {
    return __dom_wrap(_this.webkitConvertPointFromNodeToPage(__dom_unwrap(node), __dom_unwrap(p)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitConvertPointFromPageToNode(_this) {
  try {
    return __dom_wrap(_this.webkitConvertPointFromPageToNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitConvertPointFromPageToNode_2(_this, node) {
  try {
    return __dom_wrap(_this.webkitConvertPointFromPageToNode(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitConvertPointFromPageToNode_3(_this, node, p) {
  try {
    return __dom_wrap(_this.webkitConvertPointFromPageToNode(__dom_unwrap(node), __dom_unwrap(p)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitRequestAnimationFrame(_this, callback) {
  try {
    return __dom_wrap(_this.webkitRequestAnimationFrame(__dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__webkitRequestAnimationFrame_2(_this, callback, element) {
  try {
    return __dom_wrap(_this.webkitRequestAnimationFrame(__dom_unwrap(callback), __dom_unwrap(element)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemWrappingImplementation__get__kind(_this) {
  try {
    return __dom_wrap(_this.kind);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemWrappingImplementation__getAsFile(_this) {
  try {
    return __dom_wrap(_this.getAsFile());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemWrappingImplementation__getAsString(_this) {
  try {
    return __dom_wrap(_this.getAsString());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemWrappingImplementation__getAsString_2(_this, callback) {
  try {
    return __dom_wrap(_this.getAsString(__dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemsWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemsWrappingImplementation__add(_this) {
  try {
    return __dom_wrap(_this.add());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemsWrappingImplementation__add_2(_this, data) {
  try {
    return __dom_wrap(_this.add(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemsWrappingImplementation__add_3(_this, data, type) {
  try {
    return __dom_wrap(_this.add(__dom_unwrap(data), __dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemsWrappingImplementation__clear(_this) {
  try {
    return __dom_wrap(_this.clear());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataTransferItemsWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getFloat32(_this, byteOffset) {
  try {
    return __dom_wrap(_this.getFloat32(__dom_unwrap(byteOffset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getFloat32_2(_this, byteOffset, littleEndian) {
  try {
    return __dom_wrap(_this.getFloat32(__dom_unwrap(byteOffset), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getFloat64(_this, byteOffset) {
  try {
    return __dom_wrap(_this.getFloat64(__dom_unwrap(byteOffset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getFloat64_2(_this, byteOffset, littleEndian) {
  try {
    return __dom_wrap(_this.getFloat64(__dom_unwrap(byteOffset), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getInt16(_this, byteOffset) {
  try {
    return __dom_wrap(_this.getInt16(__dom_unwrap(byteOffset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getInt16_2(_this, byteOffset, littleEndian) {
  try {
    return __dom_wrap(_this.getInt16(__dom_unwrap(byteOffset), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getInt32(_this, byteOffset) {
  try {
    return __dom_wrap(_this.getInt32(__dom_unwrap(byteOffset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getInt32_2(_this, byteOffset, littleEndian) {
  try {
    return __dom_wrap(_this.getInt32(__dom_unwrap(byteOffset), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getInt8(_this) {
  try {
    return __dom_wrap(_this.getInt8());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getUint16(_this, byteOffset) {
  try {
    return __dom_wrap(_this.getUint16(__dom_unwrap(byteOffset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getUint16_2(_this, byteOffset, littleEndian) {
  try {
    return __dom_wrap(_this.getUint16(__dom_unwrap(byteOffset), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getUint32(_this, byteOffset) {
  try {
    return __dom_wrap(_this.getUint32(__dom_unwrap(byteOffset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getUint32_2(_this, byteOffset, littleEndian) {
  try {
    return __dom_wrap(_this.getUint32(__dom_unwrap(byteOffset), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__getUint8(_this) {
  try {
    return __dom_wrap(_this.getUint8());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setFloat32(_this, byteOffset, value) {
  try {
    return __dom_wrap(_this.setFloat32(__dom_unwrap(byteOffset), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setFloat32_2(_this, byteOffset, value, littleEndian) {
  try {
    return __dom_wrap(_this.setFloat32(__dom_unwrap(byteOffset), __dom_unwrap(value), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setFloat64(_this, byteOffset, value) {
  try {
    return __dom_wrap(_this.setFloat64(__dom_unwrap(byteOffset), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setFloat64_2(_this, byteOffset, value, littleEndian) {
  try {
    return __dom_wrap(_this.setFloat64(__dom_unwrap(byteOffset), __dom_unwrap(value), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setInt16(_this, byteOffset, value) {
  try {
    return __dom_wrap(_this.setInt16(__dom_unwrap(byteOffset), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setInt16_2(_this, byteOffset, value, littleEndian) {
  try {
    return __dom_wrap(_this.setInt16(__dom_unwrap(byteOffset), __dom_unwrap(value), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setInt32(_this, byteOffset, value) {
  try {
    return __dom_wrap(_this.setInt32(__dom_unwrap(byteOffset), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setInt32_2(_this, byteOffset, value, littleEndian) {
  try {
    return __dom_wrap(_this.setInt32(__dom_unwrap(byteOffset), __dom_unwrap(value), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setInt8(_this) {
  try {
    return __dom_wrap(_this.setInt8());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setUint16(_this, byteOffset, value) {
  try {
    return __dom_wrap(_this.setUint16(__dom_unwrap(byteOffset), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setUint16_2(_this, byteOffset, value, littleEndian) {
  try {
    return __dom_wrap(_this.setUint16(__dom_unwrap(byteOffset), __dom_unwrap(value), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setUint32(_this, byteOffset, value) {
  try {
    return __dom_wrap(_this.setUint32(__dom_unwrap(byteOffset), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setUint32_2(_this, byteOffset, value, littleEndian) {
  try {
    return __dom_wrap(_this.setUint32(__dom_unwrap(byteOffset), __dom_unwrap(value), __dom_unwrap(littleEndian)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DataViewWrappingImplementation__setUint8(_this) {
  try {
    return __dom_wrap(_this.setUint8());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__get__version(_this) {
  try {
    return __dom_wrap(_this.version);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__changeVersion(_this, oldVersion, newVersion) {
  try {
    return __dom_wrap(_this.changeVersion(__dom_unwrap(oldVersion), __dom_unwrap(newVersion)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__changeVersion_2(_this, oldVersion, newVersion, callback) {
  try {
    return __dom_wrap(_this.changeVersion(__dom_unwrap(oldVersion), __dom_unwrap(newVersion), __dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__changeVersion_3(_this, oldVersion, newVersion, callback, errorCallback) {
  try {
    return __dom_wrap(_this.changeVersion(__dom_unwrap(oldVersion), __dom_unwrap(newVersion), __dom_unwrap(callback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__changeVersion_4(_this, oldVersion, newVersion, callback, errorCallback, successCallback) {
  try {
    return __dom_wrap(_this.changeVersion(__dom_unwrap(oldVersion), __dom_unwrap(newVersion), __dom_unwrap(callback), __dom_unwrap(errorCallback), __dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__readTransaction(_this, callback) {
  try {
    return __dom_wrap(_this.readTransaction(__dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__readTransaction_2(_this, callback, errorCallback) {
  try {
    return __dom_wrap(_this.readTransaction(__dom_unwrap(callback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__readTransaction_3(_this, callback, errorCallback, successCallback) {
  try {
    return __dom_wrap(_this.readTransaction(__dom_unwrap(callback), __dom_unwrap(errorCallback), __dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__transaction(_this, callback) {
  try {
    return __dom_wrap(_this.transaction(__dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__transaction_2(_this, callback, errorCallback) {
  try {
    return __dom_wrap(_this.transaction(__dom_unwrap(callback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseWrappingImplementation__transaction_3(_this, callback, errorCallback, successCallback) {
  try {
    return __dom_wrap(_this.transaction(__dom_unwrap(callback), __dom_unwrap(errorCallback), __dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseCallbackWrappingImplementation__handleEvent(_this, database) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(database)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseCallbackWrappingImplementation__handleEvent_2(_this, database) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(database)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseSyncWrappingImplementation__get__version(_this) {
  try {
    return __dom_wrap(_this.version);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseSyncWrappingImplementation__changeVersion(_this, oldVersion, newVersion) {
  try {
    return __dom_wrap(_this.changeVersion(__dom_unwrap(oldVersion), __dom_unwrap(newVersion)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseSyncWrappingImplementation__changeVersion_2(_this, oldVersion, newVersion, callback) {
  try {
    return __dom_wrap(_this.changeVersion(__dom_unwrap(oldVersion), __dom_unwrap(newVersion), __dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseSyncWrappingImplementation__readTransaction(_this, callback) {
  try {
    return __dom_wrap(_this.readTransaction(__dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DatabaseSyncWrappingImplementation__transaction(_this, callback) {
  try {
    return __dom_wrap(_this.transaction(__dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DedicatedWorkerContextWrappingImplementation__get__onmessage(_this) {
  try {
    return __dom_wrap(_this.onmessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DedicatedWorkerContextWrappingImplementation__set__onmessage(_this, value) {
  try {
    _this.onmessage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DedicatedWorkerContextWrappingImplementation__postMessage(_this, message) {
  try {
    return __dom_wrap(_this.postMessage(__dom_unwrap(message)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceMotionEventWrappingImplementation__get__interval(_this) {
  try {
    return __dom_wrap(_this.interval);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceMotionEventWrappingImplementation__initDeviceMotionEvent(_this) {
  try {
    return __dom_wrap(_this.initDeviceMotionEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceMotionEventWrappingImplementation__initDeviceMotionEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initDeviceMotionEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceMotionEventWrappingImplementation__initDeviceMotionEvent_3(_this, type, bubbles) {
  try {
    return __dom_wrap(_this.initDeviceMotionEvent(__dom_unwrap(type), __dom_unwrap(bubbles)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceMotionEventWrappingImplementation__initDeviceMotionEvent_4(_this, type, bubbles, cancelable) {
  try {
    return __dom_wrap(_this.initDeviceMotionEvent(__dom_unwrap(type), __dom_unwrap(bubbles), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__get__alpha(_this) {
  try {
    return __dom_wrap(_this.alpha);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__get__beta(_this) {
  try {
    return __dom_wrap(_this.beta);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__get__gamma(_this) {
  try {
    return __dom_wrap(_this.gamma);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__initDeviceOrientationEvent(_this) {
  try {
    return __dom_wrap(_this.initDeviceOrientationEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__initDeviceOrientationEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initDeviceOrientationEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__initDeviceOrientationEvent_3(_this, type, bubbles) {
  try {
    return __dom_wrap(_this.initDeviceOrientationEvent(__dom_unwrap(type), __dom_unwrap(bubbles)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__initDeviceOrientationEvent_4(_this, type, bubbles, cancelable) {
  try {
    return __dom_wrap(_this.initDeviceOrientationEvent(__dom_unwrap(type), __dom_unwrap(bubbles), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__initDeviceOrientationEvent_5(_this, type, bubbles, cancelable, alpha) {
  try {
    return __dom_wrap(_this.initDeviceOrientationEvent(__dom_unwrap(type), __dom_unwrap(bubbles), __dom_unwrap(cancelable), __dom_unwrap(alpha)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__initDeviceOrientationEvent_6(_this, type, bubbles, cancelable, alpha, beta) {
  try {
    return __dom_wrap(_this.initDeviceOrientationEvent(__dom_unwrap(type), __dom_unwrap(bubbles), __dom_unwrap(cancelable), __dom_unwrap(alpha), __dom_unwrap(beta)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DeviceOrientationEventWrappingImplementation__initDeviceOrientationEvent_7(_this, type, bubbles, cancelable, alpha, beta, gamma) {
  try {
    return __dom_wrap(_this.initDeviceOrientationEvent(__dom_unwrap(type), __dom_unwrap(bubbles), __dom_unwrap(cancelable), __dom_unwrap(alpha), __dom_unwrap(beta), __dom_unwrap(gamma)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__createReader(_this) {
  try {
    return __dom_wrap(_this.createReader());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__getDirectory(_this, path) {
  try {
    return __dom_wrap(_this.getDirectory(__dom_unwrap(path)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__getDirectory_2(_this, path, flags) {
  try {
    return __dom_wrap(_this.getDirectory(__dom_unwrap(path), __dom_unwrap(flags)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__getDirectory_3(_this, path, flags, successCallback) {
  try {
    return __dom_wrap(_this.getDirectory(__dom_unwrap(path), __dom_unwrap(flags), __dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__getDirectory_4(_this, path, flags, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.getDirectory(__dom_unwrap(path), __dom_unwrap(flags), __dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__getFile(_this, path) {
  try {
    return __dom_wrap(_this.getFile(__dom_unwrap(path)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__getFile_2(_this, path, flags) {
  try {
    return __dom_wrap(_this.getFile(__dom_unwrap(path), __dom_unwrap(flags)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__getFile_3(_this, path, flags, successCallback) {
  try {
    return __dom_wrap(_this.getFile(__dom_unwrap(path), __dom_unwrap(flags), __dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__getFile_4(_this, path, flags, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.getFile(__dom_unwrap(path), __dom_unwrap(flags), __dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__removeRecursively(_this) {
  try {
    return __dom_wrap(_this.removeRecursively());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__removeRecursively_2(_this, successCallback) {
  try {
    return __dom_wrap(_this.removeRecursively(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntryWrappingImplementation__removeRecursively_3(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.removeRecursively(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntrySyncWrappingImplementation__createReader(_this) {
  try {
    return __dom_wrap(_this.createReader());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntrySyncWrappingImplementation__getDirectory(_this, path, flags) {
  try {
    return __dom_wrap(_this.getDirectory(__dom_unwrap(path), __dom_unwrap(flags)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntrySyncWrappingImplementation__getFile(_this, path, flags) {
  try {
    return __dom_wrap(_this.getFile(__dom_unwrap(path), __dom_unwrap(flags)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryEntrySyncWrappingImplementation__removeRecursively(_this) {
  try {
    return __dom_wrap(_this.removeRecursively());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryReaderWrappingImplementation__readEntries(_this, successCallback) {
  try {
    return __dom_wrap(_this.readEntries(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryReaderWrappingImplementation__readEntries_2(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.readEntries(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DirectoryReaderSyncWrappingImplementation__readEntries(_this) {
  try {
    return __dom_wrap(_this.readEntries());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__URL(_this) {
  try {
    return __dom_wrap(_this.URL);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__anchors(_this) {
  try {
    return __dom_wrap(_this.anchors);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__applets(_this) {
  try {
    return __dom_wrap(_this.applets);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__body(_this) {
  try {
    return __dom_wrap(_this.body);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__body(_this, value) {
  try {
    _this.body = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__characterSet(_this) {
  try {
    return __dom_wrap(_this.characterSet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__charset(_this) {
  try {
    return __dom_wrap(_this.charset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__charset(_this, value) {
  try {
    _this.charset = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__compatMode(_this) {
  try {
    return __dom_wrap(_this.compatMode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__cookie(_this) {
  try {
    return __dom_wrap(_this.cookie);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__cookie(_this, value) {
  try {
    _this.cookie = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__defaultCharset(_this) {
  try {
    return __dom_wrap(_this.defaultCharset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__defaultView(_this) {
  try {
    return __dom_wrap(_this.defaultView);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__doctype(_this) {
  try {
    return __dom_wrap(_this.doctype);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__documentElement(_this) {
  try {
    return __dom_wrap(_this.documentElement);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__documentURI(_this) {
  try {
    return __dom_wrap(_this.documentURI);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__documentURI(_this, value) {
  try {
    _this.documentURI = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__domain(_this) {
  try {
    return __dom_wrap(_this.domain);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__forms(_this) {
  try {
    return __dom_wrap(_this.forms);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__head(_this) {
  try {
    return __dom_wrap(_this.head);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__images(_this) {
  try {
    return __dom_wrap(_this.images);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__implementation(_this) {
  try {
    return __dom_wrap(_this.implementation);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__inputEncoding(_this) {
  try {
    return __dom_wrap(_this.inputEncoding);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__lastModified(_this) {
  try {
    return __dom_wrap(_this.lastModified);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__links(_this) {
  try {
    return __dom_wrap(_this.links);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onbeforecopy(_this) {
  try {
    return __dom_wrap(_this.onbeforecopy);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onbeforecopy(_this, value) {
  try {
    _this.onbeforecopy = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onbeforecut(_this) {
  try {
    return __dom_wrap(_this.onbeforecut);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onbeforecut(_this, value) {
  try {
    _this.onbeforecut = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onbeforepaste(_this) {
  try {
    return __dom_wrap(_this.onbeforepaste);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onbeforepaste(_this, value) {
  try {
    _this.onbeforepaste = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onblur(_this) {
  try {
    return __dom_wrap(_this.onblur);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onblur(_this, value) {
  try {
    _this.onblur = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onchange(_this) {
  try {
    return __dom_wrap(_this.onchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onchange(_this, value) {
  try {
    _this.onchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onclick(_this) {
  try {
    return __dom_wrap(_this.onclick);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onclick(_this, value) {
  try {
    _this.onclick = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__oncontextmenu(_this) {
  try {
    return __dom_wrap(_this.oncontextmenu);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__oncontextmenu(_this, value) {
  try {
    _this.oncontextmenu = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__oncopy(_this) {
  try {
    return __dom_wrap(_this.oncopy);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__oncopy(_this, value) {
  try {
    _this.oncopy = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__oncut(_this) {
  try {
    return __dom_wrap(_this.oncut);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__oncut(_this, value) {
  try {
    _this.oncut = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ondblclick(_this) {
  try {
    return __dom_wrap(_this.ondblclick);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ondblclick(_this, value) {
  try {
    _this.ondblclick = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ondrag(_this) {
  try {
    return __dom_wrap(_this.ondrag);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ondrag(_this, value) {
  try {
    _this.ondrag = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ondragend(_this) {
  try {
    return __dom_wrap(_this.ondragend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ondragend(_this, value) {
  try {
    _this.ondragend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ondragenter(_this) {
  try {
    return __dom_wrap(_this.ondragenter);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ondragenter(_this, value) {
  try {
    _this.ondragenter = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ondragleave(_this) {
  try {
    return __dom_wrap(_this.ondragleave);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ondragleave(_this, value) {
  try {
    _this.ondragleave = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ondragover(_this) {
  try {
    return __dom_wrap(_this.ondragover);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ondragover(_this, value) {
  try {
    _this.ondragover = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ondragstart(_this) {
  try {
    return __dom_wrap(_this.ondragstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ondragstart(_this, value) {
  try {
    _this.ondragstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ondrop(_this) {
  try {
    return __dom_wrap(_this.ondrop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ondrop(_this, value) {
  try {
    _this.ondrop = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onfocus(_this) {
  try {
    return __dom_wrap(_this.onfocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onfocus(_this, value) {
  try {
    _this.onfocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__oninput(_this) {
  try {
    return __dom_wrap(_this.oninput);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__oninput(_this, value) {
  try {
    _this.oninput = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__oninvalid(_this) {
  try {
    return __dom_wrap(_this.oninvalid);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__oninvalid(_this, value) {
  try {
    _this.oninvalid = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onkeydown(_this) {
  try {
    return __dom_wrap(_this.onkeydown);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onkeydown(_this, value) {
  try {
    _this.onkeydown = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onkeypress(_this) {
  try {
    return __dom_wrap(_this.onkeypress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onkeypress(_this, value) {
  try {
    _this.onkeypress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onkeyup(_this) {
  try {
    return __dom_wrap(_this.onkeyup);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onkeyup(_this, value) {
  try {
    _this.onkeyup = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onload(_this) {
  try {
    return __dom_wrap(_this.onload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onload(_this, value) {
  try {
    _this.onload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onmousedown(_this) {
  try {
    return __dom_wrap(_this.onmousedown);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onmousedown(_this, value) {
  try {
    _this.onmousedown = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onmousemove(_this) {
  try {
    return __dom_wrap(_this.onmousemove);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onmousemove(_this, value) {
  try {
    _this.onmousemove = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onmouseout(_this) {
  try {
    return __dom_wrap(_this.onmouseout);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onmouseout(_this, value) {
  try {
    _this.onmouseout = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onmouseover(_this) {
  try {
    return __dom_wrap(_this.onmouseover);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onmouseover(_this, value) {
  try {
    _this.onmouseover = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onmouseup(_this) {
  try {
    return __dom_wrap(_this.onmouseup);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onmouseup(_this, value) {
  try {
    _this.onmouseup = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onmousewheel(_this) {
  try {
    return __dom_wrap(_this.onmousewheel);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onmousewheel(_this, value) {
  try {
    _this.onmousewheel = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onpaste(_this) {
  try {
    return __dom_wrap(_this.onpaste);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onpaste(_this, value) {
  try {
    _this.onpaste = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onreadystatechange(_this) {
  try {
    return __dom_wrap(_this.onreadystatechange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onreadystatechange(_this, value) {
  try {
    _this.onreadystatechange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onreset(_this) {
  try {
    return __dom_wrap(_this.onreset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onreset(_this, value) {
  try {
    _this.onreset = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onscroll(_this) {
  try {
    return __dom_wrap(_this.onscroll);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onscroll(_this, value) {
  try {
    _this.onscroll = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onsearch(_this) {
  try {
    return __dom_wrap(_this.onsearch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onsearch(_this, value) {
  try {
    _this.onsearch = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onselect(_this) {
  try {
    return __dom_wrap(_this.onselect);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onselect(_this, value) {
  try {
    _this.onselect = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onselectionchange(_this) {
  try {
    return __dom_wrap(_this.onselectionchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onselectionchange(_this, value) {
  try {
    _this.onselectionchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onselectstart(_this) {
  try {
    return __dom_wrap(_this.onselectstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onselectstart(_this, value) {
  try {
    _this.onselectstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onsubmit(_this) {
  try {
    return __dom_wrap(_this.onsubmit);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onsubmit(_this, value) {
  try {
    _this.onsubmit = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ontouchcancel(_this) {
  try {
    return __dom_wrap(_this.ontouchcancel);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ontouchcancel(_this, value) {
  try {
    _this.ontouchcancel = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ontouchend(_this) {
  try {
    return __dom_wrap(_this.ontouchend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ontouchend(_this, value) {
  try {
    _this.ontouchend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ontouchmove(_this) {
  try {
    return __dom_wrap(_this.ontouchmove);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ontouchmove(_this, value) {
  try {
    _this.ontouchmove = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__ontouchstart(_this) {
  try {
    return __dom_wrap(_this.ontouchstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__ontouchstart(_this, value) {
  try {
    _this.ontouchstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__onwebkitfullscreenchange(_this) {
  try {
    return __dom_wrap(_this.onwebkitfullscreenchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__onwebkitfullscreenchange(_this, value) {
  try {
    _this.onwebkitfullscreenchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__preferredStylesheetSet(_this) {
  try {
    return __dom_wrap(_this.preferredStylesheetSet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__referrer(_this) {
  try {
    return __dom_wrap(_this.referrer);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__selectedStylesheetSet(_this) {
  try {
    return __dom_wrap(_this.selectedStylesheetSet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__selectedStylesheetSet(_this, value) {
  try {
    _this.selectedStylesheetSet = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__styleSheets(_this) {
  try {
    return __dom_wrap(_this.styleSheets);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__title(_this) {
  try {
    return __dom_wrap(_this.title);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__title(_this, value) {
  try {
    _this.title = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__webkitHidden(_this) {
  try {
    return __dom_wrap(_this.webkitHidden);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__webkitVisibilityState(_this) {
  try {
    return __dom_wrap(_this.webkitVisibilityState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__xmlEncoding(_this) {
  try {
    return __dom_wrap(_this.xmlEncoding);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__xmlStandalone(_this) {
  try {
    return __dom_wrap(_this.xmlStandalone);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__xmlStandalone(_this, value) {
  try {
    _this.xmlStandalone = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__get__xmlVersion(_this) {
  try {
    return __dom_wrap(_this.xmlVersion);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__set__xmlVersion(_this, value) {
  try {
    _this.xmlVersion = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__adoptNode(_this) {
  try {
    return __dom_wrap(_this.adoptNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__adoptNode_2(_this, source) {
  try {
    return __dom_wrap(_this.adoptNode(__dom_unwrap(source)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__caretRangeFromPoint(_this) {
  try {
    return __dom_wrap(_this.caretRangeFromPoint());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__caretRangeFromPoint_2(_this, x) {
  try {
    return __dom_wrap(_this.caretRangeFromPoint(__dom_unwrap(x)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__caretRangeFromPoint_3(_this, x, y) {
  try {
    return __dom_wrap(_this.caretRangeFromPoint(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createAttribute(_this) {
  try {
    return __dom_wrap(_this.createAttribute());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createAttribute_2(_this, name) {
  try {
    return __dom_wrap(_this.createAttribute(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createAttributeNS(_this) {
  try {
    return __dom_wrap(_this.createAttributeNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createAttributeNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.createAttributeNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createAttributeNS_3(_this, namespaceURI, qualifiedName) {
  try {
    return __dom_wrap(_this.createAttributeNS(__dom_unwrap(namespaceURI), __dom_unwrap(qualifiedName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createCDATASection(_this) {
  try {
    return __dom_wrap(_this.createCDATASection());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createCDATASection_2(_this, data) {
  try {
    return __dom_wrap(_this.createCDATASection(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createCSSStyleDeclaration(_this) {
  try {
    return __dom_wrap(_this.createCSSStyleDeclaration());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createComment(_this) {
  try {
    return __dom_wrap(_this.createComment());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createComment_2(_this, data) {
  try {
    return __dom_wrap(_this.createComment(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createDocumentFragment(_this) {
  try {
    return __dom_wrap(_this.createDocumentFragment());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createElement(_this) {
  try {
    return __dom_wrap(_this.createElement());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createElement_2(_this, tagName) {
  try {
    return __dom_wrap(_this.createElement(__dom_unwrap(tagName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createElementNS(_this) {
  try {
    return __dom_wrap(_this.createElementNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createElementNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.createElementNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createElementNS_3(_this, namespaceURI, qualifiedName) {
  try {
    return __dom_wrap(_this.createElementNS(__dom_unwrap(namespaceURI), __dom_unwrap(qualifiedName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createEntityReference(_this) {
  try {
    return __dom_wrap(_this.createEntityReference());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createEntityReference_2(_this, name) {
  try {
    return __dom_wrap(_this.createEntityReference(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createEvent(_this) {
  try {
    return __dom_wrap(_this.createEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createEvent_2(_this, eventType) {
  try {
    return __dom_wrap(_this.createEvent(__dom_unwrap(eventType)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createNodeIterator(_this) {
  try {
    return __dom_wrap(_this.createNodeIterator());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createNodeIterator_2(_this, root) {
  try {
    return __dom_wrap(_this.createNodeIterator(__dom_unwrap(root)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createNodeIterator_3(_this, root, whatToShow) {
  try {
    return __dom_wrap(_this.createNodeIterator(__dom_unwrap(root), __dom_unwrap(whatToShow)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createNodeIterator_4(_this, root, whatToShow, filter) {
  try {
    return __dom_wrap(_this.createNodeIterator(__dom_unwrap(root), __dom_unwrap(whatToShow), __dom_unwrap(filter)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createNodeIterator_5(_this, root, whatToShow, filter, entityReferenceExpansion) {
  try {
    return __dom_wrap(_this.createNodeIterator(__dom_unwrap(root), __dom_unwrap(whatToShow), __dom_unwrap(filter), __dom_unwrap(entityReferenceExpansion)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createProcessingInstruction(_this) {
  try {
    return __dom_wrap(_this.createProcessingInstruction());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createProcessingInstruction_2(_this, target) {
  try {
    return __dom_wrap(_this.createProcessingInstruction(__dom_unwrap(target)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createProcessingInstruction_3(_this, target, data) {
  try {
    return __dom_wrap(_this.createProcessingInstruction(__dom_unwrap(target), __dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createRange(_this) {
  try {
    return __dom_wrap(_this.createRange());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createTextNode(_this) {
  try {
    return __dom_wrap(_this.createTextNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createTextNode_2(_this, data) {
  try {
    return __dom_wrap(_this.createTextNode(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createTreeWalker(_this) {
  try {
    return __dom_wrap(_this.createTreeWalker());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createTreeWalker_2(_this, root) {
  try {
    return __dom_wrap(_this.createTreeWalker(__dom_unwrap(root)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createTreeWalker_3(_this, root, whatToShow) {
  try {
    return __dom_wrap(_this.createTreeWalker(__dom_unwrap(root), __dom_unwrap(whatToShow)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createTreeWalker_4(_this, root, whatToShow, filter) {
  try {
    return __dom_wrap(_this.createTreeWalker(__dom_unwrap(root), __dom_unwrap(whatToShow), __dom_unwrap(filter)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__createTreeWalker_5(_this, root, whatToShow, filter, entityReferenceExpansion) {
  try {
    return __dom_wrap(_this.createTreeWalker(__dom_unwrap(root), __dom_unwrap(whatToShow), __dom_unwrap(filter), __dom_unwrap(entityReferenceExpansion)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__elementFromPoint(_this) {
  try {
    return __dom_wrap(_this.elementFromPoint());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__elementFromPoint_2(_this, x) {
  try {
    return __dom_wrap(_this.elementFromPoint(__dom_unwrap(x)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__elementFromPoint_3(_this, x, y) {
  try {
    return __dom_wrap(_this.elementFromPoint(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__execCommand(_this) {
  try {
    return __dom_wrap(_this.execCommand());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__execCommand_2(_this, command) {
  try {
    return __dom_wrap(_this.execCommand(__dom_unwrap(command)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__execCommand_3(_this, command, userInterface) {
  try {
    return __dom_wrap(_this.execCommand(__dom_unwrap(command), __dom_unwrap(userInterface)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__execCommand_4(_this, command, userInterface, value) {
  try {
    return __dom_wrap(_this.execCommand(__dom_unwrap(command), __dom_unwrap(userInterface), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getCSSCanvasContext(_this, contextId, name, width, height) {
  try {
    return __dom_wrap(_this.getCSSCanvasContext(__dom_unwrap(contextId), __dom_unwrap(name), __dom_unwrap(width), __dom_unwrap(height)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementById(_this) {
  try {
    return __dom_wrap(_this.getElementById());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementById_2(_this, elementId) {
  try {
    return __dom_wrap(_this.getElementById(__dom_unwrap(elementId)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByClassName(_this) {
  try {
    return __dom_wrap(_this.getElementsByClassName());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByClassName_2(_this, tagname) {
  try {
    return __dom_wrap(_this.getElementsByClassName(__dom_unwrap(tagname)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByName(_this) {
  try {
    return __dom_wrap(_this.getElementsByName());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByName_2(_this, elementName) {
  try {
    return __dom_wrap(_this.getElementsByName(__dom_unwrap(elementName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByTagName(_this) {
  try {
    return __dom_wrap(_this.getElementsByTagName());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByTagName_2(_this, tagname) {
  try {
    return __dom_wrap(_this.getElementsByTagName(__dom_unwrap(tagname)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByTagNameNS(_this) {
  try {
    return __dom_wrap(_this.getElementsByTagNameNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByTagNameNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.getElementsByTagNameNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getElementsByTagNameNS_3(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.getElementsByTagNameNS(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getOverrideStyle(_this) {
  try {
    return __dom_wrap(_this.getOverrideStyle());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getOverrideStyle_2(_this, element) {
  try {
    return __dom_wrap(_this.getOverrideStyle(__dom_unwrap(element)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__getOverrideStyle_3(_this, element, pseudoElement) {
  try {
    return __dom_wrap(_this.getOverrideStyle(__dom_unwrap(element), __dom_unwrap(pseudoElement)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__importNode(_this) {
  try {
    return __dom_wrap(_this.importNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__importNode_2(_this, importedNode) {
  try {
    return __dom_wrap(_this.importNode(__dom_unwrap(importedNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__importNode_3(_this, importedNode, deep) {
  try {
    return __dom_wrap(_this.importNode(__dom_unwrap(importedNode), __dom_unwrap(deep)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandEnabled(_this) {
  try {
    return __dom_wrap(_this.queryCommandEnabled());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandEnabled_2(_this, command) {
  try {
    return __dom_wrap(_this.queryCommandEnabled(__dom_unwrap(command)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandIndeterm(_this) {
  try {
    return __dom_wrap(_this.queryCommandIndeterm());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandIndeterm_2(_this, command) {
  try {
    return __dom_wrap(_this.queryCommandIndeterm(__dom_unwrap(command)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandState(_this) {
  try {
    return __dom_wrap(_this.queryCommandState());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandState_2(_this, command) {
  try {
    return __dom_wrap(_this.queryCommandState(__dom_unwrap(command)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandSupported(_this) {
  try {
    return __dom_wrap(_this.queryCommandSupported());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandSupported_2(_this, command) {
  try {
    return __dom_wrap(_this.queryCommandSupported(__dom_unwrap(command)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandValue(_this) {
  try {
    return __dom_wrap(_this.queryCommandValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__queryCommandValue_2(_this, command) {
  try {
    return __dom_wrap(_this.queryCommandValue(__dom_unwrap(command)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__querySelector(_this, selectors) {
  try {
    return __dom_wrap(_this.querySelector(__dom_unwrap(selectors)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentWrappingImplementation__querySelectorAll(_this, selectors) {
  try {
    return __dom_wrap(_this.querySelectorAll(__dom_unwrap(selectors)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentFragmentWrappingImplementation__querySelector(_this, selectors) {
  try {
    return __dom_wrap(_this.querySelector(__dom_unwrap(selectors)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentFragmentWrappingImplementation__querySelectorAll(_this, selectors) {
  try {
    return __dom_wrap(_this.querySelectorAll(__dom_unwrap(selectors)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentTypeWrappingImplementation__get__entities(_this) {
  try {
    return __dom_wrap(_this.entities);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentTypeWrappingImplementation__get__internalSubset(_this) {
  try {
    return __dom_wrap(_this.internalSubset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentTypeWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentTypeWrappingImplementation__get__notations(_this) {
  try {
    return __dom_wrap(_this.notations);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentTypeWrappingImplementation__get__publicId(_this) {
  try {
    return __dom_wrap(_this.publicId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DocumentTypeWrappingImplementation__get__systemId(_this) {
  try {
    return __dom_wrap(_this.systemId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__childElementCount(_this) {
  try {
    return __dom_wrap(_this.childElementCount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__clientHeight(_this) {
  try {
    return __dom_wrap(_this.clientHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__clientLeft(_this) {
  try {
    return __dom_wrap(_this.clientLeft);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__clientTop(_this) {
  try {
    return __dom_wrap(_this.clientTop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__clientWidth(_this) {
  try {
    return __dom_wrap(_this.clientWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__firstElementChild(_this) {
  try {
    return __dom_wrap(_this.firstElementChild);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__lastElementChild(_this) {
  try {
    return __dom_wrap(_this.lastElementChild);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__nextElementSibling(_this) {
  try {
    return __dom_wrap(_this.nextElementSibling);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__offsetHeight(_this) {
  try {
    return __dom_wrap(_this.offsetHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__offsetLeft(_this) {
  try {
    return __dom_wrap(_this.offsetLeft);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__offsetParent(_this) {
  try {
    return __dom_wrap(_this.offsetParent);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__offsetTop(_this) {
  try {
    return __dom_wrap(_this.offsetTop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__offsetWidth(_this) {
  try {
    return __dom_wrap(_this.offsetWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onbeforecopy(_this) {
  try {
    return __dom_wrap(_this.onbeforecopy);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onbeforecopy(_this, value) {
  try {
    _this.onbeforecopy = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onbeforecut(_this) {
  try {
    return __dom_wrap(_this.onbeforecut);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onbeforecut(_this, value) {
  try {
    _this.onbeforecut = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onbeforepaste(_this) {
  try {
    return __dom_wrap(_this.onbeforepaste);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onbeforepaste(_this, value) {
  try {
    _this.onbeforepaste = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onblur(_this) {
  try {
    return __dom_wrap(_this.onblur);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onblur(_this, value) {
  try {
    _this.onblur = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onchange(_this) {
  try {
    return __dom_wrap(_this.onchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onchange(_this, value) {
  try {
    _this.onchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onclick(_this) {
  try {
    return __dom_wrap(_this.onclick);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onclick(_this, value) {
  try {
    _this.onclick = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__oncontextmenu(_this) {
  try {
    return __dom_wrap(_this.oncontextmenu);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__oncontextmenu(_this, value) {
  try {
    _this.oncontextmenu = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__oncopy(_this) {
  try {
    return __dom_wrap(_this.oncopy);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__oncopy(_this, value) {
  try {
    _this.oncopy = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__oncut(_this) {
  try {
    return __dom_wrap(_this.oncut);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__oncut(_this, value) {
  try {
    _this.oncut = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ondblclick(_this) {
  try {
    return __dom_wrap(_this.ondblclick);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ondblclick(_this, value) {
  try {
    _this.ondblclick = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ondrag(_this) {
  try {
    return __dom_wrap(_this.ondrag);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ondrag(_this, value) {
  try {
    _this.ondrag = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ondragend(_this) {
  try {
    return __dom_wrap(_this.ondragend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ondragend(_this, value) {
  try {
    _this.ondragend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ondragenter(_this) {
  try {
    return __dom_wrap(_this.ondragenter);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ondragenter(_this, value) {
  try {
    _this.ondragenter = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ondragleave(_this) {
  try {
    return __dom_wrap(_this.ondragleave);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ondragleave(_this, value) {
  try {
    _this.ondragleave = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ondragover(_this) {
  try {
    return __dom_wrap(_this.ondragover);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ondragover(_this, value) {
  try {
    _this.ondragover = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ondragstart(_this) {
  try {
    return __dom_wrap(_this.ondragstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ondragstart(_this, value) {
  try {
    _this.ondragstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ondrop(_this) {
  try {
    return __dom_wrap(_this.ondrop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ondrop(_this, value) {
  try {
    _this.ondrop = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onfocus(_this) {
  try {
    return __dom_wrap(_this.onfocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onfocus(_this, value) {
  try {
    _this.onfocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__oninput(_this) {
  try {
    return __dom_wrap(_this.oninput);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__oninput(_this, value) {
  try {
    _this.oninput = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__oninvalid(_this) {
  try {
    return __dom_wrap(_this.oninvalid);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__oninvalid(_this, value) {
  try {
    _this.oninvalid = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onkeydown(_this) {
  try {
    return __dom_wrap(_this.onkeydown);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onkeydown(_this, value) {
  try {
    _this.onkeydown = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onkeypress(_this) {
  try {
    return __dom_wrap(_this.onkeypress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onkeypress(_this, value) {
  try {
    _this.onkeypress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onkeyup(_this) {
  try {
    return __dom_wrap(_this.onkeyup);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onkeyup(_this, value) {
  try {
    _this.onkeyup = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onload(_this) {
  try {
    return __dom_wrap(_this.onload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onload(_this, value) {
  try {
    _this.onload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onmousedown(_this) {
  try {
    return __dom_wrap(_this.onmousedown);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onmousedown(_this, value) {
  try {
    _this.onmousedown = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onmousemove(_this) {
  try {
    return __dom_wrap(_this.onmousemove);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onmousemove(_this, value) {
  try {
    _this.onmousemove = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onmouseout(_this) {
  try {
    return __dom_wrap(_this.onmouseout);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onmouseout(_this, value) {
  try {
    _this.onmouseout = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onmouseover(_this) {
  try {
    return __dom_wrap(_this.onmouseover);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onmouseover(_this, value) {
  try {
    _this.onmouseover = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onmouseup(_this) {
  try {
    return __dom_wrap(_this.onmouseup);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onmouseup(_this, value) {
  try {
    _this.onmouseup = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onmousewheel(_this) {
  try {
    return __dom_wrap(_this.onmousewheel);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onmousewheel(_this, value) {
  try {
    _this.onmousewheel = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onpaste(_this) {
  try {
    return __dom_wrap(_this.onpaste);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onpaste(_this, value) {
  try {
    _this.onpaste = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onreset(_this) {
  try {
    return __dom_wrap(_this.onreset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onreset(_this, value) {
  try {
    _this.onreset = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onscroll(_this) {
  try {
    return __dom_wrap(_this.onscroll);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onscroll(_this, value) {
  try {
    _this.onscroll = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onsearch(_this) {
  try {
    return __dom_wrap(_this.onsearch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onsearch(_this, value) {
  try {
    _this.onsearch = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onselect(_this) {
  try {
    return __dom_wrap(_this.onselect);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onselect(_this, value) {
  try {
    _this.onselect = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onselectstart(_this) {
  try {
    return __dom_wrap(_this.onselectstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onselectstart(_this, value) {
  try {
    _this.onselectstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onsubmit(_this) {
  try {
    return __dom_wrap(_this.onsubmit);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onsubmit(_this, value) {
  try {
    _this.onsubmit = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ontouchcancel(_this) {
  try {
    return __dom_wrap(_this.ontouchcancel);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ontouchcancel(_this, value) {
  try {
    _this.ontouchcancel = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ontouchend(_this) {
  try {
    return __dom_wrap(_this.ontouchend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ontouchend(_this, value) {
  try {
    _this.ontouchend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ontouchmove(_this) {
  try {
    return __dom_wrap(_this.ontouchmove);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ontouchmove(_this, value) {
  try {
    _this.ontouchmove = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__ontouchstart(_this) {
  try {
    return __dom_wrap(_this.ontouchstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__ontouchstart(_this, value) {
  try {
    _this.ontouchstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__onwebkitfullscreenchange(_this) {
  try {
    return __dom_wrap(_this.onwebkitfullscreenchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__onwebkitfullscreenchange(_this, value) {
  try {
    _this.onwebkitfullscreenchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__previousElementSibling(_this) {
  try {
    return __dom_wrap(_this.previousElementSibling);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__scrollHeight(_this) {
  try {
    return __dom_wrap(_this.scrollHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__scrollLeft(_this) {
  try {
    return __dom_wrap(_this.scrollLeft);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__scrollLeft(_this, value) {
  try {
    _this.scrollLeft = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__scrollTop(_this) {
  try {
    return __dom_wrap(_this.scrollTop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__set__scrollTop(_this, value) {
  try {
    _this.scrollTop = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__scrollWidth(_this) {
  try {
    return __dom_wrap(_this.scrollWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__style(_this) {
  try {
    return __dom_wrap(_this.style);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__get__tagName(_this) {
  try {
    return __dom_wrap(_this.tagName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__blur(_this) {
  try {
    return __dom_wrap(_this.blur());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__contains(_this) {
  try {
    return __dom_wrap(_this.contains());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__contains_2(_this, element) {
  try {
    return __dom_wrap(_this.contains(__dom_unwrap(element)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__focus(_this) {
  try {
    return __dom_wrap(_this.focus());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttribute(_this) {
  try {
    return __dom_wrap(_this.getAttribute());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttribute_2(_this, name) {
  try {
    return __dom_wrap(_this.getAttribute(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttributeNS(_this) {
  try {
    return __dom_wrap(_this.getAttributeNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttributeNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.getAttributeNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttributeNS_3(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.getAttributeNS(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttributeNode(_this) {
  try {
    return __dom_wrap(_this.getAttributeNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttributeNode_2(_this, name) {
  try {
    return __dom_wrap(_this.getAttributeNode(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttributeNodeNS(_this) {
  try {
    return __dom_wrap(_this.getAttributeNodeNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttributeNodeNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.getAttributeNodeNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getAttributeNodeNS_3(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.getAttributeNodeNS(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getBoundingClientRect(_this) {
  try {
    return __dom_wrap(_this.getBoundingClientRect());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getClientRects(_this) {
  try {
    return __dom_wrap(_this.getClientRects());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getElementsByClassName(_this) {
  try {
    return __dom_wrap(_this.getElementsByClassName());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getElementsByClassName_2(_this, name) {
  try {
    return __dom_wrap(_this.getElementsByClassName(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getElementsByTagName(_this) {
  try {
    return __dom_wrap(_this.getElementsByTagName());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getElementsByTagName_2(_this, name) {
  try {
    return __dom_wrap(_this.getElementsByTagName(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getElementsByTagNameNS(_this) {
  try {
    return __dom_wrap(_this.getElementsByTagNameNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getElementsByTagNameNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.getElementsByTagNameNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__getElementsByTagNameNS_3(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.getElementsByTagNameNS(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__hasAttribute(_this, name) {
  try {
    return __dom_wrap(_this.hasAttribute(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__hasAttributeNS(_this) {
  try {
    return __dom_wrap(_this.hasAttributeNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__hasAttributeNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.hasAttributeNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__hasAttributeNS_3(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.hasAttributeNS(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__querySelector(_this, selectors) {
  try {
    return __dom_wrap(_this.querySelector(__dom_unwrap(selectors)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__querySelectorAll(_this, selectors) {
  try {
    return __dom_wrap(_this.querySelectorAll(__dom_unwrap(selectors)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__removeAttribute(_this) {
  try {
    return __dom_wrap(_this.removeAttribute());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__removeAttribute_2(_this, name) {
  try {
    return __dom_wrap(_this.removeAttribute(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__removeAttributeNS(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.removeAttributeNS(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__removeAttributeNode(_this) {
  try {
    return __dom_wrap(_this.removeAttributeNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__removeAttributeNode_2(_this, oldAttr) {
  try {
    return __dom_wrap(_this.removeAttributeNode(__dom_unwrap(oldAttr)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__scrollByLines(_this) {
  try {
    return __dom_wrap(_this.scrollByLines());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__scrollByLines_2(_this, lines) {
  try {
    return __dom_wrap(_this.scrollByLines(__dom_unwrap(lines)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__scrollByPages(_this) {
  try {
    return __dom_wrap(_this.scrollByPages());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__scrollByPages_2(_this, pages) {
  try {
    return __dom_wrap(_this.scrollByPages(__dom_unwrap(pages)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__scrollIntoView(_this) {
  try {
    return __dom_wrap(_this.scrollIntoView());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__scrollIntoView_2(_this, alignWithTop) {
  try {
    return __dom_wrap(_this.scrollIntoView(__dom_unwrap(alignWithTop)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__scrollIntoViewIfNeeded(_this) {
  try {
    return __dom_wrap(_this.scrollIntoViewIfNeeded());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__scrollIntoViewIfNeeded_2(_this, centerIfNeeded) {
  try {
    return __dom_wrap(_this.scrollIntoViewIfNeeded(__dom_unwrap(centerIfNeeded)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttribute(_this) {
  try {
    return __dom_wrap(_this.setAttribute());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttribute_2(_this, name) {
  try {
    return __dom_wrap(_this.setAttribute(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttribute_3(_this, name, value) {
  try {
    return __dom_wrap(_this.setAttribute(__dom_unwrap(name), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttributeNS(_this) {
  try {
    return __dom_wrap(_this.setAttributeNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttributeNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.setAttributeNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttributeNS_3(_this, namespaceURI, qualifiedName) {
  try {
    return __dom_wrap(_this.setAttributeNS(__dom_unwrap(namespaceURI), __dom_unwrap(qualifiedName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttributeNS_4(_this, namespaceURI, qualifiedName, value) {
  try {
    return __dom_wrap(_this.setAttributeNS(__dom_unwrap(namespaceURI), __dom_unwrap(qualifiedName), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttributeNode(_this) {
  try {
    return __dom_wrap(_this.setAttributeNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttributeNode_2(_this, newAttr) {
  try {
    return __dom_wrap(_this.setAttributeNode(__dom_unwrap(newAttr)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttributeNodeNS(_this) {
  try {
    return __dom_wrap(_this.setAttributeNodeNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__setAttributeNodeNS_2(_this, newAttr) {
  try {
    return __dom_wrap(_this.setAttributeNodeNS(__dom_unwrap(newAttr)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__webkitMatchesSelector(_this) {
  try {
    return __dom_wrap(_this.webkitMatchesSelector());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ElementWrappingImplementation__webkitMatchesSelector_2(_this, selectors) {
  try {
    return __dom_wrap(_this.webkitMatchesSelector(__dom_unwrap(selectors)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntityWrappingImplementation__get__notationName(_this) {
  try {
    return __dom_wrap(_this.notationName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntityWrappingImplementation__get__publicId(_this) {
  try {
    return __dom_wrap(_this.publicId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntityWrappingImplementation__get__systemId(_this) {
  try {
    return __dom_wrap(_this.systemId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntriesCallbackWrappingImplementation__handleEvent(_this, entries) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(entries)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__get__filesystem(_this) {
  try {
    return __dom_wrap(_this.filesystem);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__get__fullPath(_this) {
  try {
    return __dom_wrap(_this.fullPath);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__get__isDirectory(_this) {
  try {
    return __dom_wrap(_this.isDirectory);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__get__isFile(_this) {
  try {
    return __dom_wrap(_this.isFile);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__copyTo(_this, parent) {
  try {
    return __dom_wrap(_this.copyTo(__dom_unwrap(parent)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__copyTo_2(_this, parent, name) {
  try {
    return __dom_wrap(_this.copyTo(__dom_unwrap(parent), __dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__copyTo_3(_this, parent, name, successCallback) {
  try {
    return __dom_wrap(_this.copyTo(__dom_unwrap(parent), __dom_unwrap(name), __dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__copyTo_4(_this, parent, name, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.copyTo(__dom_unwrap(parent), __dom_unwrap(name), __dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__getMetadata(_this) {
  try {
    return __dom_wrap(_this.getMetadata());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__getMetadata_2(_this, successCallback) {
  try {
    return __dom_wrap(_this.getMetadata(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__getMetadata_3(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.getMetadata(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__getParent(_this) {
  try {
    return __dom_wrap(_this.getParent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__getParent_2(_this, successCallback) {
  try {
    return __dom_wrap(_this.getParent(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__getParent_3(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.getParent(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__moveTo(_this, parent) {
  try {
    return __dom_wrap(_this.moveTo(__dom_unwrap(parent)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__moveTo_2(_this, parent, name) {
  try {
    return __dom_wrap(_this.moveTo(__dom_unwrap(parent), __dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__moveTo_3(_this, parent, name, successCallback) {
  try {
    return __dom_wrap(_this.moveTo(__dom_unwrap(parent), __dom_unwrap(name), __dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__moveTo_4(_this, parent, name, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.moveTo(__dom_unwrap(parent), __dom_unwrap(name), __dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__remove(_this) {
  try {
    return __dom_wrap(_this.remove());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__remove_2(_this, successCallback) {
  try {
    return __dom_wrap(_this.remove(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__remove_3(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.remove(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryWrappingImplementation__toURL(_this) {
  try {
    return __dom_wrap(_this.toURL());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryArrayWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryArraySyncWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryArraySyncWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntryCallbackWrappingImplementation__handleEvent(_this, entry) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(entry)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__get__filesystem(_this) {
  try {
    return __dom_wrap(_this.filesystem);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__get__fullPath(_this) {
  try {
    return __dom_wrap(_this.fullPath);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__get__isDirectory(_this) {
  try {
    return __dom_wrap(_this.isDirectory);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__get__isFile(_this) {
  try {
    return __dom_wrap(_this.isFile);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__copyTo(_this, parent, name) {
  try {
    return __dom_wrap(_this.copyTo(__dom_unwrap(parent), __dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__getMetadata(_this) {
  try {
    return __dom_wrap(_this.getMetadata());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__getParent(_this) {
  try {
    return __dom_wrap(_this.getParent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__moveTo(_this, parent, name) {
  try {
    return __dom_wrap(_this.moveTo(__dom_unwrap(parent), __dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__remove(_this) {
  try {
    return __dom_wrap(_this.remove());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EntrySyncWrappingImplementation__toURL(_this) {
  try {
    return __dom_wrap(_this.toURL());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorCallbackWrappingImplementation__handleEvent(_this, error) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__get__filename(_this) {
  try {
    return __dom_wrap(_this.filename);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__get__lineno(_this) {
  try {
    return __dom_wrap(_this.lineno);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__initErrorEvent(_this) {
  try {
    return __dom_wrap(_this.initErrorEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__initErrorEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initErrorEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__initErrorEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initErrorEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__initErrorEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initErrorEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__initErrorEvent_5(_this, typeArg, canBubbleArg, cancelableArg, messageArg) {
  try {
    return __dom_wrap(_this.initErrorEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(messageArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__initErrorEvent_6(_this, typeArg, canBubbleArg, cancelableArg, messageArg, filenameArg) {
  try {
    return __dom_wrap(_this.initErrorEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(messageArg), __dom_unwrap(filenameArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ErrorEventWrappingImplementation__initErrorEvent_7(_this, typeArg, canBubbleArg, cancelableArg, messageArg, filenameArg, linenoArg) {
  try {
    return __dom_wrap(_this.initErrorEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(messageArg), __dom_unwrap(filenameArg), __dom_unwrap(linenoArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__bubbles(_this) {
  try {
    return __dom_wrap(_this.bubbles);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__cancelBubble(_this) {
  try {
    return __dom_wrap(_this.cancelBubble);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__set__cancelBubble(_this, value) {
  try {
    _this.cancelBubble = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__cancelable(_this) {
  try {
    return __dom_wrap(_this.cancelable);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__currentTarget(_this) {
  try {
    return __dom_wrap(_this.currentTarget);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__defaultPrevented(_this) {
  try {
    return __dom_wrap(_this.defaultPrevented);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__eventPhase(_this) {
  try {
    return __dom_wrap(_this.eventPhase);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__returnValue(_this) {
  try {
    return __dom_wrap(_this.returnValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__set__returnValue(_this, value) {
  try {
    _this.returnValue = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__srcElement(_this) {
  try {
    return __dom_wrap(_this.srcElement);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__target(_this) {
  try {
    return __dom_wrap(_this.target);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__timeStamp(_this) {
  try {
    return __dom_wrap(_this.timeStamp);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__initEvent(_this) {
  try {
    return __dom_wrap(_this.initEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__initEvent_2(_this, eventTypeArg) {
  try {
    return __dom_wrap(_this.initEvent(__dom_unwrap(eventTypeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__initEvent_3(_this, eventTypeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initEvent(__dom_unwrap(eventTypeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__initEvent_4(_this, eventTypeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initEvent(__dom_unwrap(eventTypeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__preventDefault(_this) {
  try {
    return __dom_wrap(_this.preventDefault());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__stopImmediatePropagation(_this) {
  try {
    return __dom_wrap(_this.stopImmediatePropagation());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventWrappingImplementation__stopPropagation(_this) {
  try {
    return __dom_wrap(_this.stopPropagation());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventExceptionWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__get__URL(_this) {
  try {
    return __dom_wrap(_this.URL);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__get__onmessage(_this) {
  try {
    return __dom_wrap(_this.onmessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__set__onmessage(_this, value) {
  try {
    _this.onmessage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__get__onopen(_this) {
  try {
    return __dom_wrap(_this.onopen);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__set__onopen(_this, value) {
  try {
    _this.onopen = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__close(_this) {
  try {
    return __dom_wrap(_this.close());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventSourceWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventTargetWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventTargetWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventTargetWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventTargetWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__EventTargetWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWrappingImplementation__get__fileName(_this) {
  try {
    return __dom_wrap(_this.fileName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWrappingImplementation__get__fileSize(_this) {
  try {
    return __dom_wrap(_this.fileSize);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWrappingImplementation__get__lastModifiedDate(_this) {
  try {
    return __dom_wrap(_this.lastModifiedDate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileCallbackWrappingImplementation__handleEvent(_this, file) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(file)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileEntryWrappingImplementation__createWriter(_this, successCallback) {
  try {
    return __dom_wrap(_this.createWriter(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileEntryWrappingImplementation__createWriter_2(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.createWriter(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileEntryWrappingImplementation__file(_this, successCallback) {
  try {
    return __dom_wrap(_this.file(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileEntryWrappingImplementation__file_2(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.file(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileEntrySyncWrappingImplementation__createWriter(_this) {
  try {
    return __dom_wrap(_this.createWriter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileEntrySyncWrappingImplementation__file(_this) {
  try {
    return __dom_wrap(_this.file());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileErrorWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileExceptionWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileListWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__error(_this) {
  try {
    return __dom_wrap(_this.error);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__onload(_this) {
  try {
    return __dom_wrap(_this.onload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__set__onload(_this, value) {
  try {
    _this.onload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__onloadend(_this) {
  try {
    return __dom_wrap(_this.onloadend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__set__onloadend(_this, value) {
  try {
    _this.onloadend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__onloadstart(_this) {
  try {
    return __dom_wrap(_this.onloadstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__set__onloadstart(_this, value) {
  try {
    _this.onloadstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__onprogress(_this) {
  try {
    return __dom_wrap(_this.onprogress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__set__onprogress(_this, value) {
  try {
    _this.onprogress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__get__result(_this) {
  try {
    return __dom_wrap(_this.result);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__abort(_this) {
  try {
    return __dom_wrap(_this.abort());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__readAsArrayBuffer(_this, blob) {
  try {
    return __dom_wrap(_this.readAsArrayBuffer(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__readAsBinaryString(_this, blob) {
  try {
    return __dom_wrap(_this.readAsBinaryString(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__readAsDataURL(_this, blob) {
  try {
    return __dom_wrap(_this.readAsDataURL(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__readAsText(_this, blob) {
  try {
    return __dom_wrap(_this.readAsText(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderWrappingImplementation__readAsText_2(_this, blob, encoding) {
  try {
    return __dom_wrap(_this.readAsText(__dom_unwrap(blob), __dom_unwrap(encoding)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderSyncWrappingImplementation__readAsArrayBuffer(_this, blob) {
  try {
    return __dom_wrap(_this.readAsArrayBuffer(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderSyncWrappingImplementation__readAsBinaryString(_this, blob) {
  try {
    return __dom_wrap(_this.readAsBinaryString(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderSyncWrappingImplementation__readAsDataURL(_this, blob) {
  try {
    return __dom_wrap(_this.readAsDataURL(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderSyncWrappingImplementation__readAsText(_this, blob) {
  try {
    return __dom_wrap(_this.readAsText(__dom_unwrap(blob)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileReaderSyncWrappingImplementation__readAsText_2(_this, blob, encoding) {
  try {
    return __dom_wrap(_this.readAsText(__dom_unwrap(blob), __dom_unwrap(encoding)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileSystemCallbackWrappingImplementation__handleEvent(_this, fileSystem) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(fileSystem)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__error(_this) {
  try {
    return __dom_wrap(_this.error);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__onprogress(_this) {
  try {
    return __dom_wrap(_this.onprogress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__set__onprogress(_this, value) {
  try {
    _this.onprogress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__onwrite(_this) {
  try {
    return __dom_wrap(_this.onwrite);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__set__onwrite(_this, value) {
  try {
    _this.onwrite = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__onwriteend(_this) {
  try {
    return __dom_wrap(_this.onwriteend);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__set__onwriteend(_this, value) {
  try {
    _this.onwriteend = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__onwritestart(_this) {
  try {
    return __dom_wrap(_this.onwritestart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__set__onwritestart(_this, value) {
  try {
    _this.onwritestart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__position(_this) {
  try {
    return __dom_wrap(_this.position);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__abort(_this) {
  try {
    return __dom_wrap(_this.abort());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__seek(_this, position) {
  try {
    return __dom_wrap(_this.seek(__dom_unwrap(position)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__truncate(_this, size) {
  try {
    return __dom_wrap(_this.truncate(__dom_unwrap(size)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterWrappingImplementation__write(_this, data) {
  try {
    return __dom_wrap(_this.write(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterCallbackWrappingImplementation__handleEvent(_this, fileWriter) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(fileWriter)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterSyncWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterSyncWrappingImplementation__get__position(_this) {
  try {
    return __dom_wrap(_this.position);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterSyncWrappingImplementation__seek(_this, position) {
  try {
    return __dom_wrap(_this.seek(__dom_unwrap(position)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterSyncWrappingImplementation__truncate(_this, size) {
  try {
    return __dom_wrap(_this.truncate(__dom_unwrap(size)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__FileWriterSyncWrappingImplementation__write(_this, data) {
  try {
    return __dom_wrap(_this.write(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Float32ArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Float32ArrayWrappingImplementation__subarray(_this) {
  try {
    return __dom_wrap(_this.subarray());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Float32ArrayWrappingImplementation__subarray_2(_this, start) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Float32ArrayWrappingImplementation__subarray_3(_this, start, end) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Float64ArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Float64ArrayWrappingImplementation__subarray(_this) {
  try {
    return __dom_wrap(_this.subarray());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Float64ArrayWrappingImplementation__subarray_2(_this, start) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Float64ArrayWrappingImplementation__subarray_3(_this, start, end) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__GeolocationWrappingImplementation__clearWatch(_this, watchId) {
  try {
    return __dom_wrap(_this.clearWatch(__dom_unwrap(watchId)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__GeolocationWrappingImplementation__getCurrentPosition(_this, successCallback) {
  try {
    return __dom_wrap(_this.getCurrentPosition(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__GeolocationWrappingImplementation__getCurrentPosition_2(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.getCurrentPosition(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__GeolocationWrappingImplementation__watchPosition(_this, successCallback) {
  try {
    return __dom_wrap(_this.watchPosition(__dom_unwrap(successCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__GeolocationWrappingImplementation__watchPosition_2(_this, successCallback, errorCallback) {
  try {
    return __dom_wrap(_this.watchPosition(__dom_unwrap(successCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__GeopositionWrappingImplementation__get__coords(_this) {
  try {
    return __dom_wrap(_this.coords);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__GeopositionWrappingImplementation__get__timestamp(_this) {
  try {
    return __dom_wrap(_this.timestamp);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAllCollectionWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAllCollectionWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAllCollectionWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAllCollectionWrappingImplementation__namedItem(_this, name) {
  try {
    return __dom_wrap(_this.namedItem(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAllCollectionWrappingImplementation__tags(_this, name) {
  try {
    return __dom_wrap(_this.tags(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__accessKey(_this) {
  try {
    return __dom_wrap(_this.accessKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__accessKey(_this, value) {
  try {
    _this.accessKey = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__charset(_this) {
  try {
    return __dom_wrap(_this.charset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__charset(_this, value) {
  try {
    _this.charset = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__coords(_this) {
  try {
    return __dom_wrap(_this.coords);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__coords(_this, value) {
  try {
    _this.coords = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__download(_this) {
  try {
    return __dom_wrap(_this.download);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__download(_this, value) {
  try {
    _this.download = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__hash(_this) {
  try {
    return __dom_wrap(_this.hash);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__hash(_this, value) {
  try {
    _this.hash = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__host(_this) {
  try {
    return __dom_wrap(_this.host);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__host(_this, value) {
  try {
    _this.host = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__hostname(_this) {
  try {
    return __dom_wrap(_this.hostname);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__hostname(_this, value) {
  try {
    _this.hostname = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__href(_this) {
  try {
    return __dom_wrap(_this.href);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__href(_this, value) {
  try {
    _this.href = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__hreflang(_this) {
  try {
    return __dom_wrap(_this.hreflang);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__hreflang(_this, value) {
  try {
    _this.hreflang = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__origin(_this) {
  try {
    return __dom_wrap(_this.origin);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__pathname(_this) {
  try {
    return __dom_wrap(_this.pathname);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__pathname(_this, value) {
  try {
    _this.pathname = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__ping(_this) {
  try {
    return __dom_wrap(_this.ping);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__ping(_this, value) {
  try {
    _this.ping = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__port(_this) {
  try {
    return __dom_wrap(_this.port);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__port(_this, value) {
  try {
    _this.port = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__protocol(_this) {
  try {
    return __dom_wrap(_this.protocol);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__protocol(_this, value) {
  try {
    _this.protocol = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__rel(_this) {
  try {
    return __dom_wrap(_this.rel);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__rel(_this, value) {
  try {
    _this.rel = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__rev(_this) {
  try {
    return __dom_wrap(_this.rev);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__rev(_this, value) {
  try {
    _this.rev = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__search(_this) {
  try {
    return __dom_wrap(_this.search);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__search(_this, value) {
  try {
    _this.search = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__shape(_this) {
  try {
    return __dom_wrap(_this.shape);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__shape(_this, value) {
  try {
    _this.shape = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__target(_this) {
  try {
    return __dom_wrap(_this.target);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__target(_this, value) {
  try {
    _this.target = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__text(_this) {
  try {
    return __dom_wrap(_this.text);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAnchorElementWrappingImplementation__getParameter(_this, name) {
  try {
    return __dom_wrap(_this.getParameter(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__alt(_this) {
  try {
    return __dom_wrap(_this.alt);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__alt(_this, value) {
  try {
    _this.alt = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__archive(_this) {
  try {
    return __dom_wrap(_this.archive);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__archive(_this, value) {
  try {
    _this.archive = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__code(_this, value) {
  try {
    _this.code = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__codeBase(_this) {
  try {
    return __dom_wrap(_this.codeBase);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__codeBase(_this, value) {
  try {
    _this.codeBase = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__hspace(_this) {
  try {
    return __dom_wrap(_this.hspace);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__hspace(_this, value) {
  try {
    _this.hspace = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__object(_this) {
  try {
    return __dom_wrap(_this.object);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__object(_this, value) {
  try {
    _this.object = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__vspace(_this) {
  try {
    return __dom_wrap(_this.vspace);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__vspace(_this, value) {
  try {
    _this.vspace = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAppletElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__accessKey(_this) {
  try {
    return __dom_wrap(_this.accessKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__set__accessKey(_this, value) {
  try {
    _this.accessKey = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__alt(_this) {
  try {
    return __dom_wrap(_this.alt);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__set__alt(_this, value) {
  try {
    _this.alt = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__coords(_this) {
  try {
    return __dom_wrap(_this.coords);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__set__coords(_this, value) {
  try {
    _this.coords = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__hash(_this) {
  try {
    return __dom_wrap(_this.hash);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__host(_this) {
  try {
    return __dom_wrap(_this.host);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__hostname(_this) {
  try {
    return __dom_wrap(_this.hostname);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__href(_this) {
  try {
    return __dom_wrap(_this.href);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__set__href(_this, value) {
  try {
    _this.href = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__noHref(_this) {
  try {
    return __dom_wrap(_this.noHref);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__set__noHref(_this, value) {
  try {
    _this.noHref = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__pathname(_this) {
  try {
    return __dom_wrap(_this.pathname);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__ping(_this) {
  try {
    return __dom_wrap(_this.ping);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__set__ping(_this, value) {
  try {
    _this.ping = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__port(_this) {
  try {
    return __dom_wrap(_this.port);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__protocol(_this) {
  try {
    return __dom_wrap(_this.protocol);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__search(_this) {
  try {
    return __dom_wrap(_this.search);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__shape(_this) {
  try {
    return __dom_wrap(_this.shape);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__set__shape(_this, value) {
  try {
    _this.shape = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__get__target(_this) {
  try {
    return __dom_wrap(_this.target);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLAreaElementWrappingImplementation__set__target(_this, value) {
  try {
    _this.target = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBRElementWrappingImplementation__get__clear(_this) {
  try {
    return __dom_wrap(_this.clear);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBRElementWrappingImplementation__set__clear(_this, value) {
  try {
    _this.clear = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseElementWrappingImplementation__get__href(_this) {
  try {
    return __dom_wrap(_this.href);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseElementWrappingImplementation__set__href(_this, value) {
  try {
    _this.href = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseElementWrappingImplementation__get__target(_this) {
  try {
    return __dom_wrap(_this.target);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseElementWrappingImplementation__set__target(_this, value) {
  try {
    _this.target = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseFontElementWrappingImplementation__get__color(_this) {
  try {
    return __dom_wrap(_this.color);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseFontElementWrappingImplementation__set__color(_this, value) {
  try {
    _this.color = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseFontElementWrappingImplementation__get__face(_this) {
  try {
    return __dom_wrap(_this.face);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseFontElementWrappingImplementation__set__face(_this, value) {
  try {
    _this.face = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseFontElementWrappingImplementation__get__size(_this) {
  try {
    return __dom_wrap(_this.size);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBaseFontElementWrappingImplementation__set__size(_this, value) {
  try {
    _this.size = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBlockquoteElementWrappingImplementation__get__cite(_this) {
  try {
    return __dom_wrap(_this.cite);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBlockquoteElementWrappingImplementation__set__cite(_this, value) {
  try {
    _this.cite = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__aLink(_this) {
  try {
    return __dom_wrap(_this.aLink);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__aLink(_this, value) {
  try {
    _this.aLink = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__background(_this) {
  try {
    return __dom_wrap(_this.background);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__background(_this, value) {
  try {
    _this.background = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__bgColor(_this) {
  try {
    return __dom_wrap(_this.bgColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__bgColor(_this, value) {
  try {
    _this.bgColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__link(_this) {
  try {
    return __dom_wrap(_this.link);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__link(_this, value) {
  try {
    _this.link = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onbeforeunload(_this) {
  try {
    return __dom_wrap(_this.onbeforeunload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onbeforeunload(_this, value) {
  try {
    _this.onbeforeunload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onblur(_this) {
  try {
    return __dom_wrap(_this.onblur);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onblur(_this, value) {
  try {
    _this.onblur = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onfocus(_this) {
  try {
    return __dom_wrap(_this.onfocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onfocus(_this, value) {
  try {
    _this.onfocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onhashchange(_this) {
  try {
    return __dom_wrap(_this.onhashchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onhashchange(_this, value) {
  try {
    _this.onhashchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onload(_this) {
  try {
    return __dom_wrap(_this.onload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onload(_this, value) {
  try {
    _this.onload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onmessage(_this) {
  try {
    return __dom_wrap(_this.onmessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onmessage(_this, value) {
  try {
    _this.onmessage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onoffline(_this) {
  try {
    return __dom_wrap(_this.onoffline);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onoffline(_this, value) {
  try {
    _this.onoffline = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__ononline(_this) {
  try {
    return __dom_wrap(_this.ononline);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__ononline(_this, value) {
  try {
    _this.ononline = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onorientationchange(_this) {
  try {
    return __dom_wrap(_this.onorientationchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onorientationchange(_this, value) {
  try {
    _this.onorientationchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onpopstate(_this) {
  try {
    return __dom_wrap(_this.onpopstate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onpopstate(_this, value) {
  try {
    _this.onpopstate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onresize(_this) {
  try {
    return __dom_wrap(_this.onresize);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onresize(_this, value) {
  try {
    _this.onresize = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onstorage(_this) {
  try {
    return __dom_wrap(_this.onstorage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onstorage(_this, value) {
  try {
    _this.onstorage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__onunload(_this) {
  try {
    return __dom_wrap(_this.onunload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__onunload(_this, value) {
  try {
    _this.onunload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__text(_this) {
  try {
    return __dom_wrap(_this.text);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__text(_this, value) {
  try {
    _this.text = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__get__vLink(_this) {
  try {
    return __dom_wrap(_this.vLink);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLBodyElementWrappingImplementation__set__vLink(_this, value) {
  try {
    _this.vLink = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__accessKey(_this) {
  try {
    return __dom_wrap(_this.accessKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__accessKey(_this, value) {
  try {
    _this.accessKey = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__autofocus(_this) {
  try {
    return __dom_wrap(_this.autofocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__autofocus(_this, value) {
  try {
    _this.autofocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__formAction(_this) {
  try {
    return __dom_wrap(_this.formAction);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__formAction(_this, value) {
  try {
    _this.formAction = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__formEnctype(_this) {
  try {
    return __dom_wrap(_this.formEnctype);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__formEnctype(_this, value) {
  try {
    _this.formEnctype = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__formMethod(_this) {
  try {
    return __dom_wrap(_this.formMethod);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__formMethod(_this, value) {
  try {
    _this.formMethod = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__formNoValidate(_this) {
  try {
    return __dom_wrap(_this.formNoValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__formNoValidate(_this, value) {
  try {
    _this.formNoValidate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__formTarget(_this) {
  try {
    return __dom_wrap(_this.formTarget);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__formTarget(_this, value) {
  try {
    _this.formTarget = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__labels(_this) {
  try {
    return __dom_wrap(_this.labels);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__validationMessage(_this) {
  try {
    return __dom_wrap(_this.validationMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__validity(_this) {
  try {
    return __dom_wrap(_this.validity);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__get__willValidate(_this) {
  try {
    return __dom_wrap(_this.willValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__click(_this) {
  try {
    return __dom_wrap(_this.click());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLButtonElementWrappingImplementation__setCustomValidity(_this, error) {
  try {
    return __dom_wrap(_this.setCustomValidity(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCanvasElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCanvasElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCanvasElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCanvasElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCanvasElementWrappingImplementation__getContext(_this) {
  try {
    return __dom_wrap(_this.getContext());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCanvasElementWrappingImplementation__getContext_2(_this, contextId) {
  try {
    return __dom_wrap(_this.getContext(__dom_unwrap(contextId)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCanvasElementWrappingImplementation__toDataURL(_this) {
  try {
    return __dom_wrap(_this.toDataURL());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCanvasElementWrappingImplementation__toDataURL_2(_this, type) {
  try {
    return __dom_wrap(_this.toDataURL(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCollectionWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCollectionWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCollectionWrappingImplementation__namedItem(_this) {
  try {
    return __dom_wrap(_this.namedItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLCollectionWrappingImplementation__namedItem_2(_this, name) {
  try {
    return __dom_wrap(_this.namedItem(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDListElementWrappingImplementation__get__compact(_this) {
  try {
    return __dom_wrap(_this.compact);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDListElementWrappingImplementation__set__compact(_this, value) {
  try {
    _this.compact = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDataListElementWrappingImplementation__get__options(_this) {
  try {
    return __dom_wrap(_this.options);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDetailsElementWrappingImplementation__get__open(_this) {
  try {
    return __dom_wrap(_this.open);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDetailsElementWrappingImplementation__set__open(_this, value) {
  try {
    _this.open = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDirectoryElementWrappingImplementation__get__compact(_this) {
  try {
    return __dom_wrap(_this.compact);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDirectoryElementWrappingImplementation__set__compact(_this, value) {
  try {
    _this.compact = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDivElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDivElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__activeElement(_this) {
  try {
    return __dom_wrap(_this.activeElement);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__alinkColor(_this) {
  try {
    return __dom_wrap(_this.alinkColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__set__alinkColor(_this, value) {
  try {
    _this.alinkColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__bgColor(_this) {
  try {
    return __dom_wrap(_this.bgColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__set__bgColor(_this, value) {
  try {
    _this.bgColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__compatMode(_this) {
  try {
    return __dom_wrap(_this.compatMode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__designMode(_this) {
  try {
    return __dom_wrap(_this.designMode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__set__designMode(_this, value) {
  try {
    _this.designMode = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__dir(_this) {
  try {
    return __dom_wrap(_this.dir);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__set__dir(_this, value) {
  try {
    _this.dir = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__embeds(_this) {
  try {
    return __dom_wrap(_this.embeds);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__fgColor(_this) {
  try {
    return __dom_wrap(_this.fgColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__set__fgColor(_this, value) {
  try {
    _this.fgColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__linkColor(_this) {
  try {
    return __dom_wrap(_this.linkColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__set__linkColor(_this, value) {
  try {
    _this.linkColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__plugins(_this) {
  try {
    return __dom_wrap(_this.plugins);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__scripts(_this) {
  try {
    return __dom_wrap(_this.scripts);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__vlinkColor(_this) {
  try {
    return __dom_wrap(_this.vlinkColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__set__vlinkColor(_this, value) {
  try {
    _this.vlinkColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__captureEvents(_this) {
  try {
    return __dom_wrap(_this.captureEvents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__clear(_this) {
  try {
    return __dom_wrap(_this.clear());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__close(_this) {
  try {
    return __dom_wrap(_this.close());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__hasFocus(_this) {
  try {
    return __dom_wrap(_this.hasFocus());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__open(_this) {
  try {
    return __dom_wrap(_this.open());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__releaseEvents(_this) {
  try {
    return __dom_wrap(_this.releaseEvents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__write(_this) {
  try {
    return __dom_wrap(_this.write());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__write_2(_this, text) {
  try {
    return __dom_wrap(_this.write(__dom_unwrap(text)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__writeln(_this) {
  try {
    return __dom_wrap(_this.writeln());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLDocumentWrappingImplementation__writeln_2(_this, text) {
  try {
    return __dom_wrap(_this.writeln(__dom_unwrap(text)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__children(_this) {
  try {
    return __dom_wrap(_this.children);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__classList(_this) {
  try {
    return __dom_wrap(_this.classList);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__className(_this) {
  try {
    return __dom_wrap(_this.className);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__className(_this, value) {
  try {
    _this.className = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__contentEditable(_this) {
  try {
    return __dom_wrap(_this.contentEditable);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__contentEditable(_this, value) {
  try {
    _this.contentEditable = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__dir(_this) {
  try {
    return __dom_wrap(_this.dir);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__dir(_this, value) {
  try {
    _this.dir = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__draggable(_this) {
  try {
    return __dom_wrap(_this.draggable);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__draggable(_this, value) {
  try {
    _this.draggable = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__hidden(_this) {
  try {
    return __dom_wrap(_this.hidden);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__hidden(_this, value) {
  try {
    _this.hidden = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__id(_this) {
  try {
    return __dom_wrap(_this.id);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__id(_this, value) {
  try {
    _this.id = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__innerHTML(_this) {
  try {
    return __dom_wrap(_this.innerHTML);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__innerHTML(_this, value) {
  try {
    _this.innerHTML = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__innerText(_this) {
  try {
    return __dom_wrap(_this.innerText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__innerText(_this, value) {
  try {
    _this.innerText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__isContentEditable(_this) {
  try {
    return __dom_wrap(_this.isContentEditable);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__lang(_this) {
  try {
    return __dom_wrap(_this.lang);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__lang(_this, value) {
  try {
    _this.lang = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__outerHTML(_this) {
  try {
    return __dom_wrap(_this.outerHTML);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__outerHTML(_this, value) {
  try {
    _this.outerHTML = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__outerText(_this) {
  try {
    return __dom_wrap(_this.outerText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__outerText(_this, value) {
  try {
    _this.outerText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__spellcheck(_this) {
  try {
    return __dom_wrap(_this.spellcheck);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__spellcheck(_this, value) {
  try {
    _this.spellcheck = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__tabIndex(_this) {
  try {
    return __dom_wrap(_this.tabIndex);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__tabIndex(_this, value) {
  try {
    _this.tabIndex = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__title(_this) {
  try {
    return __dom_wrap(_this.title);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__title(_this, value) {
  try {
    _this.title = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__get__webkitdropzone(_this) {
  try {
    return __dom_wrap(_this.webkitdropzone);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__set__webkitdropzone(_this, value) {
  try {
    _this.webkitdropzone = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentElement(_this) {
  try {
    return __dom_wrap(_this.insertAdjacentElement());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentElement_2(_this, where) {
  try {
    return __dom_wrap(_this.insertAdjacentElement(__dom_unwrap(where)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentElement_3(_this, where, element) {
  try {
    return __dom_wrap(_this.insertAdjacentElement(__dom_unwrap(where), __dom_unwrap(element)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentHTML(_this) {
  try {
    return __dom_wrap(_this.insertAdjacentHTML());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentHTML_2(_this, position_OR_where) {
  try {
    return __dom_wrap(_this.insertAdjacentHTML(__dom_unwrap(position_OR_where)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentHTML_3(_this, position_OR_where, text) {
  try {
    return __dom_wrap(_this.insertAdjacentHTML(__dom_unwrap(position_OR_where), __dom_unwrap(text)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentText(_this) {
  try {
    return __dom_wrap(_this.insertAdjacentText());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentText_2(_this, where) {
  try {
    return __dom_wrap(_this.insertAdjacentText(__dom_unwrap(where)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLElementWrappingImplementation__insertAdjacentText_3(_this, where, text) {
  try {
    return __dom_wrap(_this.insertAdjacentText(__dom_unwrap(where), __dom_unwrap(text)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLEmbedElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFieldSetElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFieldSetElementWrappingImplementation__get__validationMessage(_this) {
  try {
    return __dom_wrap(_this.validationMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFieldSetElementWrappingImplementation__get__validity(_this) {
  try {
    return __dom_wrap(_this.validity);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFieldSetElementWrappingImplementation__get__willValidate(_this) {
  try {
    return __dom_wrap(_this.willValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFieldSetElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFieldSetElementWrappingImplementation__setCustomValidity(_this, error) {
  try {
    return __dom_wrap(_this.setCustomValidity(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFontElementWrappingImplementation__get__color(_this) {
  try {
    return __dom_wrap(_this.color);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFontElementWrappingImplementation__set__color(_this, value) {
  try {
    _this.color = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFontElementWrappingImplementation__get__face(_this) {
  try {
    return __dom_wrap(_this.face);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFontElementWrappingImplementation__set__face(_this, value) {
  try {
    _this.face = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFontElementWrappingImplementation__get__size(_this) {
  try {
    return __dom_wrap(_this.size);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFontElementWrappingImplementation__set__size(_this, value) {
  try {
    _this.size = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__acceptCharset(_this) {
  try {
    return __dom_wrap(_this.acceptCharset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__acceptCharset(_this, value) {
  try {
    _this.acceptCharset = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__action(_this) {
  try {
    return __dom_wrap(_this.action);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__action(_this, value) {
  try {
    _this.action = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__autocomplete(_this) {
  try {
    return __dom_wrap(_this.autocomplete);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__autocomplete(_this, value) {
  try {
    _this.autocomplete = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__elements(_this) {
  try {
    return __dom_wrap(_this.elements);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__encoding(_this) {
  try {
    return __dom_wrap(_this.encoding);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__encoding(_this, value) {
  try {
    _this.encoding = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__enctype(_this) {
  try {
    return __dom_wrap(_this.enctype);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__enctype(_this, value) {
  try {
    _this.enctype = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__method(_this) {
  try {
    return __dom_wrap(_this.method);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__method(_this, value) {
  try {
    _this.method = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__noValidate(_this) {
  try {
    return __dom_wrap(_this.noValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__noValidate(_this, value) {
  try {
    _this.noValidate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__get__target(_this) {
  try {
    return __dom_wrap(_this.target);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__set__target(_this, value) {
  try {
    _this.target = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__reset(_this) {
  try {
    return __dom_wrap(_this.reset());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFormElementWrappingImplementation__submit(_this) {
  try {
    return __dom_wrap(_this.submit());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__contentDocument(_this) {
  try {
    return __dom_wrap(_this.contentDocument);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__contentWindow(_this) {
  try {
    return __dom_wrap(_this.contentWindow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__frameBorder(_this) {
  try {
    return __dom_wrap(_this.frameBorder);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__frameBorder(_this, value) {
  try {
    _this.frameBorder = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__location(_this) {
  try {
    return __dom_wrap(_this.location);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__location(_this, value) {
  try {
    _this.location = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__longDesc(_this) {
  try {
    return __dom_wrap(_this.longDesc);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__longDesc(_this, value) {
  try {
    _this.longDesc = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__marginHeight(_this) {
  try {
    return __dom_wrap(_this.marginHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__marginHeight(_this, value) {
  try {
    _this.marginHeight = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__marginWidth(_this) {
  try {
    return __dom_wrap(_this.marginWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__marginWidth(_this, value) {
  try {
    _this.marginWidth = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__noResize(_this) {
  try {
    return __dom_wrap(_this.noResize);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__noResize(_this, value) {
  try {
    _this.noResize = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__scrolling(_this) {
  try {
    return __dom_wrap(_this.scrolling);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__scrolling(_this, value) {
  try {
    _this.scrolling = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__cols(_this) {
  try {
    return __dom_wrap(_this.cols);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__cols(_this, value) {
  try {
    _this.cols = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onbeforeunload(_this) {
  try {
    return __dom_wrap(_this.onbeforeunload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onbeforeunload(_this, value) {
  try {
    _this.onbeforeunload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onblur(_this) {
  try {
    return __dom_wrap(_this.onblur);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onblur(_this, value) {
  try {
    _this.onblur = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onfocus(_this) {
  try {
    return __dom_wrap(_this.onfocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onfocus(_this, value) {
  try {
    _this.onfocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onhashchange(_this) {
  try {
    return __dom_wrap(_this.onhashchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onhashchange(_this, value) {
  try {
    _this.onhashchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onload(_this) {
  try {
    return __dom_wrap(_this.onload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onload(_this, value) {
  try {
    _this.onload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onmessage(_this) {
  try {
    return __dom_wrap(_this.onmessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onmessage(_this, value) {
  try {
    _this.onmessage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onoffline(_this) {
  try {
    return __dom_wrap(_this.onoffline);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onoffline(_this, value) {
  try {
    _this.onoffline = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__ononline(_this) {
  try {
    return __dom_wrap(_this.ononline);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__ononline(_this, value) {
  try {
    _this.ononline = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onorientationchange(_this) {
  try {
    return __dom_wrap(_this.onorientationchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onorientationchange(_this, value) {
  try {
    _this.onorientationchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onpopstate(_this) {
  try {
    return __dom_wrap(_this.onpopstate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onpopstate(_this, value) {
  try {
    _this.onpopstate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onresize(_this) {
  try {
    return __dom_wrap(_this.onresize);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onresize(_this, value) {
  try {
    _this.onresize = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onstorage(_this) {
  try {
    return __dom_wrap(_this.onstorage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onstorage(_this, value) {
  try {
    _this.onstorage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__onunload(_this) {
  try {
    return __dom_wrap(_this.onunload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__onunload(_this, value) {
  try {
    _this.onunload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__get__rows(_this) {
  try {
    return __dom_wrap(_this.rows);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLFrameSetElementWrappingImplementation__set__rows(_this, value) {
  try {
    _this.rows = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHRElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHRElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHRElementWrappingImplementation__get__noShade(_this) {
  try {
    return __dom_wrap(_this.noShade);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHRElementWrappingImplementation__set__noShade(_this, value) {
  try {
    _this.noShade = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHRElementWrappingImplementation__get__size(_this) {
  try {
    return __dom_wrap(_this.size);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHRElementWrappingImplementation__set__size(_this, value) {
  try {
    _this.size = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHRElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHRElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHeadElementWrappingImplementation__get__profile(_this) {
  try {
    return __dom_wrap(_this.profile);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHeadElementWrappingImplementation__set__profile(_this, value) {
  try {
    _this.profile = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHeadingElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHeadingElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHtmlElementWrappingImplementation__get__manifest(_this) {
  try {
    return __dom_wrap(_this.manifest);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHtmlElementWrappingImplementation__set__manifest(_this, value) {
  try {
    _this.manifest = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHtmlElementWrappingImplementation__get__version(_this) {
  try {
    return __dom_wrap(_this.version);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLHtmlElementWrappingImplementation__set__version(_this, value) {
  try {
    _this.version = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__contentDocument(_this) {
  try {
    return __dom_wrap(_this.contentDocument);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__contentWindow(_this) {
  try {
    return __dom_wrap(_this.contentWindow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__frameBorder(_this) {
  try {
    return __dom_wrap(_this.frameBorder);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__frameBorder(_this, value) {
  try {
    _this.frameBorder = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__longDesc(_this) {
  try {
    return __dom_wrap(_this.longDesc);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__longDesc(_this, value) {
  try {
    _this.longDesc = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__marginHeight(_this) {
  try {
    return __dom_wrap(_this.marginHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__marginHeight(_this, value) {
  try {
    _this.marginHeight = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__marginWidth(_this) {
  try {
    return __dom_wrap(_this.marginWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__marginWidth(_this, value) {
  try {
    _this.marginWidth = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__sandbox(_this) {
  try {
    return __dom_wrap(_this.sandbox);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__sandbox(_this, value) {
  try {
    _this.sandbox = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__scrolling(_this) {
  try {
    return __dom_wrap(_this.scrolling);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__scrolling(_this, value) {
  try {
    _this.scrolling = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIFrameElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__alt(_this) {
  try {
    return __dom_wrap(_this.alt);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__alt(_this, value) {
  try {
    _this.alt = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__border(_this) {
  try {
    return __dom_wrap(_this.border);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__border(_this, value) {
  try {
    _this.border = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__complete(_this) {
  try {
    return __dom_wrap(_this.complete);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__crossOrigin(_this) {
  try {
    return __dom_wrap(_this.crossOrigin);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__crossOrigin(_this, value) {
  try {
    _this.crossOrigin = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__hspace(_this) {
  try {
    return __dom_wrap(_this.hspace);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__hspace(_this, value) {
  try {
    _this.hspace = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__isMap(_this) {
  try {
    return __dom_wrap(_this.isMap);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__isMap(_this, value) {
  try {
    _this.isMap = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__longDesc(_this) {
  try {
    return __dom_wrap(_this.longDesc);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__longDesc(_this, value) {
  try {
    _this.longDesc = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__lowsrc(_this) {
  try {
    return __dom_wrap(_this.lowsrc);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__lowsrc(_this, value) {
  try {
    _this.lowsrc = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__naturalHeight(_this) {
  try {
    return __dom_wrap(_this.naturalHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__naturalWidth(_this) {
  try {
    return __dom_wrap(_this.naturalWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__useMap(_this) {
  try {
    return __dom_wrap(_this.useMap);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__useMap(_this, value) {
  try {
    _this.useMap = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__vspace(_this) {
  try {
    return __dom_wrap(_this.vspace);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__vspace(_this, value) {
  try {
    _this.vspace = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__x(_this) {
  try {
    return __dom_wrap(_this.x);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLImageElementWrappingImplementation__get__y(_this) {
  try {
    return __dom_wrap(_this.y);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__accept(_this) {
  try {
    return __dom_wrap(_this.accept);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__accept(_this, value) {
  try {
    _this.accept = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__accessKey(_this) {
  try {
    return __dom_wrap(_this.accessKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__accessKey(_this, value) {
  try {
    _this.accessKey = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__alt(_this) {
  try {
    return __dom_wrap(_this.alt);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__alt(_this, value) {
  try {
    _this.alt = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__autocomplete(_this) {
  try {
    return __dom_wrap(_this.autocomplete);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__autocomplete(_this, value) {
  try {
    _this.autocomplete = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__autofocus(_this) {
  try {
    return __dom_wrap(_this.autofocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__autofocus(_this, value) {
  try {
    _this.autofocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__checked(_this) {
  try {
    return __dom_wrap(_this.checked);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__checked(_this, value) {
  try {
    _this.checked = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__defaultChecked(_this) {
  try {
    return __dom_wrap(_this.defaultChecked);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__defaultChecked(_this, value) {
  try {
    _this.defaultChecked = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__defaultValue(_this) {
  try {
    return __dom_wrap(_this.defaultValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__defaultValue(_this, value) {
  try {
    _this.defaultValue = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__files(_this) {
  try {
    return __dom_wrap(_this.files);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__formAction(_this) {
  try {
    return __dom_wrap(_this.formAction);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__formAction(_this, value) {
  try {
    _this.formAction = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__formEnctype(_this) {
  try {
    return __dom_wrap(_this.formEnctype);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__formEnctype(_this, value) {
  try {
    _this.formEnctype = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__formMethod(_this) {
  try {
    return __dom_wrap(_this.formMethod);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__formMethod(_this, value) {
  try {
    _this.formMethod = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__formNoValidate(_this) {
  try {
    return __dom_wrap(_this.formNoValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__formNoValidate(_this, value) {
  try {
    _this.formNoValidate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__formTarget(_this) {
  try {
    return __dom_wrap(_this.formTarget);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__formTarget(_this, value) {
  try {
    _this.formTarget = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__incremental(_this) {
  try {
    return __dom_wrap(_this.incremental);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__incremental(_this, value) {
  try {
    _this.incremental = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__indeterminate(_this) {
  try {
    return __dom_wrap(_this.indeterminate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__indeterminate(_this, value) {
  try {
    _this.indeterminate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__labels(_this) {
  try {
    return __dom_wrap(_this.labels);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__list(_this) {
  try {
    return __dom_wrap(_this.list);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__max(_this) {
  try {
    return __dom_wrap(_this.max);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__max(_this, value) {
  try {
    _this.max = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__maxLength(_this) {
  try {
    return __dom_wrap(_this.maxLength);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__maxLength(_this, value) {
  try {
    _this.maxLength = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__min(_this) {
  try {
    return __dom_wrap(_this.min);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__min(_this, value) {
  try {
    _this.min = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__multiple(_this) {
  try {
    return __dom_wrap(_this.multiple);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__multiple(_this, value) {
  try {
    _this.multiple = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__onwebkitspeechchange(_this) {
  try {
    return __dom_wrap(_this.onwebkitspeechchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__onwebkitspeechchange(_this, value) {
  try {
    _this.onwebkitspeechchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__pattern(_this) {
  try {
    return __dom_wrap(_this.pattern);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__pattern(_this, value) {
  try {
    _this.pattern = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__placeholder(_this) {
  try {
    return __dom_wrap(_this.placeholder);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__placeholder(_this, value) {
  try {
    _this.placeholder = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__readOnly(_this) {
  try {
    return __dom_wrap(_this.readOnly);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__readOnly(_this, value) {
  try {
    _this.readOnly = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__required(_this) {
  try {
    return __dom_wrap(_this.required);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__required(_this, value) {
  try {
    _this.required = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__selectedOption(_this) {
  try {
    return __dom_wrap(_this.selectedOption);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__selectionDirection(_this) {
  try {
    return __dom_wrap(_this.selectionDirection);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__selectionDirection(_this, value) {
  try {
    _this.selectionDirection = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__selectionEnd(_this) {
  try {
    return __dom_wrap(_this.selectionEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__selectionEnd(_this, value) {
  try {
    _this.selectionEnd = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__selectionStart(_this) {
  try {
    return __dom_wrap(_this.selectionStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__selectionStart(_this, value) {
  try {
    _this.selectionStart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__size(_this) {
  try {
    return __dom_wrap(_this.size);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__size(_this, value) {
  try {
    _this.size = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__step(_this) {
  try {
    return __dom_wrap(_this.step);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__step(_this, value) {
  try {
    _this.step = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__useMap(_this) {
  try {
    return __dom_wrap(_this.useMap);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__useMap(_this, value) {
  try {
    _this.useMap = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__validationMessage(_this) {
  try {
    return __dom_wrap(_this.validationMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__validity(_this) {
  try {
    return __dom_wrap(_this.validity);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__valueAsDate(_this) {
  try {
    return __dom_wrap(_this.valueAsDate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__valueAsDate(_this, value) {
  try {
    _this.valueAsDate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__valueAsNumber(_this) {
  try {
    return __dom_wrap(_this.valueAsNumber);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__valueAsNumber(_this, value) {
  try {
    _this.valueAsNumber = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__webkitGrammar(_this) {
  try {
    return __dom_wrap(_this.webkitGrammar);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__webkitGrammar(_this, value) {
  try {
    _this.webkitGrammar = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__webkitSpeech(_this) {
  try {
    return __dom_wrap(_this.webkitSpeech);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__webkitSpeech(_this, value) {
  try {
    _this.webkitSpeech = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__webkitdirectory(_this) {
  try {
    return __dom_wrap(_this.webkitdirectory);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__set__webkitdirectory(_this, value) {
  try {
    _this.webkitdirectory = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__get__willValidate(_this) {
  try {
    return __dom_wrap(_this.willValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__click(_this) {
  try {
    return __dom_wrap(_this.click());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__select(_this) {
  try {
    return __dom_wrap(_this.select());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__setCustomValidity(_this, error) {
  try {
    return __dom_wrap(_this.setCustomValidity(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__setSelectionRange(_this) {
  try {
    return __dom_wrap(_this.setSelectionRange());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__setSelectionRange_2(_this, start) {
  try {
    return __dom_wrap(_this.setSelectionRange(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__setSelectionRange_3(_this, start, end) {
  try {
    return __dom_wrap(_this.setSelectionRange(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__setSelectionRange_4(_this, start, end, direction) {
  try {
    return __dom_wrap(_this.setSelectionRange(__dom_unwrap(start), __dom_unwrap(end), __dom_unwrap(direction)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__setValueForUser(_this, value) {
  try {
    return __dom_wrap(_this.setValueForUser(__dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__stepDown(_this) {
  try {
    return __dom_wrap(_this.stepDown());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__stepDown_2(_this, n) {
  try {
    return __dom_wrap(_this.stepDown(__dom_unwrap(n)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__stepUp(_this) {
  try {
    return __dom_wrap(_this.stepUp());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLInputElementWrappingImplementation__stepUp_2(_this, n) {
  try {
    return __dom_wrap(_this.stepUp(__dom_unwrap(n)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIsIndexElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIsIndexElementWrappingImplementation__get__prompt(_this) {
  try {
    return __dom_wrap(_this.prompt);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLIsIndexElementWrappingImplementation__set__prompt(_this, value) {
  try {
    _this.prompt = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__autofocus(_this) {
  try {
    return __dom_wrap(_this.autofocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__set__autofocus(_this, value) {
  try {
    _this.autofocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__challenge(_this) {
  try {
    return __dom_wrap(_this.challenge);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__set__challenge(_this, value) {
  try {
    _this.challenge = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__keytype(_this) {
  try {
    return __dom_wrap(_this.keytype);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__set__keytype(_this, value) {
  try {
    _this.keytype = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__labels(_this) {
  try {
    return __dom_wrap(_this.labels);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__validationMessage(_this) {
  try {
    return __dom_wrap(_this.validationMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__validity(_this) {
  try {
    return __dom_wrap(_this.validity);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__get__willValidate(_this) {
  try {
    return __dom_wrap(_this.willValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLKeygenElementWrappingImplementation__setCustomValidity(_this, error) {
  try {
    return __dom_wrap(_this.setCustomValidity(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLIElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLIElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLIElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLIElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLabelElementWrappingImplementation__get__accessKey(_this) {
  try {
    return __dom_wrap(_this.accessKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLabelElementWrappingImplementation__set__accessKey(_this, value) {
  try {
    _this.accessKey = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLabelElementWrappingImplementation__get__control(_this) {
  try {
    return __dom_wrap(_this.control);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLabelElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLabelElementWrappingImplementation__get__htmlFor(_this) {
  try {
    return __dom_wrap(_this.htmlFor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLabelElementWrappingImplementation__set__htmlFor(_this, value) {
  try {
    _this.htmlFor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLegendElementWrappingImplementation__get__accessKey(_this) {
  try {
    return __dom_wrap(_this.accessKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLegendElementWrappingImplementation__set__accessKey(_this, value) {
  try {
    _this.accessKey = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLegendElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLegendElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLegendElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__charset(_this) {
  try {
    return __dom_wrap(_this.charset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__charset(_this, value) {
  try {
    _this.charset = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__href(_this) {
  try {
    return __dom_wrap(_this.href);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__href(_this, value) {
  try {
    _this.href = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__hreflang(_this) {
  try {
    return __dom_wrap(_this.hreflang);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__hreflang(_this, value) {
  try {
    _this.hreflang = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__media(_this) {
  try {
    return __dom_wrap(_this.media);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__media(_this, value) {
  try {
    _this.media = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__rel(_this) {
  try {
    return __dom_wrap(_this.rel);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__rel(_this, value) {
  try {
    _this.rel = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__rev(_this) {
  try {
    return __dom_wrap(_this.rev);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__rev(_this, value) {
  try {
    _this.rev = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__sheet(_this) {
  try {
    return __dom_wrap(_this.sheet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__target(_this) {
  try {
    return __dom_wrap(_this.target);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__target(_this, value) {
  try {
    _this.target = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLLinkElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMapElementWrappingImplementation__get__areas(_this) {
  try {
    return __dom_wrap(_this.areas);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMapElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMapElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__behavior(_this) {
  try {
    return __dom_wrap(_this.behavior);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__behavior(_this, value) {
  try {
    _this.behavior = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__bgColor(_this) {
  try {
    return __dom_wrap(_this.bgColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__bgColor(_this, value) {
  try {
    _this.bgColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__direction(_this) {
  try {
    return __dom_wrap(_this.direction);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__direction(_this, value) {
  try {
    _this.direction = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__hspace(_this) {
  try {
    return __dom_wrap(_this.hspace);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__hspace(_this, value) {
  try {
    _this.hspace = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__loop(_this) {
  try {
    return __dom_wrap(_this.loop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__loop(_this, value) {
  try {
    _this.loop = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__scrollAmount(_this) {
  try {
    return __dom_wrap(_this.scrollAmount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__scrollAmount(_this, value) {
  try {
    _this.scrollAmount = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__scrollDelay(_this) {
  try {
    return __dom_wrap(_this.scrollDelay);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__scrollDelay(_this, value) {
  try {
    _this.scrollDelay = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__trueSpeed(_this) {
  try {
    return __dom_wrap(_this.trueSpeed);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__trueSpeed(_this, value) {
  try {
    _this.trueSpeed = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__vspace(_this) {
  try {
    return __dom_wrap(_this.vspace);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__vspace(_this, value) {
  try {
    _this.vspace = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__start(_this) {
  try {
    return __dom_wrap(_this.start());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMarqueeElementWrappingImplementation__stop(_this) {
  try {
    return __dom_wrap(_this.stop());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__autoplay(_this) {
  try {
    return __dom_wrap(_this.autoplay);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__autoplay(_this, value) {
  try {
    _this.autoplay = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__buffered(_this) {
  try {
    return __dom_wrap(_this.buffered);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__controls(_this) {
  try {
    return __dom_wrap(_this.controls);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__controls(_this, value) {
  try {
    _this.controls = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__currentSrc(_this) {
  try {
    return __dom_wrap(_this.currentSrc);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__currentTime(_this) {
  try {
    return __dom_wrap(_this.currentTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__currentTime(_this, value) {
  try {
    _this.currentTime = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__defaultPlaybackRate(_this) {
  try {
    return __dom_wrap(_this.defaultPlaybackRate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__defaultPlaybackRate(_this, value) {
  try {
    _this.defaultPlaybackRate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__duration(_this) {
  try {
    return __dom_wrap(_this.duration);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__ended(_this) {
  try {
    return __dom_wrap(_this.ended);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__error(_this) {
  try {
    return __dom_wrap(_this.error);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__loop(_this) {
  try {
    return __dom_wrap(_this.loop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__loop(_this, value) {
  try {
    _this.loop = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__muted(_this) {
  try {
    return __dom_wrap(_this.muted);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__muted(_this, value) {
  try {
    _this.muted = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__networkState(_this) {
  try {
    return __dom_wrap(_this.networkState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__paused(_this) {
  try {
    return __dom_wrap(_this.paused);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__playbackRate(_this) {
  try {
    return __dom_wrap(_this.playbackRate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__playbackRate(_this, value) {
  try {
    _this.playbackRate = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__played(_this) {
  try {
    return __dom_wrap(_this.played);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__preload(_this) {
  try {
    return __dom_wrap(_this.preload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__preload(_this, value) {
  try {
    _this.preload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__seekable(_this) {
  try {
    return __dom_wrap(_this.seekable);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__seeking(_this) {
  try {
    return __dom_wrap(_this.seeking);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__startTime(_this) {
  try {
    return __dom_wrap(_this.startTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__volume(_this) {
  try {
    return __dom_wrap(_this.volume);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__volume(_this, value) {
  try {
    _this.volume = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__webkitAudioDecodedByteCount(_this) {
  try {
    return __dom_wrap(_this.webkitAudioDecodedByteCount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__webkitClosedCaptionsVisible(_this) {
  try {
    return __dom_wrap(_this.webkitClosedCaptionsVisible);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__webkitClosedCaptionsVisible(_this, value) {
  try {
    _this.webkitClosedCaptionsVisible = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__webkitHasClosedCaptions(_this) {
  try {
    return __dom_wrap(_this.webkitHasClosedCaptions);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__webkitPreservesPitch(_this) {
  try {
    return __dom_wrap(_this.webkitPreservesPitch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__set__webkitPreservesPitch(_this, value) {
  try {
    _this.webkitPreservesPitch = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__get__webkitVideoDecodedByteCount(_this) {
  try {
    return __dom_wrap(_this.webkitVideoDecodedByteCount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__canPlayType(_this) {
  try {
    return __dom_wrap(_this.canPlayType());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__canPlayType_2(_this, type) {
  try {
    return __dom_wrap(_this.canPlayType(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__load(_this) {
  try {
    return __dom_wrap(_this.load());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__pause(_this) {
  try {
    return __dom_wrap(_this.pause());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMediaElementWrappingImplementation__play(_this) {
  try {
    return __dom_wrap(_this.play());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMenuElementWrappingImplementation__get__compact(_this) {
  try {
    return __dom_wrap(_this.compact);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMenuElementWrappingImplementation__set__compact(_this, value) {
  try {
    _this.compact = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMetaElementWrappingImplementation__get__content(_this) {
  try {
    return __dom_wrap(_this.content);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMetaElementWrappingImplementation__set__content(_this, value) {
  try {
    _this.content = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMetaElementWrappingImplementation__get__httpEquiv(_this) {
  try {
    return __dom_wrap(_this.httpEquiv);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMetaElementWrappingImplementation__set__httpEquiv(_this, value) {
  try {
    _this.httpEquiv = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMetaElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMetaElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMetaElementWrappingImplementation__get__scheme(_this) {
  try {
    return __dom_wrap(_this.scheme);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMetaElementWrappingImplementation__set__scheme(_this, value) {
  try {
    _this.scheme = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__get__high(_this) {
  try {
    return __dom_wrap(_this.high);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__set__high(_this, value) {
  try {
    _this.high = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__get__labels(_this) {
  try {
    return __dom_wrap(_this.labels);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__get__low(_this) {
  try {
    return __dom_wrap(_this.low);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__set__low(_this, value) {
  try {
    _this.low = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__get__max(_this) {
  try {
    return __dom_wrap(_this.max);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__set__max(_this, value) {
  try {
    _this.max = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__get__min(_this) {
  try {
    return __dom_wrap(_this.min);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__set__min(_this, value) {
  try {
    _this.min = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__get__optimum(_this) {
  try {
    return __dom_wrap(_this.optimum);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__set__optimum(_this, value) {
  try {
    _this.optimum = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLMeterElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLModElementWrappingImplementation__get__cite(_this) {
  try {
    return __dom_wrap(_this.cite);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLModElementWrappingImplementation__set__cite(_this, value) {
  try {
    _this.cite = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLModElementWrappingImplementation__get__dateTime(_this) {
  try {
    return __dom_wrap(_this.dateTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLModElementWrappingImplementation__set__dateTime(_this, value) {
  try {
    _this.dateTime = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOListElementWrappingImplementation__get__compact(_this) {
  try {
    return __dom_wrap(_this.compact);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOListElementWrappingImplementation__set__compact(_this, value) {
  try {
    _this.compact = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOListElementWrappingImplementation__get__start(_this) {
  try {
    return __dom_wrap(_this.start);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOListElementWrappingImplementation__set__start(_this, value) {
  try {
    _this.start = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOListElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOListElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__archive(_this) {
  try {
    return __dom_wrap(_this.archive);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__archive(_this, value) {
  try {
    _this.archive = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__border(_this) {
  try {
    return __dom_wrap(_this.border);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__border(_this, value) {
  try {
    _this.border = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__code(_this, value) {
  try {
    _this.code = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__codeBase(_this) {
  try {
    return __dom_wrap(_this.codeBase);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__codeBase(_this, value) {
  try {
    _this.codeBase = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__codeType(_this) {
  try {
    return __dom_wrap(_this.codeType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__codeType(_this, value) {
  try {
    _this.codeType = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__contentDocument(_this) {
  try {
    return __dom_wrap(_this.contentDocument);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__data(_this) {
  try {
    return __dom_wrap(_this.data);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__data(_this, value) {
  try {
    _this.data = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__declare(_this) {
  try {
    return __dom_wrap(_this.declare);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__declare(_this, value) {
  try {
    _this.declare = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__hspace(_this) {
  try {
    return __dom_wrap(_this.hspace);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__hspace(_this, value) {
  try {
    _this.hspace = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__standby(_this) {
  try {
    return __dom_wrap(_this.standby);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__standby(_this, value) {
  try {
    _this.standby = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__useMap(_this) {
  try {
    return __dom_wrap(_this.useMap);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__useMap(_this, value) {
  try {
    _this.useMap = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__validationMessage(_this) {
  try {
    return __dom_wrap(_this.validationMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__validity(_this) {
  try {
    return __dom_wrap(_this.validity);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__vspace(_this) {
  try {
    return __dom_wrap(_this.vspace);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__vspace(_this, value) {
  try {
    _this.vspace = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__get__willValidate(_this) {
  try {
    return __dom_wrap(_this.willValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLObjectElementWrappingImplementation__setCustomValidity(_this, error) {
  try {
    return __dom_wrap(_this.setCustomValidity(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptGroupElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptGroupElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptGroupElementWrappingImplementation__get__label(_this) {
  try {
    return __dom_wrap(_this.label);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptGroupElementWrappingImplementation__set__label(_this, value) {
  try {
    _this.label = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__get__defaultSelected(_this) {
  try {
    return __dom_wrap(_this.defaultSelected);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__set__defaultSelected(_this, value) {
  try {
    _this.defaultSelected = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__get__index(_this) {
  try {
    return __dom_wrap(_this.index);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__get__label(_this) {
  try {
    return __dom_wrap(_this.label);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__set__label(_this, value) {
  try {
    _this.label = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__get__selected(_this) {
  try {
    return __dom_wrap(_this.selected);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__set__selected(_this, value) {
  try {
    _this.selected = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__get__text(_this) {
  try {
    return __dom_wrap(_this.text);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionsCollectionWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionsCollectionWrappingImplementation__set__length(_this, value) {
  try {
    _this.length = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionsCollectionWrappingImplementation__get__selectedIndex(_this) {
  try {
    return __dom_wrap(_this.selectedIndex);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionsCollectionWrappingImplementation__set__selectedIndex(_this, value) {
  try {
    _this.selectedIndex = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionsCollectionWrappingImplementation__remove(_this) {
  try {
    return __dom_wrap(_this.remove());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOptionsCollectionWrappingImplementation__remove_2(_this, index) {
  try {
    return __dom_wrap(_this.remove(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__defaultValue(_this) {
  try {
    return __dom_wrap(_this.defaultValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__set__defaultValue(_this, value) {
  try {
    _this.defaultValue = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__htmlFor(_this) {
  try {
    return __dom_wrap(_this.htmlFor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__set__htmlFor(_this, value) {
  try {
    _this.htmlFor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__labels(_this) {
  try {
    return __dom_wrap(_this.labels);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__validationMessage(_this) {
  try {
    return __dom_wrap(_this.validationMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__validity(_this) {
  try {
    return __dom_wrap(_this.validity);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__get__willValidate(_this) {
  try {
    return __dom_wrap(_this.willValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLOutputElementWrappingImplementation__setCustomValidity(_this, error) {
  try {
    return __dom_wrap(_this.setCustomValidity(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParagraphElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParagraphElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParamElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParamElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParamElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParamElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParamElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParamElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParamElementWrappingImplementation__get__valueType(_this) {
  try {
    return __dom_wrap(_this.valueType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLParamElementWrappingImplementation__set__valueType(_this, value) {
  try {
    _this.valueType = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLPreElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLPreElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLPreElementWrappingImplementation__get__wrap(_this) {
  try {
    return __dom_wrap(_this.wrap);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLPreElementWrappingImplementation__set__wrap(_this, value) {
  try {
    _this.wrap = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLProgressElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLProgressElementWrappingImplementation__get__labels(_this) {
  try {
    return __dom_wrap(_this.labels);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLProgressElementWrappingImplementation__get__max(_this) {
  try {
    return __dom_wrap(_this.max);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLProgressElementWrappingImplementation__set__max(_this, value) {
  try {
    _this.max = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLProgressElementWrappingImplementation__get__position(_this) {
  try {
    return __dom_wrap(_this.position);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLProgressElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLProgressElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLQuoteElementWrappingImplementation__get__cite(_this) {
  try {
    return __dom_wrap(_this.cite);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLQuoteElementWrappingImplementation__set__cite(_this, value) {
  try {
    _this.cite = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__get__async(_this) {
  try {
    return __dom_wrap(_this.async);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__set__async(_this, value) {
  try {
    _this.async = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__get__charset(_this) {
  try {
    return __dom_wrap(_this.charset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__set__charset(_this, value) {
  try {
    _this.charset = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__get__defer(_this) {
  try {
    return __dom_wrap(_this.defer);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__set__defer(_this, value) {
  try {
    _this.defer = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__get__event(_this) {
  try {
    return __dom_wrap(_this.event);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__set__event(_this, value) {
  try {
    _this.event = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__get__htmlFor(_this) {
  try {
    return __dom_wrap(_this.htmlFor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__set__htmlFor(_this, value) {
  try {
    _this.htmlFor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__get__text(_this) {
  try {
    return __dom_wrap(_this.text);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__set__text(_this, value) {
  try {
    _this.text = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLScriptElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__autofocus(_this) {
  try {
    return __dom_wrap(_this.autofocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__autofocus(_this, value) {
  try {
    _this.autofocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__labels(_this) {
  try {
    return __dom_wrap(_this.labels);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__length(_this, value) {
  try {
    _this.length = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__multiple(_this) {
  try {
    return __dom_wrap(_this.multiple);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__multiple(_this, value) {
  try {
    _this.multiple = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__options(_this) {
  try {
    return __dom_wrap(_this.options);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__required(_this) {
  try {
    return __dom_wrap(_this.required);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__required(_this, value) {
  try {
    _this.required = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__selectedIndex(_this) {
  try {
    return __dom_wrap(_this.selectedIndex);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__selectedIndex(_this, value) {
  try {
    _this.selectedIndex = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__size(_this) {
  try {
    return __dom_wrap(_this.size);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__size(_this, value) {
  try {
    _this.size = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__validationMessage(_this) {
  try {
    return __dom_wrap(_this.validationMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__validity(_this) {
  try {
    return __dom_wrap(_this.validity);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__get__willValidate(_this) {
  try {
    return __dom_wrap(_this.willValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__add(_this) {
  try {
    return __dom_wrap(_this.add());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__add_2(_this, element) {
  try {
    return __dom_wrap(_this.add(__dom_unwrap(element)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__add_3(_this, element, before) {
  try {
    return __dom_wrap(_this.add(__dom_unwrap(element), __dom_unwrap(before)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__namedItem(_this) {
  try {
    return __dom_wrap(_this.namedItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__namedItem_2(_this, name) {
  try {
    return __dom_wrap(_this.namedItem(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__remove(_this, index) {
  try {
    return __dom_wrap(_this.remove(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSelectElementWrappingImplementation__setCustomValidity(_this, error) {
  try {
    return __dom_wrap(_this.setCustomValidity(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSourceElementWrappingImplementation__get__media(_this) {
  try {
    return __dom_wrap(_this.media);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSourceElementWrappingImplementation__set__media(_this, value) {
  try {
    _this.media = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSourceElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSourceElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSourceElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLSourceElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLStyleElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLStyleElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLStyleElementWrappingImplementation__get__media(_this) {
  try {
    return __dom_wrap(_this.media);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLStyleElementWrappingImplementation__set__media(_this, value) {
  try {
    _this.media = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLStyleElementWrappingImplementation__get__sheet(_this) {
  try {
    return __dom_wrap(_this.sheet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLStyleElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLStyleElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCaptionElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCaptionElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__abbr(_this) {
  try {
    return __dom_wrap(_this.abbr);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__abbr(_this, value) {
  try {
    _this.abbr = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__axis(_this) {
  try {
    return __dom_wrap(_this.axis);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__axis(_this, value) {
  try {
    _this.axis = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__bgColor(_this) {
  try {
    return __dom_wrap(_this.bgColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__bgColor(_this, value) {
  try {
    _this.bgColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__cellIndex(_this) {
  try {
    return __dom_wrap(_this.cellIndex);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__ch(_this) {
  try {
    return __dom_wrap(_this.ch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__ch(_this, value) {
  try {
    _this.ch = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__chOff(_this) {
  try {
    return __dom_wrap(_this.chOff);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__chOff(_this, value) {
  try {
    _this.chOff = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__colSpan(_this) {
  try {
    return __dom_wrap(_this.colSpan);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__colSpan(_this, value) {
  try {
    _this.colSpan = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__headers(_this) {
  try {
    return __dom_wrap(_this.headers);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__headers(_this, value) {
  try {
    _this.headers = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__noWrap(_this) {
  try {
    return __dom_wrap(_this.noWrap);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__noWrap(_this, value) {
  try {
    _this.noWrap = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__rowSpan(_this) {
  try {
    return __dom_wrap(_this.rowSpan);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__rowSpan(_this, value) {
  try {
    _this.rowSpan = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__scope(_this) {
  try {
    return __dom_wrap(_this.scope);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__scope(_this, value) {
  try {
    _this.scope = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__vAlign(_this) {
  try {
    return __dom_wrap(_this.vAlign);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__vAlign(_this, value) {
  try {
    _this.vAlign = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableCellElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__get__ch(_this) {
  try {
    return __dom_wrap(_this.ch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__set__ch(_this, value) {
  try {
    _this.ch = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__get__chOff(_this) {
  try {
    return __dom_wrap(_this.chOff);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__set__chOff(_this, value) {
  try {
    _this.chOff = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__get__span(_this) {
  try {
    return __dom_wrap(_this.span);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__set__span(_this, value) {
  try {
    _this.span = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__get__vAlign(_this) {
  try {
    return __dom_wrap(_this.vAlign);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__set__vAlign(_this, value) {
  try {
    _this.vAlign = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableColElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__bgColor(_this) {
  try {
    return __dom_wrap(_this.bgColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__bgColor(_this, value) {
  try {
    _this.bgColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__border(_this) {
  try {
    return __dom_wrap(_this.border);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__border(_this, value) {
  try {
    _this.border = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__caption(_this) {
  try {
    return __dom_wrap(_this.caption);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__caption(_this, value) {
  try {
    _this.caption = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__cellPadding(_this) {
  try {
    return __dom_wrap(_this.cellPadding);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__cellPadding(_this, value) {
  try {
    _this.cellPadding = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__cellSpacing(_this) {
  try {
    return __dom_wrap(_this.cellSpacing);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__cellSpacing(_this, value) {
  try {
    _this.cellSpacing = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__frame(_this) {
  try {
    return __dom_wrap(_this.frame);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__frame(_this, value) {
  try {
    _this.frame = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__rows(_this) {
  try {
    return __dom_wrap(_this.rows);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__rules(_this) {
  try {
    return __dom_wrap(_this.rules);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__rules(_this, value) {
  try {
    _this.rules = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__summary(_this) {
  try {
    return __dom_wrap(_this.summary);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__summary(_this, value) {
  try {
    _this.summary = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__tBodies(_this) {
  try {
    return __dom_wrap(_this.tBodies);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__tFoot(_this) {
  try {
    return __dom_wrap(_this.tFoot);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__tFoot(_this, value) {
  try {
    _this.tFoot = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__tHead(_this) {
  try {
    return __dom_wrap(_this.tHead);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__tHead(_this, value) {
  try {
    _this.tHead = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__createCaption(_this) {
  try {
    return __dom_wrap(_this.createCaption());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__createTFoot(_this) {
  try {
    return __dom_wrap(_this.createTFoot());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__createTHead(_this) {
  try {
    return __dom_wrap(_this.createTHead());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__deleteCaption(_this) {
  try {
    return __dom_wrap(_this.deleteCaption());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__deleteRow(_this) {
  try {
    return __dom_wrap(_this.deleteRow());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__deleteRow_2(_this, index) {
  try {
    return __dom_wrap(_this.deleteRow(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__deleteTFoot(_this) {
  try {
    return __dom_wrap(_this.deleteTFoot());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__deleteTHead(_this) {
  try {
    return __dom_wrap(_this.deleteTHead());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__insertRow(_this) {
  try {
    return __dom_wrap(_this.insertRow());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableElementWrappingImplementation__insertRow_2(_this, index) {
  try {
    return __dom_wrap(_this.insertRow(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__get__bgColor(_this) {
  try {
    return __dom_wrap(_this.bgColor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__set__bgColor(_this, value) {
  try {
    _this.bgColor = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__get__cells(_this) {
  try {
    return __dom_wrap(_this.cells);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__get__ch(_this) {
  try {
    return __dom_wrap(_this.ch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__set__ch(_this, value) {
  try {
    _this.ch = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__get__chOff(_this) {
  try {
    return __dom_wrap(_this.chOff);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__set__chOff(_this, value) {
  try {
    _this.chOff = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__get__rowIndex(_this) {
  try {
    return __dom_wrap(_this.rowIndex);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__get__sectionRowIndex(_this) {
  try {
    return __dom_wrap(_this.sectionRowIndex);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__get__vAlign(_this) {
  try {
    return __dom_wrap(_this.vAlign);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__set__vAlign(_this, value) {
  try {
    _this.vAlign = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__deleteCell(_this) {
  try {
    return __dom_wrap(_this.deleteCell());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__deleteCell_2(_this, index) {
  try {
    return __dom_wrap(_this.deleteCell(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__insertCell(_this) {
  try {
    return __dom_wrap(_this.insertCell());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableRowElementWrappingImplementation__insertCell_2(_this, index) {
  try {
    return __dom_wrap(_this.insertCell(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__get__align(_this) {
  try {
    return __dom_wrap(_this.align);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__set__align(_this, value) {
  try {
    _this.align = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__get__ch(_this) {
  try {
    return __dom_wrap(_this.ch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__set__ch(_this, value) {
  try {
    _this.ch = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__get__chOff(_this) {
  try {
    return __dom_wrap(_this.chOff);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__set__chOff(_this, value) {
  try {
    _this.chOff = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__get__rows(_this) {
  try {
    return __dom_wrap(_this.rows);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__get__vAlign(_this) {
  try {
    return __dom_wrap(_this.vAlign);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__set__vAlign(_this, value) {
  try {
    _this.vAlign = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__deleteRow(_this) {
  try {
    return __dom_wrap(_this.deleteRow());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__deleteRow_2(_this, index) {
  try {
    return __dom_wrap(_this.deleteRow(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__insertRow(_this) {
  try {
    return __dom_wrap(_this.insertRow());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTableSectionElementWrappingImplementation__insertRow_2(_this, index) {
  try {
    return __dom_wrap(_this.insertRow(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__accessKey(_this) {
  try {
    return __dom_wrap(_this.accessKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__accessKey(_this, value) {
  try {
    _this.accessKey = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__autofocus(_this) {
  try {
    return __dom_wrap(_this.autofocus);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__autofocus(_this, value) {
  try {
    _this.autofocus = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__cols(_this) {
  try {
    return __dom_wrap(_this.cols);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__cols(_this, value) {
  try {
    _this.cols = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__defaultValue(_this) {
  try {
    return __dom_wrap(_this.defaultValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__defaultValue(_this, value) {
  try {
    _this.defaultValue = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__form(_this) {
  try {
    return __dom_wrap(_this.form);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__labels(_this) {
  try {
    return __dom_wrap(_this.labels);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__maxLength(_this) {
  try {
    return __dom_wrap(_this.maxLength);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__maxLength(_this, value) {
  try {
    _this.maxLength = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__placeholder(_this) {
  try {
    return __dom_wrap(_this.placeholder);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__placeholder(_this, value) {
  try {
    _this.placeholder = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__readOnly(_this) {
  try {
    return __dom_wrap(_this.readOnly);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__readOnly(_this, value) {
  try {
    _this.readOnly = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__required(_this) {
  try {
    return __dom_wrap(_this.required);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__required(_this, value) {
  try {
    _this.required = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__rows(_this) {
  try {
    return __dom_wrap(_this.rows);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__rows(_this, value) {
  try {
    _this.rows = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__selectionDirection(_this) {
  try {
    return __dom_wrap(_this.selectionDirection);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__selectionDirection(_this, value) {
  try {
    _this.selectionDirection = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__selectionEnd(_this) {
  try {
    return __dom_wrap(_this.selectionEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__selectionEnd(_this, value) {
  try {
    _this.selectionEnd = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__selectionStart(_this) {
  try {
    return __dom_wrap(_this.selectionStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__selectionStart(_this, value) {
  try {
    _this.selectionStart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__textLength(_this) {
  try {
    return __dom_wrap(_this.textLength);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__validationMessage(_this) {
  try {
    return __dom_wrap(_this.validationMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__validity(_this) {
  try {
    return __dom_wrap(_this.validity);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__set__value(_this, value) {
  try {
    _this.value = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__get__willValidate(_this) {
  try {
    return __dom_wrap(_this.willValidate);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__checkValidity(_this) {
  try {
    return __dom_wrap(_this.checkValidity());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__select(_this) {
  try {
    return __dom_wrap(_this.select());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__setCustomValidity(_this, error) {
  try {
    return __dom_wrap(_this.setCustomValidity(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__setSelectionRange(_this) {
  try {
    return __dom_wrap(_this.setSelectionRange());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__setSelectionRange_2(_this, start) {
  try {
    return __dom_wrap(_this.setSelectionRange(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__setSelectionRange_3(_this, start, end) {
  try {
    return __dom_wrap(_this.setSelectionRange(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTextAreaElementWrappingImplementation__setSelectionRange_4(_this, start, end, direction) {
  try {
    return __dom_wrap(_this.setSelectionRange(__dom_unwrap(start), __dom_unwrap(end), __dom_unwrap(direction)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTitleElementWrappingImplementation__get__text(_this) {
  try {
    return __dom_wrap(_this.text);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTitleElementWrappingImplementation__set__text(_this, value) {
  try {
    _this.text = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__get__isDefault(_this) {
  try {
    return __dom_wrap(_this.isDefault);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__set__isDefault(_this, value) {
  try {
    _this.isDefault = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__get__kind(_this) {
  try {
    return __dom_wrap(_this.kind);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__set__kind(_this, value) {
  try {
    _this.kind = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__get__label(_this) {
  try {
    return __dom_wrap(_this.label);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__set__label(_this, value) {
  try {
    _this.label = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__get__src(_this) {
  try {
    return __dom_wrap(_this.src);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__set__src(_this, value) {
  try {
    _this.src = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__get__srclang(_this) {
  try {
    return __dom_wrap(_this.srclang);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLTrackElementWrappingImplementation__set__srclang(_this, value) {
  try {
    _this.srclang = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLUListElementWrappingImplementation__get__compact(_this) {
  try {
    return __dom_wrap(_this.compact);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLUListElementWrappingImplementation__set__compact(_this, value) {
  try {
    _this.compact = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLUListElementWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLUListElementWrappingImplementation__set__type(_this, value) {
  try {
    _this.type = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__set__height(_this, value) {
  try {
    _this.height = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__poster(_this) {
  try {
    return __dom_wrap(_this.poster);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__set__poster(_this, value) {
  try {
    _this.poster = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__videoHeight(_this) {
  try {
    return __dom_wrap(_this.videoHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__videoWidth(_this) {
  try {
    return __dom_wrap(_this.videoWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__webkitDecodedFrameCount(_this) {
  try {
    return __dom_wrap(_this.webkitDecodedFrameCount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__webkitDisplayingFullscreen(_this) {
  try {
    return __dom_wrap(_this.webkitDisplayingFullscreen);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__webkitDroppedFrameCount(_this) {
  try {
    return __dom_wrap(_this.webkitDroppedFrameCount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__webkitSupportsFullscreen(_this) {
  try {
    return __dom_wrap(_this.webkitSupportsFullscreen);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__set__width(_this, value) {
  try {
    _this.width = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__webkitEnterFullScreen(_this) {
  try {
    return __dom_wrap(_this.webkitEnterFullScreen());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__webkitEnterFullscreen(_this) {
  try {
    return __dom_wrap(_this.webkitEnterFullscreen());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__webkitExitFullScreen(_this) {
  try {
    return __dom_wrap(_this.webkitExitFullScreen());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HTMLVideoElementWrappingImplementation__webkitExitFullscreen(_this) {
  try {
    return __dom_wrap(_this.webkitExitFullscreen());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HashChangeEventWrappingImplementation__get__newURL(_this) {
  try {
    return __dom_wrap(_this.newURL);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HashChangeEventWrappingImplementation__get__oldURL(_this) {
  try {
    return __dom_wrap(_this.oldURL);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HashChangeEventWrappingImplementation__initHashChangeEvent(_this) {
  try {
    return __dom_wrap(_this.initHashChangeEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HashChangeEventWrappingImplementation__initHashChangeEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initHashChangeEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HashChangeEventWrappingImplementation__initHashChangeEvent_3(_this, type, canBubble) {
  try {
    return __dom_wrap(_this.initHashChangeEvent(__dom_unwrap(type), __dom_unwrap(canBubble)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HashChangeEventWrappingImplementation__initHashChangeEvent_4(_this, type, canBubble, cancelable) {
  try {
    return __dom_wrap(_this.initHashChangeEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HashChangeEventWrappingImplementation__initHashChangeEvent_5(_this, type, canBubble, cancelable, oldURL) {
  try {
    return __dom_wrap(_this.initHashChangeEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(oldURL)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HashChangeEventWrappingImplementation__initHashChangeEvent_6(_this, type, canBubble, cancelable, oldURL, newURL) {
  try {
    return __dom_wrap(_this.initHashChangeEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(oldURL), __dom_unwrap(newURL)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__back(_this) {
  try {
    return __dom_wrap(_this.back());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__forward(_this) {
  try {
    return __dom_wrap(_this.forward());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__go(_this) {
  try {
    return __dom_wrap(_this.go());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__go_2(_this, delta) {
  try {
    return __dom_wrap(_this.go(__dom_unwrap(delta)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__pushState(_this, data, title) {
  try {
    return __dom_wrap(_this.pushState(__dom_unwrap(data), __dom_unwrap(title)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__pushState_2(_this, data, title, url) {
  try {
    return __dom_wrap(_this.pushState(__dom_unwrap(data), __dom_unwrap(title), __dom_unwrap(url)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__replaceState(_this, data, title) {
  try {
    return __dom_wrap(_this.replaceState(__dom_unwrap(data), __dom_unwrap(title)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__HistoryWrappingImplementation__replaceState_2(_this, data, title, url) {
  try {
    return __dom_wrap(_this.replaceState(__dom_unwrap(data), __dom_unwrap(title), __dom_unwrap(url)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBCursorWrappingImplementation__get__direction(_this) {
  try {
    return __dom_wrap(_this.direction);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBCursorWrappingImplementation__get__key(_this) {
  try {
    return __dom_wrap(_this.key);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBCursorWrappingImplementation__get__primaryKey(_this) {
  try {
    return __dom_wrap(_this.primaryKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBCursorWrappingImplementation__get__source(_this) {
  try {
    return __dom_wrap(_this.source);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBCursorWrappingImplementation__delete(_this) {
  try {
    return __dom_wrap(_this.delete());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBCursorWrappingImplementation__update(_this, value) {
  try {
    return __dom_wrap(_this.update(__dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBCursorWithValueWrappingImplementation__get__value(_this) {
  try {
    return __dom_wrap(_this.value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__get__onversionchange(_this) {
  try {
    return __dom_wrap(_this.onversionchange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__set__onversionchange(_this, value) {
  try {
    _this.onversionchange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__get__version(_this) {
  try {
    return __dom_wrap(_this.version);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__close(_this) {
  try {
    return __dom_wrap(_this.close());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__createObjectStore(_this, name) {
  try {
    return __dom_wrap(_this.createObjectStore(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__deleteObjectStore(_this, name) {
  try {
    return __dom_wrap(_this.deleteObjectStore(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseWrappingImplementation__setVersion(_this, version) {
  try {
    return __dom_wrap(_this.setVersion(__dom_unwrap(version)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseErrorWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseErrorWrappingImplementation__set__code(_this, value) {
  try {
    _this.code = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseErrorWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseErrorWrappingImplementation__set__message(_this, value) {
  try {
    _this.message = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBDatabaseExceptionWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBFactoryWrappingImplementation__open(_this, name) {
  try {
    return __dom_wrap(_this.open(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__get__keyPath(_this) {
  try {
    return __dom_wrap(_this.keyPath);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__get__objectStore(_this) {
  try {
    return __dom_wrap(_this.objectStore);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__get__unique(_this) {
  try {
    return __dom_wrap(_this.unique);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__getKey(_this, key) {
  try {
    return __dom_wrap(_this.getKey(__dom_unwrap(key)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__openCursor(_this) {
  try {
    return __dom_wrap(_this.openCursor());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__openCursor_2(_this, range) {
  try {
    return __dom_wrap(_this.openCursor(__dom_unwrap(range)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__openCursor_3(_this, range, direction) {
  try {
    return __dom_wrap(_this.openCursor(__dom_unwrap(range), __dom_unwrap(direction)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__openKeyCursor(_this) {
  try {
    return __dom_wrap(_this.openKeyCursor());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__openKeyCursor_2(_this, range) {
  try {
    return __dom_wrap(_this.openKeyCursor(__dom_unwrap(range)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBIndexWrappingImplementation__openKeyCursor_3(_this, range, direction) {
  try {
    return __dom_wrap(_this.openKeyCursor(__dom_unwrap(range), __dom_unwrap(direction)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__get__lower(_this) {
  try {
    return __dom_wrap(_this.lower);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__get__lowerOpen(_this) {
  try {
    return __dom_wrap(_this.lowerOpen);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__get__upper(_this) {
  try {
    return __dom_wrap(_this.upper);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__get__upperOpen(_this) {
  try {
    return __dom_wrap(_this.upperOpen);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__bound(_this, lower, upper) {
  try {
    return __dom_wrap(_this.bound(__dom_unwrap(lower), __dom_unwrap(upper)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__bound_2(_this, lower, upper, lowerOpen) {
  try {
    return __dom_wrap(_this.bound(__dom_unwrap(lower), __dom_unwrap(upper), __dom_unwrap(lowerOpen)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__bound_3(_this, lower, upper, lowerOpen, upperOpen) {
  try {
    return __dom_wrap(_this.bound(__dom_unwrap(lower), __dom_unwrap(upper), __dom_unwrap(lowerOpen), __dom_unwrap(upperOpen)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__lowerBound(_this, bound) {
  try {
    return __dom_wrap(_this.lowerBound(__dom_unwrap(bound)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__lowerBound_2(_this, bound, open) {
  try {
    return __dom_wrap(_this.lowerBound(__dom_unwrap(bound), __dom_unwrap(open)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__only(_this, value) {
  try {
    return __dom_wrap(_this.only(__dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__upperBound(_this, bound) {
  try {
    return __dom_wrap(_this.upperBound(__dom_unwrap(bound)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBKeyRangeWrappingImplementation__upperBound_2(_this, bound, open) {
  try {
    return __dom_wrap(_this.upperBound(__dom_unwrap(bound), __dom_unwrap(open)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__get__keyPath(_this) {
  try {
    return __dom_wrap(_this.keyPath);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__add(_this, value) {
  try {
    return __dom_wrap(_this.add(__dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__add_2(_this, value, key) {
  try {
    return __dom_wrap(_this.add(__dom_unwrap(value), __dom_unwrap(key)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__clear(_this) {
  try {
    return __dom_wrap(_this.clear());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__createIndex(_this, name, keyPath) {
  try {
    return __dom_wrap(_this.createIndex(__dom_unwrap(name), __dom_unwrap(keyPath)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__delete(_this, key) {
  try {
    return __dom_wrap(_this.delete(__dom_unwrap(key)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__deleteIndex(_this, name) {
  try {
    return __dom_wrap(_this.deleteIndex(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__index(_this, name) {
  try {
    return __dom_wrap(_this.index(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__openCursor(_this) {
  try {
    return __dom_wrap(_this.openCursor());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__openCursor_2(_this, range) {
  try {
    return __dom_wrap(_this.openCursor(__dom_unwrap(range)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__openCursor_3(_this, range, direction) {
  try {
    return __dom_wrap(_this.openCursor(__dom_unwrap(range), __dom_unwrap(direction)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__put(_this, value) {
  try {
    return __dom_wrap(_this.put(__dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBObjectStoreWrappingImplementation__put_2(_this, value, key) {
  try {
    return __dom_wrap(_this.put(__dom_unwrap(value), __dom_unwrap(key)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__get__errorCode(_this) {
  try {
    return __dom_wrap(_this.errorCode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__get__onsuccess(_this) {
  try {
    return __dom_wrap(_this.onsuccess);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__set__onsuccess(_this, value) {
  try {
    _this.onsuccess = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__get__result(_this) {
  try {
    return __dom_wrap(_this.result);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__get__source(_this) {
  try {
    return __dom_wrap(_this.source);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__get__transaction(_this) {
  try {
    return __dom_wrap(_this.transaction);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__get__webkitErrorMessage(_this) {
  try {
    return __dom_wrap(_this.webkitErrorMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBRequestWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__get__db(_this) {
  try {
    return __dom_wrap(_this.db);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__get__mode(_this) {
  try {
    return __dom_wrap(_this.mode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__get__oncomplete(_this) {
  try {
    return __dom_wrap(_this.oncomplete);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__set__oncomplete(_this, value) {
  try {
    _this.oncomplete = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__abort(_this) {
  try {
    return __dom_wrap(_this.abort());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__objectStore(_this, name) {
  try {
    return __dom_wrap(_this.objectStore(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBTransactionWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBVersionChangeEventWrappingImplementation__get__version(_this) {
  try {
    return __dom_wrap(_this.version);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBVersionChangeRequestWrappingImplementation__get__onblocked(_this) {
  try {
    return __dom_wrap(_this.onblocked);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__IDBVersionChangeRequestWrappingImplementation__set__onblocked(_this, value) {
  try {
    _this.onblocked = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ImageDataWrappingImplementation__get__data(_this) {
  try {
    return __dom_wrap(_this.data);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ImageDataWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ImageDataWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__clearConsoleMessages(_this) {
  try {
    return __dom_wrap(_this.clearConsoleMessages());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__copyText(_this, text) {
  try {
    return __dom_wrap(_this.copyText(__dom_unwrap(text)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__databaseId(_this, database) {
  try {
    return __dom_wrap(_this.databaseId(__dom_unwrap(database)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__evaluate(_this, text) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(text)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__inspect(_this, objectId, hints) {
  try {
    return __dom_wrap(_this.inspect(__dom_unwrap(objectId), __dom_unwrap(hints)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__inspectedNode(_this, num) {
  try {
    return __dom_wrap(_this.inspectedNode(__dom_unwrap(num)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__internalConstructorName(_this, object) {
  try {
    return __dom_wrap(_this.internalConstructorName(__dom_unwrap(object)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__isHTMLAllCollection(_this, object) {
  try {
    return __dom_wrap(_this.isHTMLAllCollection(__dom_unwrap(object)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__storageId(_this, storage) {
  try {
    return __dom_wrap(_this.storageId(__dom_unwrap(storage)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InjectedScriptHostWrappingImplementation__type(_this, object) {
  try {
    return __dom_wrap(_this.type(__dom_unwrap(object)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__bringToFront(_this) {
  try {
    return __dom_wrap(_this.bringToFront());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__closeWindow(_this) {
  try {
    return __dom_wrap(_this.closeWindow());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__copyText(_this, text) {
  try {
    return __dom_wrap(_this.copyText(__dom_unwrap(text)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__disconnectFromBackend(_this) {
  try {
    return __dom_wrap(_this.disconnectFromBackend());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__hiddenPanels(_this) {
  try {
    return __dom_wrap(_this.hiddenPanels());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__inspectedURLChanged(_this, newURL) {
  try {
    return __dom_wrap(_this.inspectedURLChanged(__dom_unwrap(newURL)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__loaded(_this) {
  try {
    return __dom_wrap(_this.loaded());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__localizedStringsURL(_this) {
  try {
    return __dom_wrap(_this.localizedStringsURL());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__moveWindowBy(_this, x, y) {
  try {
    return __dom_wrap(_this.moveWindowBy(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__platform(_this) {
  try {
    return __dom_wrap(_this.platform());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__port(_this) {
  try {
    return __dom_wrap(_this.port());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__recordActionTaken(_this, actionCode) {
  try {
    return __dom_wrap(_this.recordActionTaken(__dom_unwrap(actionCode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__recordPanelShown(_this, panelCode) {
  try {
    return __dom_wrap(_this.recordPanelShown(__dom_unwrap(panelCode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__recordSettingChanged(_this, settingChanged) {
  try {
    return __dom_wrap(_this.recordSettingChanged(__dom_unwrap(settingChanged)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__requestAttachWindow(_this) {
  try {
    return __dom_wrap(_this.requestAttachWindow());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__requestDetachWindow(_this) {
  try {
    return __dom_wrap(_this.requestDetachWindow());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__saveAs(_this, fileName, content) {
  try {
    return __dom_wrap(_this.saveAs(__dom_unwrap(fileName), __dom_unwrap(content)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__sendMessageToBackend(_this, message) {
  try {
    return __dom_wrap(_this.sendMessageToBackend(__dom_unwrap(message)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__setAttachedWindowHeight(_this, height) {
  try {
    return __dom_wrap(_this.setAttachedWindowHeight(__dom_unwrap(height)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__setExtensionAPI(_this, script) {
  try {
    return __dom_wrap(_this.setExtensionAPI(__dom_unwrap(script)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__InspectorFrontendHostWrappingImplementation__showContextMenu(_this, event, items) {
  try {
    return __dom_wrap(_this.showContextMenu(__dom_unwrap(event), __dom_unwrap(items)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int16ArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int16ArrayWrappingImplementation__subarray(_this) {
  try {
    return __dom_wrap(_this.subarray());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int16ArrayWrappingImplementation__subarray_2(_this, start) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int16ArrayWrappingImplementation__subarray_3(_this, start, end) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int32ArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int32ArrayWrappingImplementation__subarray(_this) {
  try {
    return __dom_wrap(_this.subarray());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int32ArrayWrappingImplementation__subarray_2(_this, start) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int32ArrayWrappingImplementation__subarray_3(_this, start, end) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int8ArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int8ArrayWrappingImplementation__subarray(_this) {
  try {
    return __dom_wrap(_this.subarray());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int8ArrayWrappingImplementation__subarray_2(_this, start) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Int8ArrayWrappingImplementation__subarray_3(_this, start, end) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__JavaScriptCallFrameWrappingImplementation__get__caller(_this) {
  try {
    return __dom_wrap(_this.caller);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__JavaScriptCallFrameWrappingImplementation__get__column(_this) {
  try {
    return __dom_wrap(_this.column);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__JavaScriptCallFrameWrappingImplementation__get__functionName(_this) {
  try {
    return __dom_wrap(_this.functionName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__JavaScriptCallFrameWrappingImplementation__get__line(_this) {
  try {
    return __dom_wrap(_this.line);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__JavaScriptCallFrameWrappingImplementation__get__sourceID(_this) {
  try {
    return __dom_wrap(_this.sourceID);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__JavaScriptCallFrameWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__JavaScriptCallFrameWrappingImplementation__evaluate(_this, script) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(script)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__JavaScriptCallFrameWrappingImplementation__scopeType(_this, scopeIndex) {
  try {
    return __dom_wrap(_this.scopeType(__dom_unwrap(scopeIndex)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__get__altGraphKey(_this) {
  try {
    return __dom_wrap(_this.altGraphKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__get__altKey(_this) {
  try {
    return __dom_wrap(_this.altKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__get__ctrlKey(_this) {
  try {
    return __dom_wrap(_this.ctrlKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__get__keyIdentifier(_this) {
  try {
    return __dom_wrap(_this.keyIdentifier);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__get__keyLocation(_this) {
  try {
    return __dom_wrap(_this.keyLocation);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__get__metaKey(_this) {
  try {
    return __dom_wrap(_this.metaKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__get__shiftKey(_this) {
  try {
    return __dom_wrap(_this.shiftKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__getModifierState(_this) {
  try {
    return __dom_wrap(_this.getModifierState());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__getModifierState_2(_this, keyIdentifierArg) {
  try {
    return __dom_wrap(_this.getModifierState(__dom_unwrap(keyIdentifierArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent(_this) {
  try {
    return __dom_wrap(_this.initKeyboardEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_3(_this, type, canBubble) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_4(_this, type, canBubble, cancelable) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_5(_this, type, canBubble, cancelable, view) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_6(_this, type, canBubble, cancelable, view, keyIdentifier) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(keyIdentifier)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_7(_this, type, canBubble, cancelable, view, keyIdentifier, keyLocation) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(keyIdentifier), __dom_unwrap(keyLocation)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_8(_this, type, canBubble, cancelable, view, keyIdentifier, keyLocation, ctrlKey) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(keyIdentifier), __dom_unwrap(keyLocation), __dom_unwrap(ctrlKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_9(_this, type, canBubble, cancelable, view, keyIdentifier, keyLocation, ctrlKey, altKey) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(keyIdentifier), __dom_unwrap(keyLocation), __dom_unwrap(ctrlKey), __dom_unwrap(altKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_10(_this, type, canBubble, cancelable, view, keyIdentifier, keyLocation, ctrlKey, altKey, shiftKey) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(keyIdentifier), __dom_unwrap(keyLocation), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_11(_this, type, canBubble, cancelable, view, keyIdentifier, keyLocation, ctrlKey, altKey, shiftKey, metaKey) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(keyIdentifier), __dom_unwrap(keyLocation), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey), __dom_unwrap(metaKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__KeyboardEventWrappingImplementation__initKeyboardEvent_12(_this, type, canBubble, cancelable, view, keyIdentifier, keyLocation, ctrlKey, altKey, shiftKey, metaKey, altGraphKey) {
  try {
    return __dom_wrap(_this.initKeyboardEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(keyIdentifier), __dom_unwrap(keyLocation), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey), __dom_unwrap(metaKey), __dom_unwrap(altGraphKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocalMediaStreamWrappingImplementation__stop(_this) {
  try {
    return __dom_wrap(_this.stop());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__hash(_this) {
  try {
    return __dom_wrap(_this.hash);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__set__hash(_this, value) {
  try {
    _this.hash = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__host(_this) {
  try {
    return __dom_wrap(_this.host);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__set__host(_this, value) {
  try {
    _this.host = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__hostname(_this) {
  try {
    return __dom_wrap(_this.hostname);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__set__hostname(_this, value) {
  try {
    _this.hostname = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__href(_this) {
  try {
    return __dom_wrap(_this.href);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__set__href(_this, value) {
  try {
    _this.href = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__origin(_this) {
  try {
    return __dom_wrap(_this.origin);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__pathname(_this) {
  try {
    return __dom_wrap(_this.pathname);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__set__pathname(_this, value) {
  try {
    _this.pathname = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__port(_this) {
  try {
    return __dom_wrap(_this.port);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__set__port(_this, value) {
  try {
    _this.port = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__protocol(_this) {
  try {
    return __dom_wrap(_this.protocol);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__set__protocol(_this, value) {
  try {
    _this.protocol = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__get__search(_this) {
  try {
    return __dom_wrap(_this.search);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__set__search(_this, value) {
  try {
    _this.search = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__assign(_this) {
  try {
    return __dom_wrap(_this.assign());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__assign_2(_this, url) {
  try {
    return __dom_wrap(_this.assign(__dom_unwrap(url)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__getParameter(_this, name) {
  try {
    return __dom_wrap(_this.getParameter(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__reload(_this) {
  try {
    return __dom_wrap(_this.reload());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__replace(_this) {
  try {
    return __dom_wrap(_this.replace());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__LocationWrappingImplementation__replace_2(_this, url) {
  try {
    return __dom_wrap(_this.replace(__dom_unwrap(url)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaErrorWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__get__mediaText(_this) {
  try {
    return __dom_wrap(_this.mediaText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__set__mediaText(_this, value) {
  try {
    _this.mediaText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__appendMedium(_this) {
  try {
    return __dom_wrap(_this.appendMedium());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__appendMedium_2(_this, newMedium) {
  try {
    return __dom_wrap(_this.appendMedium(__dom_unwrap(newMedium)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__deleteMedium(_this) {
  try {
    return __dom_wrap(_this.deleteMedium());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__deleteMedium_2(_this, oldMedium) {
  try {
    return __dom_wrap(_this.deleteMedium(__dom_unwrap(oldMedium)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaListWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaQueryListWrappingImplementation__get__matches(_this) {
  try {
    return __dom_wrap(_this.matches);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaQueryListWrappingImplementation__get__media(_this) {
  try {
    return __dom_wrap(_this.media);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaQueryListWrappingImplementation__addListener(_this) {
  try {
    return __dom_wrap(_this.addListener());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaQueryListWrappingImplementation__addListener_2(_this, listener) {
  try {
    return __dom_wrap(_this.addListener(__dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaQueryListWrappingImplementation__removeListener(_this) {
  try {
    return __dom_wrap(_this.removeListener());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaQueryListWrappingImplementation__removeListener_2(_this, listener) {
  try {
    return __dom_wrap(_this.removeListener(__dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaQueryListListenerWrappingImplementation__queryChanged(_this) {
  try {
    return __dom_wrap(_this.queryChanged());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaQueryListListenerWrappingImplementation__queryChanged_2(_this, list) {
  try {
    return __dom_wrap(_this.queryChanged(__dom_unwrap(list)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__get__label(_this) {
  try {
    return __dom_wrap(_this.label);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__get__onended(_this) {
  try {
    return __dom_wrap(_this.onended);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__set__onended(_this, value) {
  try {
    _this.onended = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__get__tracks(_this) {
  try {
    return __dom_wrap(_this.tracks);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__dispatchEvent(_this, event) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(event)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamListWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamTrackWrappingImplementation__get__enabled(_this) {
  try {
    return __dom_wrap(_this.enabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamTrackWrappingImplementation__set__enabled(_this, value) {
  try {
    _this.enabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamTrackWrappingImplementation__get__kind(_this) {
  try {
    return __dom_wrap(_this.kind);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamTrackWrappingImplementation__get__label(_this) {
  try {
    return __dom_wrap(_this.label);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamTrackListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MediaStreamTrackListWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MemoryInfoWrappingImplementation__get__jsHeapSizeLimit(_this) {
  try {
    return __dom_wrap(_this.jsHeapSizeLimit);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MemoryInfoWrappingImplementation__get__totalJSHeapSize(_this) {
  try {
    return __dom_wrap(_this.totalJSHeapSize);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MemoryInfoWrappingImplementation__get__usedJSHeapSize(_this) {
  try {
    return __dom_wrap(_this.usedJSHeapSize);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageChannelWrappingImplementation__get__port1(_this) {
  try {
    return __dom_wrap(_this.port1);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageChannelWrappingImplementation__get__port2(_this) {
  try {
    return __dom_wrap(_this.port2);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__get__data(_this) {
  try {
    return __dom_wrap(_this.data);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__get__lastEventId(_this) {
  try {
    return __dom_wrap(_this.lastEventId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__get__messagePort(_this) {
  try {
    return __dom_wrap(_this.messagePort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__get__origin(_this) {
  try {
    return __dom_wrap(_this.origin);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__get__source(_this) {
  try {
    return __dom_wrap(_this.source);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent(_this) {
  try {
    return __dom_wrap(_this.initMessageEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initMessageEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initMessageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initMessageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent_5(_this, typeArg, canBubbleArg, cancelableArg, dataArg) {
  try {
    return __dom_wrap(_this.initMessageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(dataArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent_6(_this, typeArg, canBubbleArg, cancelableArg, dataArg, originArg) {
  try {
    return __dom_wrap(_this.initMessageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(dataArg), __dom_unwrap(originArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent_7(_this, typeArg, canBubbleArg, cancelableArg, dataArg, originArg, lastEventIdArg) {
  try {
    return __dom_wrap(_this.initMessageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(dataArg), __dom_unwrap(originArg), __dom_unwrap(lastEventIdArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent_8(_this, typeArg, canBubbleArg, cancelableArg, dataArg, originArg, lastEventIdArg, sourceArg) {
  try {
    return __dom_wrap(_this.initMessageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(dataArg), __dom_unwrap(originArg), __dom_unwrap(lastEventIdArg), __dom_unwrap(sourceArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MessageEventWrappingImplementation__initMessageEvent_9(_this, typeArg, canBubbleArg, cancelableArg, dataArg, originArg, lastEventIdArg, sourceArg, messagePort) {
  try {
    return __dom_wrap(_this.initMessageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(dataArg), __dom_unwrap(originArg), __dom_unwrap(lastEventIdArg), __dom_unwrap(sourceArg), __dom_unwrap(messagePort)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MetadataWrappingImplementation__get__modificationTime(_this) {
  try {
    return __dom_wrap(_this.modificationTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MetadataCallbackWrappingImplementation__handleEvent(_this, metadata) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(metadata)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__altKey(_this) {
  try {
    return __dom_wrap(_this.altKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__button(_this) {
  try {
    return __dom_wrap(_this.button);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__clientX(_this) {
  try {
    return __dom_wrap(_this.clientX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__clientY(_this) {
  try {
    return __dom_wrap(_this.clientY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__ctrlKey(_this) {
  try {
    return __dom_wrap(_this.ctrlKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__fromElement(_this) {
  try {
    return __dom_wrap(_this.fromElement);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__metaKey(_this) {
  try {
    return __dom_wrap(_this.metaKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__offsetX(_this) {
  try {
    return __dom_wrap(_this.offsetX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__offsetY(_this) {
  try {
    return __dom_wrap(_this.offsetY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__relatedTarget(_this) {
  try {
    return __dom_wrap(_this.relatedTarget);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__screenX(_this) {
  try {
    return __dom_wrap(_this.screenX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__screenY(_this) {
  try {
    return __dom_wrap(_this.screenY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__shiftKey(_this) {
  try {
    return __dom_wrap(_this.shiftKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__toElement(_this) {
  try {
    return __dom_wrap(_this.toElement);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__x(_this) {
  try {
    return __dom_wrap(_this.x);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__get__y(_this) {
  try {
    return __dom_wrap(_this.y);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent(_this) {
  try {
    return __dom_wrap(_this.initMouseEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_3(_this, type, canBubble) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_4(_this, type, canBubble, cancelable) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_5(_this, type, canBubble, cancelable, view) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_6(_this, type, canBubble, cancelable, view, detail) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_7(_this, type, canBubble, cancelable, view, detail, screenX) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_8(_this, type, canBubble, cancelable, view, detail, screenX, screenY) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_9(_this, type, canBubble, cancelable, view, detail, screenX, screenY, clientX) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_10(_this, type, canBubble, cancelable, view, detail, screenX, screenY, clientX, clientY) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_11(_this, type, canBubble, cancelable, view, detail, screenX, screenY, clientX, clientY, ctrlKey) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_12(_this, type, canBubble, cancelable, view, detail, screenX, screenY, clientX, clientY, ctrlKey, altKey) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_13(_this, type, canBubble, cancelable, view, detail, screenX, screenY, clientX, clientY, ctrlKey, altKey, shiftKey) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_14(_this, type, canBubble, cancelable, view, detail, screenX, screenY, clientX, clientY, ctrlKey, altKey, shiftKey, metaKey) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey), __dom_unwrap(metaKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_15(_this, type, canBubble, cancelable, view, detail, screenX, screenY, clientX, clientY, ctrlKey, altKey, shiftKey, metaKey, button) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey), __dom_unwrap(metaKey), __dom_unwrap(button)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MouseEventWrappingImplementation__initMouseEvent_16(_this, type, canBubble, cancelable, view, detail, screenX, screenY, clientX, clientY, ctrlKey, altKey, shiftKey, metaKey, button, relatedTarget) {
  try {
    return __dom_wrap(_this.initMouseEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey), __dom_unwrap(metaKey), __dom_unwrap(button), __dom_unwrap(relatedTarget)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__get__attrChange(_this) {
  try {
    return __dom_wrap(_this.attrChange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__get__attrName(_this) {
  try {
    return __dom_wrap(_this.attrName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__get__newValue(_this) {
  try {
    return __dom_wrap(_this.newValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__get__prevValue(_this) {
  try {
    return __dom_wrap(_this.prevValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__get__relatedNode(_this) {
  try {
    return __dom_wrap(_this.relatedNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent(_this) {
  try {
    return __dom_wrap(_this.initMutationEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initMutationEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent_3(_this, type, canBubble) {
  try {
    return __dom_wrap(_this.initMutationEvent(__dom_unwrap(type), __dom_unwrap(canBubble)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent_4(_this, type, canBubble, cancelable) {
  try {
    return __dom_wrap(_this.initMutationEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent_5(_this, type, canBubble, cancelable, relatedNode) {
  try {
    return __dom_wrap(_this.initMutationEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(relatedNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent_6(_this, type, canBubble, cancelable, relatedNode, prevValue) {
  try {
    return __dom_wrap(_this.initMutationEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(relatedNode), __dom_unwrap(prevValue)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent_7(_this, type, canBubble, cancelable, relatedNode, prevValue, newValue) {
  try {
    return __dom_wrap(_this.initMutationEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(relatedNode), __dom_unwrap(prevValue), __dom_unwrap(newValue)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent_8(_this, type, canBubble, cancelable, relatedNode, prevValue, newValue, attrName) {
  try {
    return __dom_wrap(_this.initMutationEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(relatedNode), __dom_unwrap(prevValue), __dom_unwrap(newValue), __dom_unwrap(attrName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__MutationEventWrappingImplementation__initMutationEvent_9(_this, type, canBubble, cancelable, relatedNode, prevValue, newValue, attrName, attrChange) {
  try {
    return __dom_wrap(_this.initMutationEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(relatedNode), __dom_unwrap(prevValue), __dom_unwrap(newValue), __dom_unwrap(attrName), __dom_unwrap(attrChange)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__getNamedItem(_this) {
  try {
    return __dom_wrap(_this.getNamedItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__getNamedItem_2(_this, name) {
  try {
    return __dom_wrap(_this.getNamedItem(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__getNamedItemNS(_this) {
  try {
    return __dom_wrap(_this.getNamedItemNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__getNamedItemNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.getNamedItemNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__getNamedItemNS_3(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.getNamedItemNS(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__removeNamedItem(_this) {
  try {
    return __dom_wrap(_this.removeNamedItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__removeNamedItem_2(_this, name) {
  try {
    return __dom_wrap(_this.removeNamedItem(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__removeNamedItemNS(_this) {
  try {
    return __dom_wrap(_this.removeNamedItemNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__removeNamedItemNS_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.removeNamedItemNS(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__removeNamedItemNS_3(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.removeNamedItemNS(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__setNamedItem(_this) {
  try {
    return __dom_wrap(_this.setNamedItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__setNamedItem_2(_this, node) {
  try {
    return __dom_wrap(_this.setNamedItem(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__setNamedItemNS(_this) {
  try {
    return __dom_wrap(_this.setNamedItemNS());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NamedNodeMapWrappingImplementation__setNamedItemNS_2(_this, node) {
  try {
    return __dom_wrap(_this.setNamedItemNS(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__appCodeName(_this) {
  try {
    return __dom_wrap(_this.appCodeName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__appName(_this) {
  try {
    return __dom_wrap(_this.appName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__appVersion(_this) {
  try {
    return __dom_wrap(_this.appVersion);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__cookieEnabled(_this) {
  try {
    return __dom_wrap(_this.cookieEnabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__language(_this) {
  try {
    return __dom_wrap(_this.language);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__mimeTypes(_this) {
  try {
    return __dom_wrap(_this.mimeTypes);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__onLine(_this) {
  try {
    return __dom_wrap(_this.onLine);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__platform(_this) {
  try {
    return __dom_wrap(_this.platform);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__plugins(_this) {
  try {
    return __dom_wrap(_this.plugins);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__product(_this) {
  try {
    return __dom_wrap(_this.product);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__productSub(_this) {
  try {
    return __dom_wrap(_this.productSub);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__userAgent(_this) {
  try {
    return __dom_wrap(_this.userAgent);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__vendor(_this) {
  try {
    return __dom_wrap(_this.vendor);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__get__vendorSub(_this) {
  try {
    return __dom_wrap(_this.vendorSub);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__getStorageUpdates(_this) {
  try {
    return __dom_wrap(_this.getStorageUpdates());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorWrappingImplementation__javaEnabled(_this) {
  try {
    return __dom_wrap(_this.javaEnabled());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorUserMediaErrorWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorUserMediaErrorCallbackWrappingImplementation__handleEvent(_this, error) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NavigatorUserMediaSuccessCallbackWrappingImplementation__handleEvent(_this, stream) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(stream)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__attributes(_this) {
  try {
    return __dom_wrap(_this.attributes);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__baseURI(_this) {
  try {
    return __dom_wrap(_this.baseURI);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__childNodes(_this) {
  try {
    return __dom_wrap(_this.childNodes);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__firstChild(_this) {
  try {
    return __dom_wrap(_this.firstChild);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__lastChild(_this) {
  try {
    return __dom_wrap(_this.lastChild);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__localName(_this) {
  try {
    return __dom_wrap(_this.localName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__namespaceURI(_this) {
  try {
    return __dom_wrap(_this.namespaceURI);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__nextSibling(_this) {
  try {
    return __dom_wrap(_this.nextSibling);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__nodeName(_this) {
  try {
    return __dom_wrap(_this.nodeName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__nodeType(_this) {
  try {
    return __dom_wrap(_this.nodeType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__nodeValue(_this) {
  try {
    return __dom_wrap(_this.nodeValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__set__nodeValue(_this, value) {
  try {
    _this.nodeValue = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__ownerDocument(_this) {
  try {
    return __dom_wrap(_this.ownerDocument);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__parentElement(_this) {
  try {
    return __dom_wrap(_this.parentElement);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__parentNode(_this) {
  try {
    return __dom_wrap(_this.parentNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__prefix(_this) {
  try {
    return __dom_wrap(_this.prefix);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__set__prefix(_this, value) {
  try {
    _this.prefix = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__previousSibling(_this) {
  try {
    return __dom_wrap(_this.previousSibling);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__get__textContent(_this) {
  try {
    return __dom_wrap(_this.textContent);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__set__textContent(_this, value) {
  try {
    _this.textContent = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__appendChild(_this, newChild) {
  try {
    return __dom_wrap(_this.appendChild(__dom_unwrap(newChild)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__cloneNode(_this) {
  try {
    return __dom_wrap(_this.cloneNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__cloneNode_2(_this, deep) {
  try {
    return __dom_wrap(_this.cloneNode(__dom_unwrap(deep)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__compareDocumentPosition(_this) {
  try {
    return __dom_wrap(_this.compareDocumentPosition());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__compareDocumentPosition_2(_this, other) {
  try {
    return __dom_wrap(_this.compareDocumentPosition(__dom_unwrap(other)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__dispatchEvent(_this, event) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(event)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__hasAttributes(_this) {
  try {
    return __dom_wrap(_this.hasAttributes());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__hasChildNodes(_this) {
  try {
    return __dom_wrap(_this.hasChildNodes());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__insertBefore(_this, newChild, refChild) {
  try {
    return __dom_wrap(_this.insertBefore(__dom_unwrap(newChild), __dom_unwrap(refChild)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isDefaultNamespace(_this) {
  try {
    return __dom_wrap(_this.isDefaultNamespace());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isDefaultNamespace_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.isDefaultNamespace(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isEqualNode(_this) {
  try {
    return __dom_wrap(_this.isEqualNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isEqualNode_2(_this, other) {
  try {
    return __dom_wrap(_this.isEqualNode(__dom_unwrap(other)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isSameNode(_this) {
  try {
    return __dom_wrap(_this.isSameNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isSameNode_2(_this, other) {
  try {
    return __dom_wrap(_this.isSameNode(__dom_unwrap(other)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isSupported(_this) {
  try {
    return __dom_wrap(_this.isSupported());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isSupported_2(_this, feature) {
  try {
    return __dom_wrap(_this.isSupported(__dom_unwrap(feature)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__isSupported_3(_this, feature, version) {
  try {
    return __dom_wrap(_this.isSupported(__dom_unwrap(feature), __dom_unwrap(version)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__lookupNamespaceURI(_this) {
  try {
    return __dom_wrap(_this.lookupNamespaceURI());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__lookupNamespaceURI_2(_this, prefix) {
  try {
    return __dom_wrap(_this.lookupNamespaceURI(__dom_unwrap(prefix)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__lookupPrefix(_this) {
  try {
    return __dom_wrap(_this.lookupPrefix());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__lookupPrefix_2(_this, namespaceURI) {
  try {
    return __dom_wrap(_this.lookupPrefix(__dom_unwrap(namespaceURI)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__normalize(_this) {
  try {
    return __dom_wrap(_this.normalize());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__removeChild(_this, oldChild) {
  try {
    return __dom_wrap(_this.removeChild(__dom_unwrap(oldChild)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeWrappingImplementation__replaceChild(_this, newChild, oldChild) {
  try {
    return __dom_wrap(_this.replaceChild(__dom_unwrap(newChild), __dom_unwrap(oldChild)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeFilterWrappingImplementation__acceptNode(_this) {
  try {
    return __dom_wrap(_this.acceptNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeFilterWrappingImplementation__acceptNode_2(_this, n) {
  try {
    return __dom_wrap(_this.acceptNode(__dom_unwrap(n)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__get__expandEntityReferences(_this) {
  try {
    return __dom_wrap(_this.expandEntityReferences);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__get__filter(_this) {
  try {
    return __dom_wrap(_this.filter);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__get__pointerBeforeReferenceNode(_this) {
  try {
    return __dom_wrap(_this.pointerBeforeReferenceNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__get__referenceNode(_this) {
  try {
    return __dom_wrap(_this.referenceNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__get__root(_this) {
  try {
    return __dom_wrap(_this.root);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__get__whatToShow(_this) {
  try {
    return __dom_wrap(_this.whatToShow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__detach(_this) {
  try {
    return __dom_wrap(_this.detach());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__nextNode(_this) {
  try {
    return __dom_wrap(_this.nextNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeIteratorWrappingImplementation__previousNode(_this) {
  try {
    return __dom_wrap(_this.previousNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeListWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NodeListWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotationWrappingImplementation__get__publicId(_this) {
  try {
    return __dom_wrap(_this.publicId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotationWrappingImplementation__get__systemId(_this) {
  try {
    return __dom_wrap(_this.systemId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__get__dir(_this) {
  try {
    return __dom_wrap(_this.dir);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__set__dir(_this, value) {
  try {
    _this.dir = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__get__onclick(_this) {
  try {
    return __dom_wrap(_this.onclick);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__set__onclick(_this, value) {
  try {
    _this.onclick = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__get__onclose(_this) {
  try {
    return __dom_wrap(_this.onclose);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__set__onclose(_this, value) {
  try {
    _this.onclose = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__get__ondisplay(_this) {
  try {
    return __dom_wrap(_this.ondisplay);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__set__ondisplay(_this, value) {
  try {
    _this.ondisplay = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__get__replaceId(_this) {
  try {
    return __dom_wrap(_this.replaceId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__set__replaceId(_this, value) {
  try {
    _this.replaceId = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__cancel(_this) {
  try {
    return __dom_wrap(_this.cancel());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationWrappingImplementation__show(_this) {
  try {
    return __dom_wrap(_this.show());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationCenterWrappingImplementation__checkPermission(_this) {
  try {
    return __dom_wrap(_this.checkPermission());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationCenterWrappingImplementation__createHTMLNotification(_this, url) {
  try {
    return __dom_wrap(_this.createHTMLNotification(__dom_unwrap(url)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationCenterWrappingImplementation__createNotification(_this, iconUrl, title, body) {
  try {
    return __dom_wrap(_this.createNotification(__dom_unwrap(iconUrl), __dom_unwrap(title), __dom_unwrap(body)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__NotificationCenterWrappingImplementation__requestPermission(_this, callback) {
  try {
    return __dom_wrap(_this.requestPermission(__dom_unwrap(callback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OESVertexArrayObjectWrappingImplementation__bindVertexArrayOES(_this) {
  try {
    return __dom_wrap(_this.bindVertexArrayOES());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OESVertexArrayObjectWrappingImplementation__bindVertexArrayOES_2(_this, arrayObject) {
  try {
    return __dom_wrap(_this.bindVertexArrayOES(__dom_unwrap(arrayObject)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OESVertexArrayObjectWrappingImplementation__createVertexArrayOES(_this) {
  try {
    return __dom_wrap(_this.createVertexArrayOES());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OESVertexArrayObjectWrappingImplementation__deleteVertexArrayOES(_this) {
  try {
    return __dom_wrap(_this.deleteVertexArrayOES());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OESVertexArrayObjectWrappingImplementation__deleteVertexArrayOES_2(_this, arrayObject) {
  try {
    return __dom_wrap(_this.deleteVertexArrayOES(__dom_unwrap(arrayObject)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OESVertexArrayObjectWrappingImplementation__isVertexArrayOES(_this) {
  try {
    return __dom_wrap(_this.isVertexArrayOES());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OESVertexArrayObjectWrappingImplementation__isVertexArrayOES_2(_this, arrayObject) {
  try {
    return __dom_wrap(_this.isVertexArrayOES(__dom_unwrap(arrayObject)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OperationNotAllowedExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OperationNotAllowedExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OperationNotAllowedExceptionWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OverflowEventWrappingImplementation__get__horizontalOverflow(_this) {
  try {
    return __dom_wrap(_this.horizontalOverflow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OverflowEventWrappingImplementation__get__orient(_this) {
  try {
    return __dom_wrap(_this.orient);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OverflowEventWrappingImplementation__get__verticalOverflow(_this) {
  try {
    return __dom_wrap(_this.verticalOverflow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OverflowEventWrappingImplementation__initOverflowEvent(_this) {
  try {
    return __dom_wrap(_this.initOverflowEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OverflowEventWrappingImplementation__initOverflowEvent_2(_this, orient) {
  try {
    return __dom_wrap(_this.initOverflowEvent(__dom_unwrap(orient)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OverflowEventWrappingImplementation__initOverflowEvent_3(_this, orient, horizontalOverflow) {
  try {
    return __dom_wrap(_this.initOverflowEvent(__dom_unwrap(orient), __dom_unwrap(horizontalOverflow)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__OverflowEventWrappingImplementation__initOverflowEvent_4(_this, orient, horizontalOverflow, verticalOverflow) {
  try {
    return __dom_wrap(_this.initOverflowEvent(__dom_unwrap(orient), __dom_unwrap(horizontalOverflow), __dom_unwrap(verticalOverflow)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PageTransitionEventWrappingImplementation__get__persisted(_this) {
  try {
    return __dom_wrap(_this.persisted);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PageTransitionEventWrappingImplementation__initPageTransitionEvent(_this) {
  try {
    return __dom_wrap(_this.initPageTransitionEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PageTransitionEventWrappingImplementation__initPageTransitionEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initPageTransitionEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PageTransitionEventWrappingImplementation__initPageTransitionEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initPageTransitionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PageTransitionEventWrappingImplementation__initPageTransitionEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initPageTransitionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PageTransitionEventWrappingImplementation__initPageTransitionEvent_5(_this, typeArg, canBubbleArg, cancelableArg, persisted) {
  try {
    return __dom_wrap(_this.initPageTransitionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(persisted)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceWrappingImplementation__get__memory(_this) {
  try {
    return __dom_wrap(_this.memory);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceWrappingImplementation__get__navigation(_this) {
  try {
    return __dom_wrap(_this.navigation);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceWrappingImplementation__get__timing(_this) {
  try {
    return __dom_wrap(_this.timing);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceNavigationWrappingImplementation__get__redirectCount(_this) {
  try {
    return __dom_wrap(_this.redirectCount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceNavigationWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__connectEnd(_this) {
  try {
    return __dom_wrap(_this.connectEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__connectStart(_this) {
  try {
    return __dom_wrap(_this.connectStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__domComplete(_this) {
  try {
    return __dom_wrap(_this.domComplete);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__domContentLoadedEventEnd(_this) {
  try {
    return __dom_wrap(_this.domContentLoadedEventEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__domContentLoadedEventStart(_this) {
  try {
    return __dom_wrap(_this.domContentLoadedEventStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__domInteractive(_this) {
  try {
    return __dom_wrap(_this.domInteractive);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__domLoading(_this) {
  try {
    return __dom_wrap(_this.domLoading);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__domainLookupEnd(_this) {
  try {
    return __dom_wrap(_this.domainLookupEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__domainLookupStart(_this) {
  try {
    return __dom_wrap(_this.domainLookupStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__fetchStart(_this) {
  try {
    return __dom_wrap(_this.fetchStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__loadEventEnd(_this) {
  try {
    return __dom_wrap(_this.loadEventEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__loadEventStart(_this) {
  try {
    return __dom_wrap(_this.loadEventStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__navigationStart(_this) {
  try {
    return __dom_wrap(_this.navigationStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__redirectEnd(_this) {
  try {
    return __dom_wrap(_this.redirectEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__redirectStart(_this) {
  try {
    return __dom_wrap(_this.redirectStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__requestStart(_this) {
  try {
    return __dom_wrap(_this.requestStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__responseEnd(_this) {
  try {
    return __dom_wrap(_this.responseEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__responseStart(_this) {
  try {
    return __dom_wrap(_this.responseStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__secureConnectionStart(_this) {
  try {
    return __dom_wrap(_this.secureConnectionStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__unloadEventEnd(_this) {
  try {
    return __dom_wrap(_this.unloadEventEnd);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PerformanceTimingWrappingImplementation__get__unloadEventStart(_this) {
  try {
    return __dom_wrap(_this.unloadEventStart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PopStateEventWrappingImplementation__get__state(_this) {
  try {
    return __dom_wrap(_this.state);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PopStateEventWrappingImplementation__initPopStateEvent(_this) {
  try {
    return __dom_wrap(_this.initPopStateEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PopStateEventWrappingImplementation__initPopStateEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initPopStateEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PopStateEventWrappingImplementation__initPopStateEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initPopStateEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PopStateEventWrappingImplementation__initPopStateEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initPopStateEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PopStateEventWrappingImplementation__initPopStateEvent_5(_this, typeArg, canBubbleArg, cancelableArg, stateArg) {
  try {
    return __dom_wrap(_this.initPopStateEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(stateArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PositionCallbackWrappingImplementation__handleEvent(_this, position) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(position)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PositionErrorWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PositionErrorWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__PositionErrorCallbackWrappingImplementation__handleEvent(_this, error) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProcessingInstructionWrappingImplementation__get__data(_this) {
  try {
    return __dom_wrap(_this.data);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProcessingInstructionWrappingImplementation__set__data(_this, value) {
  try {
    _this.data = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProcessingInstructionWrappingImplementation__get__sheet(_this) {
  try {
    return __dom_wrap(_this.sheet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProcessingInstructionWrappingImplementation__get__target(_this) {
  try {
    return __dom_wrap(_this.target);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__get__lengthComputable(_this) {
  try {
    return __dom_wrap(_this.lengthComputable);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__get__loaded(_this) {
  try {
    return __dom_wrap(_this.loaded);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__get__total(_this) {
  try {
    return __dom_wrap(_this.total);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__initProgressEvent(_this) {
  try {
    return __dom_wrap(_this.initProgressEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__initProgressEvent_2(_this, type_OR_typeArg) {
  try {
    return __dom_wrap(_this.initProgressEvent(__dom_unwrap(type_OR_typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__initProgressEvent_3(_this, type_OR_typeArg, bubbles_OR_canBubbleArg) {
  try {
    return __dom_wrap(_this.initProgressEvent(__dom_unwrap(type_OR_typeArg), __dom_unwrap(bubbles_OR_canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__initProgressEvent_4(_this, type_OR_typeArg, bubbles_OR_canBubbleArg, cancelable_OR_cancelableArg) {
  try {
    return __dom_wrap(_this.initProgressEvent(__dom_unwrap(type_OR_typeArg), __dom_unwrap(bubbles_OR_canBubbleArg), __dom_unwrap(cancelable_OR_cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__initProgressEvent_5(_this, type_OR_typeArg, bubbles_OR_canBubbleArg, cancelable_OR_cancelableArg, lengthComputable_OR_lengthComputableArg) {
  try {
    return __dom_wrap(_this.initProgressEvent(__dom_unwrap(type_OR_typeArg), __dom_unwrap(bubbles_OR_canBubbleArg), __dom_unwrap(cancelable_OR_cancelableArg), __dom_unwrap(lengthComputable_OR_lengthComputableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__initProgressEvent_6(_this, type_OR_typeArg, bubbles_OR_canBubbleArg, cancelable_OR_cancelableArg, lengthComputable_OR_lengthComputableArg, loaded_OR_loadedArg) {
  try {
    return __dom_wrap(_this.initProgressEvent(__dom_unwrap(type_OR_typeArg), __dom_unwrap(bubbles_OR_canBubbleArg), __dom_unwrap(cancelable_OR_cancelableArg), __dom_unwrap(lengthComputable_OR_lengthComputableArg), __dom_unwrap(loaded_OR_loadedArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ProgressEventWrappingImplementation__initProgressEvent_7(_this, type_OR_typeArg, bubbles_OR_canBubbleArg, cancelable_OR_cancelableArg, lengthComputable_OR_lengthComputableArg, loaded_OR_loadedArg, total) {
  try {
    return __dom_wrap(_this.initProgressEvent(__dom_unwrap(type_OR_typeArg), __dom_unwrap(bubbles_OR_canBubbleArg), __dom_unwrap(cancelable_OR_cancelableArg), __dom_unwrap(lengthComputable_OR_lengthComputableArg), __dom_unwrap(loaded_OR_loadedArg), __dom_unwrap(total)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RGBColorWrappingImplementation__get__alpha(_this) {
  try {
    return __dom_wrap(_this.alpha);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RGBColorWrappingImplementation__get__blue(_this) {
  try {
    return __dom_wrap(_this.blue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RGBColorWrappingImplementation__get__green(_this) {
  try {
    return __dom_wrap(_this.green);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RGBColorWrappingImplementation__get__red(_this) {
  try {
    return __dom_wrap(_this.red);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__get__collapsed(_this) {
  try {
    return __dom_wrap(_this.collapsed);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__get__commonAncestorContainer(_this) {
  try {
    return __dom_wrap(_this.commonAncestorContainer);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__get__endContainer(_this) {
  try {
    return __dom_wrap(_this.endContainer);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__get__endOffset(_this) {
  try {
    return __dom_wrap(_this.endOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__get__startContainer(_this) {
  try {
    return __dom_wrap(_this.startContainer);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__get__startOffset(_this) {
  try {
    return __dom_wrap(_this.startOffset);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__get__text(_this) {
  try {
    return __dom_wrap(_this.text);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__cloneContents(_this) {
  try {
    return __dom_wrap(_this.cloneContents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__cloneRange(_this) {
  try {
    return __dom_wrap(_this.cloneRange());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__collapse(_this) {
  try {
    return __dom_wrap(_this.collapse());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__collapse_2(_this, toStart) {
  try {
    return __dom_wrap(_this.collapse(__dom_unwrap(toStart)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__compareBoundaryPoints(_this) {
  try {
    return __dom_wrap(_this.compareBoundaryPoints());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__compareNode(_this) {
  try {
    return __dom_wrap(_this.compareNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__compareNode_2(_this, refNode) {
  try {
    return __dom_wrap(_this.compareNode(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__comparePoint(_this) {
  try {
    return __dom_wrap(_this.comparePoint());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__comparePoint_2(_this, refNode) {
  try {
    return __dom_wrap(_this.comparePoint(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__comparePoint_3(_this, refNode, offset) {
  try {
    return __dom_wrap(_this.comparePoint(__dom_unwrap(refNode), __dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__createContextualFragment(_this) {
  try {
    return __dom_wrap(_this.createContextualFragment());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__createContextualFragment_2(_this, html) {
  try {
    return __dom_wrap(_this.createContextualFragment(__dom_unwrap(html)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__deleteContents(_this) {
  try {
    return __dom_wrap(_this.deleteContents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__detach(_this) {
  try {
    return __dom_wrap(_this.detach());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__expand(_this) {
  try {
    return __dom_wrap(_this.expand());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__expand_2(_this, unit) {
  try {
    return __dom_wrap(_this.expand(__dom_unwrap(unit)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__extractContents(_this) {
  try {
    return __dom_wrap(_this.extractContents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__insertNode(_this) {
  try {
    return __dom_wrap(_this.insertNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__insertNode_2(_this, newNode) {
  try {
    return __dom_wrap(_this.insertNode(__dom_unwrap(newNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__intersectsNode(_this) {
  try {
    return __dom_wrap(_this.intersectsNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__intersectsNode_2(_this, refNode) {
  try {
    return __dom_wrap(_this.intersectsNode(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__isPointInRange(_this) {
  try {
    return __dom_wrap(_this.isPointInRange());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__isPointInRange_2(_this, refNode) {
  try {
    return __dom_wrap(_this.isPointInRange(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__isPointInRange_3(_this, refNode, offset) {
  try {
    return __dom_wrap(_this.isPointInRange(__dom_unwrap(refNode), __dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__selectNode(_this) {
  try {
    return __dom_wrap(_this.selectNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__selectNode_2(_this, refNode) {
  try {
    return __dom_wrap(_this.selectNode(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__selectNodeContents(_this) {
  try {
    return __dom_wrap(_this.selectNodeContents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__selectNodeContents_2(_this, refNode) {
  try {
    return __dom_wrap(_this.selectNodeContents(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setEnd(_this) {
  try {
    return __dom_wrap(_this.setEnd());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setEnd_2(_this, refNode) {
  try {
    return __dom_wrap(_this.setEnd(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setEnd_3(_this, refNode, offset) {
  try {
    return __dom_wrap(_this.setEnd(__dom_unwrap(refNode), __dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setEndAfter(_this) {
  try {
    return __dom_wrap(_this.setEndAfter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setEndAfter_2(_this, refNode) {
  try {
    return __dom_wrap(_this.setEndAfter(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setEndBefore(_this) {
  try {
    return __dom_wrap(_this.setEndBefore());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setEndBefore_2(_this, refNode) {
  try {
    return __dom_wrap(_this.setEndBefore(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setStart(_this) {
  try {
    return __dom_wrap(_this.setStart());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setStart_2(_this, refNode) {
  try {
    return __dom_wrap(_this.setStart(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setStart_3(_this, refNode, offset) {
  try {
    return __dom_wrap(_this.setStart(__dom_unwrap(refNode), __dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setStartAfter(_this) {
  try {
    return __dom_wrap(_this.setStartAfter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setStartAfter_2(_this, refNode) {
  try {
    return __dom_wrap(_this.setStartAfter(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setStartBefore(_this) {
  try {
    return __dom_wrap(_this.setStartBefore());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__setStartBefore_2(_this, refNode) {
  try {
    return __dom_wrap(_this.setStartBefore(__dom_unwrap(refNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__surroundContents(_this) {
  try {
    return __dom_wrap(_this.surroundContents());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__surroundContents_2(_this, newParent) {
  try {
    return __dom_wrap(_this.surroundContents(__dom_unwrap(newParent)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeWrappingImplementation__toString(_this) {
  try {
    return __dom_wrap(_this.toString());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RangeExceptionWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RectWrappingImplementation__get__bottom(_this) {
  try {
    return __dom_wrap(_this.bottom);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RectWrappingImplementation__get__left(_this) {
  try {
    return __dom_wrap(_this.left);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RectWrappingImplementation__get__right(_this) {
  try {
    return __dom_wrap(_this.right);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RectWrappingImplementation__get__top(_this) {
  try {
    return __dom_wrap(_this.top);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__RequestAnimationFrameCallbackWrappingImplementation__handleEvent(_this, time) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(time)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLErrorWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLErrorWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLResultSetWrappingImplementation__get__insertId(_this) {
  try {
    return __dom_wrap(_this.insertId);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLResultSetWrappingImplementation__get__rows(_this) {
  try {
    return __dom_wrap(_this.rows);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLResultSetWrappingImplementation__get__rowsAffected(_this) {
  try {
    return __dom_wrap(_this.rowsAffected);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLResultSetRowListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLResultSetRowListWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLStatementCallbackWrappingImplementation__handleEvent(_this, transaction, resultSet) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(transaction), __dom_unwrap(resultSet)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLStatementErrorCallbackWrappingImplementation__handleEvent(_this, transaction, error) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(transaction), __dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLTransactionCallbackWrappingImplementation__handleEvent(_this, transaction) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(transaction)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLTransactionErrorCallbackWrappingImplementation__handleEvent(_this, error) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SQLTransactionSyncCallbackWrappingImplementation__handleEvent(_this, transaction) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(transaction)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScreenWrappingImplementation__get__availHeight(_this) {
  try {
    return __dom_wrap(_this.availHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScreenWrappingImplementation__get__availLeft(_this) {
  try {
    return __dom_wrap(_this.availLeft);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScreenWrappingImplementation__get__availTop(_this) {
  try {
    return __dom_wrap(_this.availTop);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScreenWrappingImplementation__get__availWidth(_this) {
  try {
    return __dom_wrap(_this.availWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScreenWrappingImplementation__get__colorDepth(_this) {
  try {
    return __dom_wrap(_this.colorDepth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScreenWrappingImplementation__get__height(_this) {
  try {
    return __dom_wrap(_this.height);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScreenWrappingImplementation__get__pixelDepth(_this) {
  try {
    return __dom_wrap(_this.pixelDepth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScreenWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileWrappingImplementation__get__head(_this) {
  try {
    return __dom_wrap(_this.head);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileWrappingImplementation__get__title(_this) {
  try {
    return __dom_wrap(_this.title);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileWrappingImplementation__get__uid(_this) {
  try {
    return __dom_wrap(_this.uid);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileNodeWrappingImplementation__get__callUID(_this) {
  try {
    return __dom_wrap(_this.callUID);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileNodeWrappingImplementation__get__functionName(_this) {
  try {
    return __dom_wrap(_this.functionName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileNodeWrappingImplementation__get__lineNumber(_this) {
  try {
    return __dom_wrap(_this.lineNumber);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileNodeWrappingImplementation__get__numberOfCalls(_this) {
  try {
    return __dom_wrap(_this.numberOfCalls);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileNodeWrappingImplementation__get__selfTime(_this) {
  try {
    return __dom_wrap(_this.selfTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileNodeWrappingImplementation__get__totalTime(_this) {
  try {
    return __dom_wrap(_this.totalTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileNodeWrappingImplementation__get__url(_this) {
  try {
    return __dom_wrap(_this.url);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ScriptProfileNodeWrappingImplementation__get__visible(_this) {
  try {
    return __dom_wrap(_this.visible);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SharedWorkerWrappingImplementation__get__port(_this) {
  try {
    return __dom_wrap(_this.port);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SharedWorkercontextWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SharedWorkercontextWrappingImplementation__get__onconnect(_this) {
  try {
    return __dom_wrap(_this.onconnect);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SharedWorkercontextWrappingImplementation__set__onconnect(_this, value) {
  try {
    _this.onconnect = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SpeechInputEventWrappingImplementation__get__results(_this) {
  try {
    return __dom_wrap(_this.results);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SpeechInputResultWrappingImplementation__get__confidence(_this) {
  try {
    return __dom_wrap(_this.confidence);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SpeechInputResultWrappingImplementation__get__utterance(_this) {
  try {
    return __dom_wrap(_this.utterance);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SpeechInputResultListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__SpeechInputResultListWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageWrappingImplementation__clear(_this) {
  try {
    return __dom_wrap(_this.clear());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageWrappingImplementation__getItem(_this, key) {
  try {
    return __dom_wrap(_this.getItem(__dom_unwrap(key)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageWrappingImplementation__key(_this, index) {
  try {
    return __dom_wrap(_this.key(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageWrappingImplementation__removeItem(_this, key) {
  try {
    return __dom_wrap(_this.removeItem(__dom_unwrap(key)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageWrappingImplementation__setItem(_this, key, data) {
  try {
    return __dom_wrap(_this.setItem(__dom_unwrap(key), __dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__get__key(_this) {
  try {
    return __dom_wrap(_this.key);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__get__newValue(_this) {
  try {
    return __dom_wrap(_this.newValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__get__oldValue(_this) {
  try {
    return __dom_wrap(_this.oldValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__get__storageArea(_this) {
  try {
    return __dom_wrap(_this.storageArea);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__get__url(_this) {
  try {
    return __dom_wrap(_this.url);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent(_this) {
  try {
    return __dom_wrap(_this.initStorageEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initStorageEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initStorageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initStorageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent_5(_this, typeArg, canBubbleArg, cancelableArg, keyArg) {
  try {
    return __dom_wrap(_this.initStorageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(keyArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent_6(_this, typeArg, canBubbleArg, cancelableArg, keyArg, oldValueArg) {
  try {
    return __dom_wrap(_this.initStorageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(keyArg), __dom_unwrap(oldValueArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent_7(_this, typeArg, canBubbleArg, cancelableArg, keyArg, oldValueArg, newValueArg) {
  try {
    return __dom_wrap(_this.initStorageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(keyArg), __dom_unwrap(oldValueArg), __dom_unwrap(newValueArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent_8(_this, typeArg, canBubbleArg, cancelableArg, keyArg, oldValueArg, newValueArg, urlArg) {
  try {
    return __dom_wrap(_this.initStorageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(keyArg), __dom_unwrap(oldValueArg), __dom_unwrap(newValueArg), __dom_unwrap(urlArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageEventWrappingImplementation__initStorageEvent_9(_this, typeArg, canBubbleArg, cancelableArg, keyArg, oldValueArg, newValueArg, urlArg, storageAreaArg) {
  try {
    return __dom_wrap(_this.initStorageEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(keyArg), __dom_unwrap(oldValueArg), __dom_unwrap(newValueArg), __dom_unwrap(urlArg), __dom_unwrap(storageAreaArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoWrappingImplementation__queryUsageAndQuota(_this, storageType) {
  try {
    return __dom_wrap(_this.queryUsageAndQuota(__dom_unwrap(storageType)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoWrappingImplementation__queryUsageAndQuota_2(_this, storageType, usageCallback) {
  try {
    return __dom_wrap(_this.queryUsageAndQuota(__dom_unwrap(storageType), __dom_unwrap(usageCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoWrappingImplementation__queryUsageAndQuota_3(_this, storageType, usageCallback, errorCallback) {
  try {
    return __dom_wrap(_this.queryUsageAndQuota(__dom_unwrap(storageType), __dom_unwrap(usageCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoWrappingImplementation__requestQuota(_this, storageType, newQuotaInBytes) {
  try {
    return __dom_wrap(_this.requestQuota(__dom_unwrap(storageType), __dom_unwrap(newQuotaInBytes)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoWrappingImplementation__requestQuota_2(_this, storageType, newQuotaInBytes, quotaCallback) {
  try {
    return __dom_wrap(_this.requestQuota(__dom_unwrap(storageType), __dom_unwrap(newQuotaInBytes), __dom_unwrap(quotaCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoWrappingImplementation__requestQuota_3(_this, storageType, newQuotaInBytes, quotaCallback, errorCallback) {
  try {
    return __dom_wrap(_this.requestQuota(__dom_unwrap(storageType), __dom_unwrap(newQuotaInBytes), __dom_unwrap(quotaCallback), __dom_unwrap(errorCallback)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoErrorCallbackWrappingImplementation__handleEvent(_this, error) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(error)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoQuotaCallbackWrappingImplementation__handleEvent(_this, grantedQuotaInBytes) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(grantedQuotaInBytes)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StorageInfoUsageCallbackWrappingImplementation__handleEvent(_this, currentUsageInBytes, currentQuotaInBytes) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(currentUsageInBytes), __dom_unwrap(currentQuotaInBytes)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StringCallbackWrappingImplementation__handleEvent(_this, data) {
  try {
    return __dom_wrap(_this.handleEvent(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleMediaWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleMediaWrappingImplementation__matchMedium(_this) {
  try {
    return __dom_wrap(_this.matchMedium());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleMediaWrappingImplementation__matchMedium_2(_this, mediaquery) {
  try {
    return __dom_wrap(_this.matchMedium(__dom_unwrap(mediaquery)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetWrappingImplementation__get__disabled(_this) {
  try {
    return __dom_wrap(_this.disabled);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetWrappingImplementation__set__disabled(_this, value) {
  try {
    _this.disabled = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetWrappingImplementation__get__href(_this) {
  try {
    return __dom_wrap(_this.href);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetWrappingImplementation__get__media(_this) {
  try {
    return __dom_wrap(_this.media);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetWrappingImplementation__get__ownerNode(_this) {
  try {
    return __dom_wrap(_this.ownerNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetWrappingImplementation__get__parentStyleSheet(_this) {
  try {
    return __dom_wrap(_this.parentStyleSheet);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetWrappingImplementation__get__title(_this) {
  try {
    return __dom_wrap(_this.title);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetListWrappingImplementation__item(_this) {
  try {
    return __dom_wrap(_this.item());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__StyleSheetListWrappingImplementation__item_2(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextWrappingImplementation__get__wholeText(_this) {
  try {
    return __dom_wrap(_this.wholeText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextWrappingImplementation__replaceWholeText(_this) {
  try {
    return __dom_wrap(_this.replaceWholeText());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextWrappingImplementation__replaceWholeText_2(_this, content) {
  try {
    return __dom_wrap(_this.replaceWholeText(__dom_unwrap(content)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextWrappingImplementation__splitText(_this) {
  try {
    return __dom_wrap(_this.splitText());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextWrappingImplementation__splitText_2(_this, offset) {
  try {
    return __dom_wrap(_this.splitText(__dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextEventWrappingImplementation__get__data(_this) {
  try {
    return __dom_wrap(_this.data);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextEventWrappingImplementation__initTextEvent(_this) {
  try {
    return __dom_wrap(_this.initTextEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextEventWrappingImplementation__initTextEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initTextEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextEventWrappingImplementation__initTextEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initTextEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextEventWrappingImplementation__initTextEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initTextEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextEventWrappingImplementation__initTextEvent_5(_this, typeArg, canBubbleArg, cancelableArg, viewArg) {
  try {
    return __dom_wrap(_this.initTextEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(viewArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextEventWrappingImplementation__initTextEvent_6(_this, typeArg, canBubbleArg, cancelableArg, viewArg, dataArg) {
  try {
    return __dom_wrap(_this.initTextEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(viewArg), __dom_unwrap(dataArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TextMetricsWrappingImplementation__get__width(_this) {
  try {
    return __dom_wrap(_this.width);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TimeRangesWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TimeRangesWrappingImplementation__end(_this, index) {
  try {
    return __dom_wrap(_this.end(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TimeRangesWrappingImplementation__start(_this, index) {
  try {
    return __dom_wrap(_this.start(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__clientX(_this) {
  try {
    return __dom_wrap(_this.clientX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__clientY(_this) {
  try {
    return __dom_wrap(_this.clientY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__identifier(_this) {
  try {
    return __dom_wrap(_this.identifier);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__pageX(_this) {
  try {
    return __dom_wrap(_this.pageX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__pageY(_this) {
  try {
    return __dom_wrap(_this.pageY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__screenX(_this) {
  try {
    return __dom_wrap(_this.screenX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__screenY(_this) {
  try {
    return __dom_wrap(_this.screenY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__target(_this) {
  try {
    return __dom_wrap(_this.target);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__webkitForce(_this) {
  try {
    return __dom_wrap(_this.webkitForce);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__webkitRadiusX(_this) {
  try {
    return __dom_wrap(_this.webkitRadiusX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__webkitRadiusY(_this) {
  try {
    return __dom_wrap(_this.webkitRadiusY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchWrappingImplementation__get__webkitRotationAngle(_this) {
  try {
    return __dom_wrap(_this.webkitRotationAngle);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__get__altKey(_this) {
  try {
    return __dom_wrap(_this.altKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__get__changedTouches(_this) {
  try {
    return __dom_wrap(_this.changedTouches);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__get__ctrlKey(_this) {
  try {
    return __dom_wrap(_this.ctrlKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__get__metaKey(_this) {
  try {
    return __dom_wrap(_this.metaKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__get__shiftKey(_this) {
  try {
    return __dom_wrap(_this.shiftKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__get__targetTouches(_this) {
  try {
    return __dom_wrap(_this.targetTouches);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__get__touches(_this) {
  try {
    return __dom_wrap(_this.touches);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent(_this) {
  try {
    return __dom_wrap(_this.initTouchEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_2(_this, touches) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_3(_this, touches, targetTouches) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_4(_this, touches, targetTouches, changedTouches) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_5(_this, touches, targetTouches, changedTouches, type) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_6(_this, touches, targetTouches, changedTouches, type, view) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_7(_this, touches, targetTouches, changedTouches, type, view, screenX) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view), __dom_unwrap(screenX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_8(_this, touches, targetTouches, changedTouches, type, view, screenX, screenY) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_9(_this, touches, targetTouches, changedTouches, type, view, screenX, screenY, clientX) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_10(_this, touches, targetTouches, changedTouches, type, view, screenX, screenY, clientX, clientY) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_11(_this, touches, targetTouches, changedTouches, type, view, screenX, screenY, clientX, clientY, ctrlKey) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_12(_this, touches, targetTouches, changedTouches, type, view, screenX, screenY, clientX, clientY, ctrlKey, altKey) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_13(_this, touches, targetTouches, changedTouches, type, view, screenX, screenY, clientX, clientY, ctrlKey, altKey, shiftKey) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchEventWrappingImplementation__initTouchEvent_14(_this, touches, targetTouches, changedTouches, type, view, screenX, screenY, clientX, clientY, ctrlKey, altKey, shiftKey, metaKey) {
  try {
    return __dom_wrap(_this.initTouchEvent(__dom_unwrap(touches), __dom_unwrap(targetTouches), __dom_unwrap(changedTouches), __dom_unwrap(type), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey), __dom_unwrap(metaKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TouchListWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__get__currentNode(_this) {
  try {
    return __dom_wrap(_this.currentNode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__set__currentNode(_this, value) {
  try {
    _this.currentNode = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__get__expandEntityReferences(_this) {
  try {
    return __dom_wrap(_this.expandEntityReferences);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__get__filter(_this) {
  try {
    return __dom_wrap(_this.filter);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__get__root(_this) {
  try {
    return __dom_wrap(_this.root);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__get__whatToShow(_this) {
  try {
    return __dom_wrap(_this.whatToShow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__firstChild(_this) {
  try {
    return __dom_wrap(_this.firstChild());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__lastChild(_this) {
  try {
    return __dom_wrap(_this.lastChild());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__nextNode(_this) {
  try {
    return __dom_wrap(_this.nextNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__nextSibling(_this) {
  try {
    return __dom_wrap(_this.nextSibling());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__parentNode(_this) {
  try {
    return __dom_wrap(_this.parentNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__previousNode(_this) {
  try {
    return __dom_wrap(_this.previousNode());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__TreeWalkerWrappingImplementation__previousSibling(_this) {
  try {
    return __dom_wrap(_this.previousSibling());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__charCode(_this) {
  try {
    return __dom_wrap(_this.charCode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__detail(_this) {
  try {
    return __dom_wrap(_this.detail);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__keyCode(_this) {
  try {
    return __dom_wrap(_this.keyCode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__layerX(_this) {
  try {
    return __dom_wrap(_this.layerX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__layerY(_this) {
  try {
    return __dom_wrap(_this.layerY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__pageX(_this) {
  try {
    return __dom_wrap(_this.pageX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__pageY(_this) {
  try {
    return __dom_wrap(_this.pageY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__view(_this) {
  try {
    return __dom_wrap(_this.view);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__get__which(_this) {
  try {
    return __dom_wrap(_this.which);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__initUIEvent(_this) {
  try {
    return __dom_wrap(_this.initUIEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__initUIEvent_2(_this, type) {
  try {
    return __dom_wrap(_this.initUIEvent(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__initUIEvent_3(_this, type, canBubble) {
  try {
    return __dom_wrap(_this.initUIEvent(__dom_unwrap(type), __dom_unwrap(canBubble)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__initUIEvent_4(_this, type, canBubble, cancelable) {
  try {
    return __dom_wrap(_this.initUIEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__initUIEvent_5(_this, type, canBubble, cancelable, view) {
  try {
    return __dom_wrap(_this.initUIEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__UIEventWrappingImplementation__initUIEvent_6(_this, type, canBubble, cancelable, view, detail) {
  try {
    return __dom_wrap(_this.initUIEvent(__dom_unwrap(type), __dom_unwrap(canBubble), __dom_unwrap(cancelable), __dom_unwrap(view), __dom_unwrap(detail)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint16ArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint16ArrayWrappingImplementation__subarray(_this) {
  try {
    return __dom_wrap(_this.subarray());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint16ArrayWrappingImplementation__subarray_2(_this, start) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint16ArrayWrappingImplementation__subarray_3(_this, start, end) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint32ArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint32ArrayWrappingImplementation__subarray(_this) {
  try {
    return __dom_wrap(_this.subarray());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint32ArrayWrappingImplementation__subarray_2(_this, start) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint32ArrayWrappingImplementation__subarray_3(_this, start, end) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint8ArrayWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint8ArrayWrappingImplementation__subarray(_this) {
  try {
    return __dom_wrap(_this.subarray());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint8ArrayWrappingImplementation__subarray_2(_this, start) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__Uint8ArrayWrappingImplementation__subarray_3(_this, start, end) {
  try {
    return __dom_wrap(_this.subarray(__dom_unwrap(start), __dom_unwrap(end)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__customError(_this) {
  try {
    return __dom_wrap(_this.customError);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__patternMismatch(_this) {
  try {
    return __dom_wrap(_this.patternMismatch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__rangeOverflow(_this) {
  try {
    return __dom_wrap(_this.rangeOverflow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__rangeUnderflow(_this) {
  try {
    return __dom_wrap(_this.rangeUnderflow);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__stepMismatch(_this) {
  try {
    return __dom_wrap(_this.stepMismatch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__tooLong(_this) {
  try {
    return __dom_wrap(_this.tooLong);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__typeMismatch(_this) {
  try {
    return __dom_wrap(_this.typeMismatch);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__valid(_this) {
  try {
    return __dom_wrap(_this.valid);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__ValidityStateWrappingImplementation__get__valueMissing(_this) {
  try {
    return __dom_wrap(_this.valueMissing);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__VoidCallbackWrappingImplementation__handleEvent(_this) {
  try {
    return __dom_wrap(_this.handleEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLActiveInfoWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLActiveInfoWrappingImplementation__get__size(_this) {
  try {
    return __dom_wrap(_this.size);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLActiveInfoWrappingImplementation__get__type(_this) {
  try {
    return __dom_wrap(_this.type);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__get__alpha(_this) {
  try {
    return __dom_wrap(_this.alpha);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__set__alpha(_this, value) {
  try {
    _this.alpha = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__get__antialias(_this) {
  try {
    return __dom_wrap(_this.antialias);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__set__antialias(_this, value) {
  try {
    _this.antialias = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__get__depth(_this) {
  try {
    return __dom_wrap(_this.depth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__set__depth(_this, value) {
  try {
    _this.depth = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__get__premultipliedAlpha(_this) {
  try {
    return __dom_wrap(_this.premultipliedAlpha);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__set__premultipliedAlpha(_this, value) {
  try {
    _this.premultipliedAlpha = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__get__preserveDrawingBuffer(_this) {
  try {
    return __dom_wrap(_this.preserveDrawingBuffer);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__set__preserveDrawingBuffer(_this, value) {
  try {
    _this.preserveDrawingBuffer = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__get__stencil(_this) {
  try {
    return __dom_wrap(_this.stencil);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextAttributesWrappingImplementation__set__stencil(_this, value) {
  try {
    _this.stencil = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLContextEventWrappingImplementation__get__statusMessage(_this) {
  try {
    return __dom_wrap(_this.statusMessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__get__drawingBufferHeight(_this) {
  try {
    return __dom_wrap(_this.drawingBufferHeight);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__get__drawingBufferWidth(_this) {
  try {
    return __dom_wrap(_this.drawingBufferWidth);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__activeTexture(_this, texture) {
  try {
    return __dom_wrap(_this.activeTexture(__dom_unwrap(texture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__attachShader(_this, program, shader) {
  try {
    return __dom_wrap(_this.attachShader(__dom_unwrap(program), __dom_unwrap(shader)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bindAttribLocation(_this, program, index, name) {
  try {
    return __dom_wrap(_this.bindAttribLocation(__dom_unwrap(program), __dom_unwrap(index), __dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bindBuffer(_this, target, buffer) {
  try {
    return __dom_wrap(_this.bindBuffer(__dom_unwrap(target), __dom_unwrap(buffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bindFramebuffer(_this, target, framebuffer) {
  try {
    return __dom_wrap(_this.bindFramebuffer(__dom_unwrap(target), __dom_unwrap(framebuffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bindRenderbuffer(_this, target, renderbuffer) {
  try {
    return __dom_wrap(_this.bindRenderbuffer(__dom_unwrap(target), __dom_unwrap(renderbuffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bindTexture(_this, target, texture) {
  try {
    return __dom_wrap(_this.bindTexture(__dom_unwrap(target), __dom_unwrap(texture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__blendColor(_this, red, green, blue, alpha) {
  try {
    return __dom_wrap(_this.blendColor(__dom_unwrap(red), __dom_unwrap(green), __dom_unwrap(blue), __dom_unwrap(alpha)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__blendEquation(_this, mode) {
  try {
    return __dom_wrap(_this.blendEquation(__dom_unwrap(mode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__blendEquationSeparate(_this, modeRGB, modeAlpha) {
  try {
    return __dom_wrap(_this.blendEquationSeparate(__dom_unwrap(modeRGB), __dom_unwrap(modeAlpha)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__blendFunc(_this, sfactor, dfactor) {
  try {
    return __dom_wrap(_this.blendFunc(__dom_unwrap(sfactor), __dom_unwrap(dfactor)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__blendFuncSeparate(_this, srcRGB, dstRGB, srcAlpha, dstAlpha) {
  try {
    return __dom_wrap(_this.blendFuncSeparate(__dom_unwrap(srcRGB), __dom_unwrap(dstRGB), __dom_unwrap(srcAlpha), __dom_unwrap(dstAlpha)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bufferData(_this, target, data_OR_size, usage) {
  try {
    return __dom_wrap(_this.bufferData(__dom_unwrap(target), __dom_unwrap(data_OR_size), __dom_unwrap(usage)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bufferData_2(_this, target, data_OR_size, usage) {
  try {
    return __dom_wrap(_this.bufferData(__dom_unwrap(target), __dom_unwrap(data_OR_size), __dom_unwrap(usage)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bufferData_3(_this, target, data_OR_size, usage) {
  try {
    return __dom_wrap(_this.bufferData(__dom_unwrap(target), __dom_unwrap(data_OR_size), __dom_unwrap(usage)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bufferSubData(_this, target, offset, data) {
  try {
    return __dom_wrap(_this.bufferSubData(__dom_unwrap(target), __dom_unwrap(offset), __dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__bufferSubData_2(_this, target, offset, data) {
  try {
    return __dom_wrap(_this.bufferSubData(__dom_unwrap(target), __dom_unwrap(offset), __dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__checkFramebufferStatus(_this, target) {
  try {
    return __dom_wrap(_this.checkFramebufferStatus(__dom_unwrap(target)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__clear(_this, mask) {
  try {
    return __dom_wrap(_this.clear(__dom_unwrap(mask)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__clearColor(_this, red, green, blue, alpha) {
  try {
    return __dom_wrap(_this.clearColor(__dom_unwrap(red), __dom_unwrap(green), __dom_unwrap(blue), __dom_unwrap(alpha)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__clearDepth(_this, depth) {
  try {
    return __dom_wrap(_this.clearDepth(__dom_unwrap(depth)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__clearStencil(_this, s) {
  try {
    return __dom_wrap(_this.clearStencil(__dom_unwrap(s)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__colorMask(_this, red, green, blue, alpha) {
  try {
    return __dom_wrap(_this.colorMask(__dom_unwrap(red), __dom_unwrap(green), __dom_unwrap(blue), __dom_unwrap(alpha)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__compileShader(_this, shader) {
  try {
    return __dom_wrap(_this.compileShader(__dom_unwrap(shader)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__copyTexImage2D(_this, target, level, internalformat, x, y, width, height, border) {
  try {
    return __dom_wrap(_this.copyTexImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(internalformat), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(border)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__copyTexSubImage2D(_this, target, level, xoffset, yoffset, x, y, width, height) {
  try {
    return __dom_wrap(_this.copyTexSubImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(xoffset), __dom_unwrap(yoffset), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(width), __dom_unwrap(height)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__createBuffer(_this) {
  try {
    return __dom_wrap(_this.createBuffer());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__createFramebuffer(_this) {
  try {
    return __dom_wrap(_this.createFramebuffer());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__createProgram(_this) {
  try {
    return __dom_wrap(_this.createProgram());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__createRenderbuffer(_this) {
  try {
    return __dom_wrap(_this.createRenderbuffer());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__createShader(_this, type) {
  try {
    return __dom_wrap(_this.createShader(__dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__createTexture(_this) {
  try {
    return __dom_wrap(_this.createTexture());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__cullFace(_this, mode) {
  try {
    return __dom_wrap(_this.cullFace(__dom_unwrap(mode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__deleteBuffer(_this, buffer) {
  try {
    return __dom_wrap(_this.deleteBuffer(__dom_unwrap(buffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__deleteFramebuffer(_this, framebuffer) {
  try {
    return __dom_wrap(_this.deleteFramebuffer(__dom_unwrap(framebuffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__deleteProgram(_this, program) {
  try {
    return __dom_wrap(_this.deleteProgram(__dom_unwrap(program)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__deleteRenderbuffer(_this, renderbuffer) {
  try {
    return __dom_wrap(_this.deleteRenderbuffer(__dom_unwrap(renderbuffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__deleteShader(_this, shader) {
  try {
    return __dom_wrap(_this.deleteShader(__dom_unwrap(shader)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__deleteTexture(_this, texture) {
  try {
    return __dom_wrap(_this.deleteTexture(__dom_unwrap(texture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__depthFunc(_this, func) {
  try {
    return __dom_wrap(_this.depthFunc(__dom_unwrap(func)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__depthMask(_this, flag) {
  try {
    return __dom_wrap(_this.depthMask(__dom_unwrap(flag)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__depthRange(_this, zNear, zFar) {
  try {
    return __dom_wrap(_this.depthRange(__dom_unwrap(zNear), __dom_unwrap(zFar)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__detachShader(_this, program, shader) {
  try {
    return __dom_wrap(_this.detachShader(__dom_unwrap(program), __dom_unwrap(shader)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__disable(_this, cap) {
  try {
    return __dom_wrap(_this.disable(__dom_unwrap(cap)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__disableVertexAttribArray(_this, index) {
  try {
    return __dom_wrap(_this.disableVertexAttribArray(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__drawArrays(_this, mode, first, count) {
  try {
    return __dom_wrap(_this.drawArrays(__dom_unwrap(mode), __dom_unwrap(first), __dom_unwrap(count)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__drawElements(_this, mode, count, type, offset) {
  try {
    return __dom_wrap(_this.drawElements(__dom_unwrap(mode), __dom_unwrap(count), __dom_unwrap(type), __dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__enable(_this, cap) {
  try {
    return __dom_wrap(_this.enable(__dom_unwrap(cap)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__enableVertexAttribArray(_this, index) {
  try {
    return __dom_wrap(_this.enableVertexAttribArray(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__finish(_this) {
  try {
    return __dom_wrap(_this.finish());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__flush(_this) {
  try {
    return __dom_wrap(_this.flush());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__framebufferRenderbuffer(_this, target, attachment, renderbuffertarget, renderbuffer) {
  try {
    return __dom_wrap(_this.framebufferRenderbuffer(__dom_unwrap(target), __dom_unwrap(attachment), __dom_unwrap(renderbuffertarget), __dom_unwrap(renderbuffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__framebufferTexture2D(_this, target, attachment, textarget, texture, level) {
  try {
    return __dom_wrap(_this.framebufferTexture2D(__dom_unwrap(target), __dom_unwrap(attachment), __dom_unwrap(textarget), __dom_unwrap(texture), __dom_unwrap(level)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__frontFace(_this, mode) {
  try {
    return __dom_wrap(_this.frontFace(__dom_unwrap(mode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__generateMipmap(_this, target) {
  try {
    return __dom_wrap(_this.generateMipmap(__dom_unwrap(target)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getActiveAttrib(_this, program, index) {
  try {
    return __dom_wrap(_this.getActiveAttrib(__dom_unwrap(program), __dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getActiveUniform(_this, program, index) {
  try {
    return __dom_wrap(_this.getActiveUniform(__dom_unwrap(program), __dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getAttachedShaders(_this, program) {
  try {
    return __dom_wrap(_this.getAttachedShaders(__dom_unwrap(program)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getAttribLocation(_this, program, name) {
  try {
    return __dom_wrap(_this.getAttribLocation(__dom_unwrap(program), __dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getBufferParameter(_this) {
  try {
    return __dom_wrap(_this.getBufferParameter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getContextAttributes(_this) {
  try {
    return __dom_wrap(_this.getContextAttributes());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getError(_this) {
  try {
    return __dom_wrap(_this.getError());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getExtension(_this, name) {
  try {
    return __dom_wrap(_this.getExtension(__dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getFramebufferAttachmentParameter(_this) {
  try {
    return __dom_wrap(_this.getFramebufferAttachmentParameter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getParameter(_this) {
  try {
    return __dom_wrap(_this.getParameter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getProgramInfoLog(_this, program) {
  try {
    return __dom_wrap(_this.getProgramInfoLog(__dom_unwrap(program)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getProgramParameter(_this) {
  try {
    return __dom_wrap(_this.getProgramParameter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getRenderbufferParameter(_this) {
  try {
    return __dom_wrap(_this.getRenderbufferParameter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getShaderInfoLog(_this, shader) {
  try {
    return __dom_wrap(_this.getShaderInfoLog(__dom_unwrap(shader)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getShaderParameter(_this) {
  try {
    return __dom_wrap(_this.getShaderParameter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getShaderSource(_this, shader) {
  try {
    return __dom_wrap(_this.getShaderSource(__dom_unwrap(shader)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getSupportedExtensions(_this) {
  try {
    return __dom_wrap(_this.getSupportedExtensions());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getTexParameter(_this) {
  try {
    return __dom_wrap(_this.getTexParameter());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getUniform(_this) {
  try {
    return __dom_wrap(_this.getUniform());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getUniformLocation(_this, program, name) {
  try {
    return __dom_wrap(_this.getUniformLocation(__dom_unwrap(program), __dom_unwrap(name)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getVertexAttrib(_this) {
  try {
    return __dom_wrap(_this.getVertexAttrib());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__getVertexAttribOffset(_this, index, pname) {
  try {
    return __dom_wrap(_this.getVertexAttribOffset(__dom_unwrap(index), __dom_unwrap(pname)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__hint(_this, target, mode) {
  try {
    return __dom_wrap(_this.hint(__dom_unwrap(target), __dom_unwrap(mode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__isBuffer(_this, buffer) {
  try {
    return __dom_wrap(_this.isBuffer(__dom_unwrap(buffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__isContextLost(_this) {
  try {
    return __dom_wrap(_this.isContextLost());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__isEnabled(_this, cap) {
  try {
    return __dom_wrap(_this.isEnabled(__dom_unwrap(cap)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__isFramebuffer(_this, framebuffer) {
  try {
    return __dom_wrap(_this.isFramebuffer(__dom_unwrap(framebuffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__isProgram(_this, program) {
  try {
    return __dom_wrap(_this.isProgram(__dom_unwrap(program)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__isRenderbuffer(_this, renderbuffer) {
  try {
    return __dom_wrap(_this.isRenderbuffer(__dom_unwrap(renderbuffer)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__isShader(_this, shader) {
  try {
    return __dom_wrap(_this.isShader(__dom_unwrap(shader)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__isTexture(_this, texture) {
  try {
    return __dom_wrap(_this.isTexture(__dom_unwrap(texture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__lineWidth(_this, width) {
  try {
    return __dom_wrap(_this.lineWidth(__dom_unwrap(width)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__linkProgram(_this, program) {
  try {
    return __dom_wrap(_this.linkProgram(__dom_unwrap(program)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__pixelStorei(_this, pname, param) {
  try {
    return __dom_wrap(_this.pixelStorei(__dom_unwrap(pname), __dom_unwrap(param)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__polygonOffset(_this, factor, units) {
  try {
    return __dom_wrap(_this.polygonOffset(__dom_unwrap(factor), __dom_unwrap(units)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__readPixels(_this, x, y, width, height, format, type, pixels) {
  try {
    return __dom_wrap(_this.readPixels(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(width), __dom_unwrap(height), __dom_unwrap(format), __dom_unwrap(type), __dom_unwrap(pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__releaseShaderCompiler(_this) {
  try {
    return __dom_wrap(_this.releaseShaderCompiler());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__renderbufferStorage(_this, target, internalformat, width, height) {
  try {
    return __dom_wrap(_this.renderbufferStorage(__dom_unwrap(target), __dom_unwrap(internalformat), __dom_unwrap(width), __dom_unwrap(height)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__sampleCoverage(_this, value, invert) {
  try {
    return __dom_wrap(_this.sampleCoverage(__dom_unwrap(value), __dom_unwrap(invert)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__scissor(_this, x, y, width, height) {
  try {
    return __dom_wrap(_this.scissor(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(width), __dom_unwrap(height)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__shaderSource(_this, shader, string) {
  try {
    return __dom_wrap(_this.shaderSource(__dom_unwrap(shader), __dom_unwrap(string)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__stencilFunc(_this, func, ref, mask) {
  try {
    return __dom_wrap(_this.stencilFunc(__dom_unwrap(func), __dom_unwrap(ref), __dom_unwrap(mask)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__stencilFuncSeparate(_this, face, func, ref, mask) {
  try {
    return __dom_wrap(_this.stencilFuncSeparate(__dom_unwrap(face), __dom_unwrap(func), __dom_unwrap(ref), __dom_unwrap(mask)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__stencilMask(_this, mask) {
  try {
    return __dom_wrap(_this.stencilMask(__dom_unwrap(mask)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__stencilMaskSeparate(_this, face, mask) {
  try {
    return __dom_wrap(_this.stencilMaskSeparate(__dom_unwrap(face), __dom_unwrap(mask)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__stencilOp(_this, fail, zfail, zpass) {
  try {
    return __dom_wrap(_this.stencilOp(__dom_unwrap(fail), __dom_unwrap(zfail), __dom_unwrap(zpass)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__stencilOpSeparate(_this, face, fail, zfail, zpass) {
  try {
    return __dom_wrap(_this.stencilOpSeparate(__dom_unwrap(face), __dom_unwrap(fail), __dom_unwrap(zfail), __dom_unwrap(zpass)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texImage2D(_this, target, level, internalformat, format_OR_width, height_OR_type, border_OR_canvas_OR_image_OR_pixels) {
  try {
    return __dom_wrap(_this.texImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(internalformat), __dom_unwrap(format_OR_width), __dom_unwrap(height_OR_type), __dom_unwrap(border_OR_canvas_OR_image_OR_pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texImage2D_2(_this, target, level, internalformat, format_OR_width, height_OR_type, border_OR_canvas_OR_image_OR_pixels) {
  try {
    return __dom_wrap(_this.texImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(internalformat), __dom_unwrap(format_OR_width), __dom_unwrap(height_OR_type), __dom_unwrap(border_OR_canvas_OR_image_OR_pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texImage2D_3(_this, target, level, internalformat, format_OR_width, height_OR_type, border_OR_canvas_OR_image_OR_pixels) {
  try {
    return __dom_wrap(_this.texImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(internalformat), __dom_unwrap(format_OR_width), __dom_unwrap(height_OR_type), __dom_unwrap(border_OR_canvas_OR_image_OR_pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texImage2D_4(_this, target, level, internalformat, format_OR_width, height_OR_type, border_OR_canvas_OR_image_OR_pixels, format, type, pixels) {
  try {
    return __dom_wrap(_this.texImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(internalformat), __dom_unwrap(format_OR_width), __dom_unwrap(height_OR_type), __dom_unwrap(border_OR_canvas_OR_image_OR_pixels), __dom_unwrap(format), __dom_unwrap(type), __dom_unwrap(pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texParameterf(_this, target, pname, param) {
  try {
    return __dom_wrap(_this.texParameterf(__dom_unwrap(target), __dom_unwrap(pname), __dom_unwrap(param)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texParameteri(_this, target, pname, param) {
  try {
    return __dom_wrap(_this.texParameteri(__dom_unwrap(target), __dom_unwrap(pname), __dom_unwrap(param)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texSubImage2D(_this, target, level, xoffset, yoffset, format_OR_width, height_OR_type, canvas_OR_format_OR_image_OR_pixels) {
  try {
    return __dom_wrap(_this.texSubImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(xoffset), __dom_unwrap(yoffset), __dom_unwrap(format_OR_width), __dom_unwrap(height_OR_type), __dom_unwrap(canvas_OR_format_OR_image_OR_pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texSubImage2D_2(_this, target, level, xoffset, yoffset, format_OR_width, height_OR_type, canvas_OR_format_OR_image_OR_pixels) {
  try {
    return __dom_wrap(_this.texSubImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(xoffset), __dom_unwrap(yoffset), __dom_unwrap(format_OR_width), __dom_unwrap(height_OR_type), __dom_unwrap(canvas_OR_format_OR_image_OR_pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texSubImage2D_3(_this, target, level, xoffset, yoffset, format_OR_width, height_OR_type, canvas_OR_format_OR_image_OR_pixels) {
  try {
    return __dom_wrap(_this.texSubImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(xoffset), __dom_unwrap(yoffset), __dom_unwrap(format_OR_width), __dom_unwrap(height_OR_type), __dom_unwrap(canvas_OR_format_OR_image_OR_pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__texSubImage2D_4(_this, target, level, xoffset, yoffset, format_OR_width, height_OR_type, canvas_OR_format_OR_image_OR_pixels, type, pixels) {
  try {
    return __dom_wrap(_this.texSubImage2D(__dom_unwrap(target), __dom_unwrap(level), __dom_unwrap(xoffset), __dom_unwrap(yoffset), __dom_unwrap(format_OR_width), __dom_unwrap(height_OR_type), __dom_unwrap(canvas_OR_format_OR_image_OR_pixels), __dom_unwrap(type), __dom_unwrap(pixels)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform1f(_this, location, x) {
  try {
    return __dom_wrap(_this.uniform1f(__dom_unwrap(location), __dom_unwrap(x)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform1fv(_this, location, v) {
  try {
    return __dom_wrap(_this.uniform1fv(__dom_unwrap(location), __dom_unwrap(v)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform1i(_this, location, x) {
  try {
    return __dom_wrap(_this.uniform1i(__dom_unwrap(location), __dom_unwrap(x)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform1iv(_this, location, v) {
  try {
    return __dom_wrap(_this.uniform1iv(__dom_unwrap(location), __dom_unwrap(v)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform2f(_this, location, x, y) {
  try {
    return __dom_wrap(_this.uniform2f(__dom_unwrap(location), __dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform2fv(_this, location, v) {
  try {
    return __dom_wrap(_this.uniform2fv(__dom_unwrap(location), __dom_unwrap(v)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform2i(_this, location, x, y) {
  try {
    return __dom_wrap(_this.uniform2i(__dom_unwrap(location), __dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform2iv(_this, location, v) {
  try {
    return __dom_wrap(_this.uniform2iv(__dom_unwrap(location), __dom_unwrap(v)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform3f(_this, location, x, y, z) {
  try {
    return __dom_wrap(_this.uniform3f(__dom_unwrap(location), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform3fv(_this, location, v) {
  try {
    return __dom_wrap(_this.uniform3fv(__dom_unwrap(location), __dom_unwrap(v)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform3i(_this, location, x, y, z) {
  try {
    return __dom_wrap(_this.uniform3i(__dom_unwrap(location), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform3iv(_this, location, v) {
  try {
    return __dom_wrap(_this.uniform3iv(__dom_unwrap(location), __dom_unwrap(v)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform4f(_this, location, x, y, z, w) {
  try {
    return __dom_wrap(_this.uniform4f(__dom_unwrap(location), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z), __dom_unwrap(w)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform4fv(_this, location, v) {
  try {
    return __dom_wrap(_this.uniform4fv(__dom_unwrap(location), __dom_unwrap(v)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform4i(_this, location, x, y, z, w) {
  try {
    return __dom_wrap(_this.uniform4i(__dom_unwrap(location), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z), __dom_unwrap(w)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniform4iv(_this, location, v) {
  try {
    return __dom_wrap(_this.uniform4iv(__dom_unwrap(location), __dom_unwrap(v)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniformMatrix2fv(_this, location, transpose, array) {
  try {
    return __dom_wrap(_this.uniformMatrix2fv(__dom_unwrap(location), __dom_unwrap(transpose), __dom_unwrap(array)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniformMatrix3fv(_this, location, transpose, array) {
  try {
    return __dom_wrap(_this.uniformMatrix3fv(__dom_unwrap(location), __dom_unwrap(transpose), __dom_unwrap(array)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__uniformMatrix4fv(_this, location, transpose, array) {
  try {
    return __dom_wrap(_this.uniformMatrix4fv(__dom_unwrap(location), __dom_unwrap(transpose), __dom_unwrap(array)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__useProgram(_this, program) {
  try {
    return __dom_wrap(_this.useProgram(__dom_unwrap(program)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__validateProgram(_this, program) {
  try {
    return __dom_wrap(_this.validateProgram(__dom_unwrap(program)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttrib1f(_this, indx, x) {
  try {
    return __dom_wrap(_this.vertexAttrib1f(__dom_unwrap(indx), __dom_unwrap(x)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttrib1fv(_this, indx, values) {
  try {
    return __dom_wrap(_this.vertexAttrib1fv(__dom_unwrap(indx), __dom_unwrap(values)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttrib2f(_this, indx, x, y) {
  try {
    return __dom_wrap(_this.vertexAttrib2f(__dom_unwrap(indx), __dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttrib2fv(_this, indx, values) {
  try {
    return __dom_wrap(_this.vertexAttrib2fv(__dom_unwrap(indx), __dom_unwrap(values)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttrib3f(_this, indx, x, y, z) {
  try {
    return __dom_wrap(_this.vertexAttrib3f(__dom_unwrap(indx), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttrib3fv(_this, indx, values) {
  try {
    return __dom_wrap(_this.vertexAttrib3fv(__dom_unwrap(indx), __dom_unwrap(values)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttrib4f(_this, indx, x, y, z, w) {
  try {
    return __dom_wrap(_this.vertexAttrib4f(__dom_unwrap(indx), __dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z), __dom_unwrap(w)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttrib4fv(_this, indx, values) {
  try {
    return __dom_wrap(_this.vertexAttrib4fv(__dom_unwrap(indx), __dom_unwrap(values)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__vertexAttribPointer(_this, indx, size, type, normalized, stride, offset) {
  try {
    return __dom_wrap(_this.vertexAttribPointer(__dom_unwrap(indx), __dom_unwrap(size), __dom_unwrap(type), __dom_unwrap(normalized), __dom_unwrap(stride), __dom_unwrap(offset)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebGLRenderingContextWrappingImplementation__viewport(_this, x, y, width, height) {
  try {
    return __dom_wrap(_this.viewport(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(width), __dom_unwrap(height)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__delay(_this) {
  try {
    return __dom_wrap(_this.delay);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__direction(_this) {
  try {
    return __dom_wrap(_this.direction);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__duration(_this) {
  try {
    return __dom_wrap(_this.duration);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__elapsedTime(_this) {
  try {
    return __dom_wrap(_this.elapsedTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__set__elapsedTime(_this, value) {
  try {
    _this.elapsedTime = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__ended(_this) {
  try {
    return __dom_wrap(_this.ended);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__fillMode(_this) {
  try {
    return __dom_wrap(_this.fillMode);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__iterationCount(_this) {
  try {
    return __dom_wrap(_this.iterationCount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__get__paused(_this) {
  try {
    return __dom_wrap(_this.paused);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__pause(_this) {
  try {
    return __dom_wrap(_this.pause());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationWrappingImplementation__play(_this) {
  try {
    return __dom_wrap(_this.play());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationEventWrappingImplementation__get__animationName(_this) {
  try {
    return __dom_wrap(_this.animationName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationEventWrappingImplementation__get__elapsedTime(_this) {
  try {
    return __dom_wrap(_this.elapsedTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationEventWrappingImplementation__initWebKitAnimationEvent(_this) {
  try {
    return __dom_wrap(_this.initWebKitAnimationEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationEventWrappingImplementation__initWebKitAnimationEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initWebKitAnimationEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationEventWrappingImplementation__initWebKitAnimationEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initWebKitAnimationEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationEventWrappingImplementation__initWebKitAnimationEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initWebKitAnimationEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationEventWrappingImplementation__initWebKitAnimationEvent_5(_this, typeArg, canBubbleArg, cancelableArg, animationNameArg) {
  try {
    return __dom_wrap(_this.initWebKitAnimationEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(animationNameArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationEventWrappingImplementation__initWebKitAnimationEvent_6(_this, typeArg, canBubbleArg, cancelableArg, animationNameArg, elapsedTimeArg) {
  try {
    return __dom_wrap(_this.initWebKitAnimationEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(animationNameArg), __dom_unwrap(elapsedTimeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationListWrappingImplementation__get__length(_this) {
  try {
    return __dom_wrap(_this.length);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitAnimationListWrappingImplementation__item(_this, index) {
  try {
    return __dom_wrap(_this.item(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitBlobBuilderWrappingImplementation__append(_this, blob_OR_value) {
  try {
    return __dom_wrap(_this.append(__dom_unwrap(blob_OR_value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitBlobBuilderWrappingImplementation__append_2(_this, blob_OR_value) {
  try {
    return __dom_wrap(_this.append(__dom_unwrap(blob_OR_value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitBlobBuilderWrappingImplementation__append_3(_this, blob_OR_value, endings) {
  try {
    return __dom_wrap(_this.append(__dom_unwrap(blob_OR_value), __dom_unwrap(endings)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitBlobBuilderWrappingImplementation__getBlob(_this) {
  try {
    return __dom_wrap(_this.getBlob());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitBlobBuilderWrappingImplementation__getBlob_2(_this, contentType) {
  try {
    return __dom_wrap(_this.getBlob(__dom_unwrap(contentType)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframeRuleWrappingImplementation__get__keyText(_this) {
  try {
    return __dom_wrap(_this.keyText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframeRuleWrappingImplementation__set__keyText(_this, value) {
  try {
    _this.keyText = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframeRuleWrappingImplementation__get__style(_this) {
  try {
    return __dom_wrap(_this.style);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__get__cssRules(_this) {
  try {
    return __dom_wrap(_this.cssRules);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__set__name(_this, value) {
  try {
    _this.name = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__deleteRule(_this) {
  try {
    return __dom_wrap(_this.deleteRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__deleteRule_2(_this, key) {
  try {
    return __dom_wrap(_this.deleteRule(__dom_unwrap(key)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__findRule(_this) {
  try {
    return __dom_wrap(_this.findRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__findRule_2(_this, key) {
  try {
    return __dom_wrap(_this.findRule(__dom_unwrap(key)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__insertRule(_this) {
  try {
    return __dom_wrap(_this.insertRule());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSKeyframesRuleWrappingImplementation__insertRule_2(_this, rule) {
  try {
    return __dom_wrap(_this.insertRule(__dom_unwrap(rule)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__a(_this) {
  try {
    return __dom_wrap(_this.a);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__a(_this, value) {
  try {
    _this.a = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__b(_this) {
  try {
    return __dom_wrap(_this.b);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__b(_this, value) {
  try {
    _this.b = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__c(_this) {
  try {
    return __dom_wrap(_this.c);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__c(_this, value) {
  try {
    _this.c = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__d(_this) {
  try {
    return __dom_wrap(_this.d);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__d(_this, value) {
  try {
    _this.d = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__e(_this) {
  try {
    return __dom_wrap(_this.e);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__e(_this, value) {
  try {
    _this.e = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__f(_this) {
  try {
    return __dom_wrap(_this.f);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__f(_this, value) {
  try {
    _this.f = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m11(_this) {
  try {
    return __dom_wrap(_this.m11);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m11(_this, value) {
  try {
    _this.m11 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m12(_this) {
  try {
    return __dom_wrap(_this.m12);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m12(_this, value) {
  try {
    _this.m12 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m13(_this) {
  try {
    return __dom_wrap(_this.m13);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m13(_this, value) {
  try {
    _this.m13 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m14(_this) {
  try {
    return __dom_wrap(_this.m14);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m14(_this, value) {
  try {
    _this.m14 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m21(_this) {
  try {
    return __dom_wrap(_this.m21);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m21(_this, value) {
  try {
    _this.m21 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m22(_this) {
  try {
    return __dom_wrap(_this.m22);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m22(_this, value) {
  try {
    _this.m22 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m23(_this) {
  try {
    return __dom_wrap(_this.m23);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m23(_this, value) {
  try {
    _this.m23 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m24(_this) {
  try {
    return __dom_wrap(_this.m24);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m24(_this, value) {
  try {
    _this.m24 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m31(_this) {
  try {
    return __dom_wrap(_this.m31);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m31(_this, value) {
  try {
    _this.m31 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m32(_this) {
  try {
    return __dom_wrap(_this.m32);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m32(_this, value) {
  try {
    _this.m32 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m33(_this) {
  try {
    return __dom_wrap(_this.m33);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m33(_this, value) {
  try {
    _this.m33 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m34(_this) {
  try {
    return __dom_wrap(_this.m34);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m34(_this, value) {
  try {
    _this.m34 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m41(_this) {
  try {
    return __dom_wrap(_this.m41);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m41(_this, value) {
  try {
    _this.m41 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m42(_this) {
  try {
    return __dom_wrap(_this.m42);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m42(_this, value) {
  try {
    _this.m42 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m43(_this) {
  try {
    return __dom_wrap(_this.m43);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m43(_this, value) {
  try {
    _this.m43 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__get__m44(_this) {
  try {
    return __dom_wrap(_this.m44);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__set__m44(_this, value) {
  try {
    _this.m44 = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__inverse(_this) {
  try {
    return __dom_wrap(_this.inverse());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__multiply(_this) {
  try {
    return __dom_wrap(_this.multiply());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__multiply_2(_this, secondMatrix) {
  try {
    return __dom_wrap(_this.multiply(__dom_unwrap(secondMatrix)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotate(_this) {
  try {
    return __dom_wrap(_this.rotate());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotate_2(_this, rotX) {
  try {
    return __dom_wrap(_this.rotate(__dom_unwrap(rotX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotate_3(_this, rotX, rotY) {
  try {
    return __dom_wrap(_this.rotate(__dom_unwrap(rotX), __dom_unwrap(rotY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotate_4(_this, rotX, rotY, rotZ) {
  try {
    return __dom_wrap(_this.rotate(__dom_unwrap(rotX), __dom_unwrap(rotY), __dom_unwrap(rotZ)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotateAxisAngle(_this) {
  try {
    return __dom_wrap(_this.rotateAxisAngle());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotateAxisAngle_2(_this, x) {
  try {
    return __dom_wrap(_this.rotateAxisAngle(__dom_unwrap(x)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotateAxisAngle_3(_this, x, y) {
  try {
    return __dom_wrap(_this.rotateAxisAngle(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotateAxisAngle_4(_this, x, y, z) {
  try {
    return __dom_wrap(_this.rotateAxisAngle(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__rotateAxisAngle_5(_this, x, y, z, angle) {
  try {
    return __dom_wrap(_this.rotateAxisAngle(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z), __dom_unwrap(angle)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__scale(_this) {
  try {
    return __dom_wrap(_this.scale());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__scale_2(_this, scaleX) {
  try {
    return __dom_wrap(_this.scale(__dom_unwrap(scaleX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__scale_3(_this, scaleX, scaleY) {
  try {
    return __dom_wrap(_this.scale(__dom_unwrap(scaleX), __dom_unwrap(scaleY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__scale_4(_this, scaleX, scaleY, scaleZ) {
  try {
    return __dom_wrap(_this.scale(__dom_unwrap(scaleX), __dom_unwrap(scaleY), __dom_unwrap(scaleZ)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__setMatrixValue(_this) {
  try {
    return __dom_wrap(_this.setMatrixValue());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__setMatrixValue_2(_this, string) {
  try {
    return __dom_wrap(_this.setMatrixValue(__dom_unwrap(string)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__skewX(_this) {
  try {
    return __dom_wrap(_this.skewX());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__skewX_2(_this, angle) {
  try {
    return __dom_wrap(_this.skewX(__dom_unwrap(angle)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__skewY(_this) {
  try {
    return __dom_wrap(_this.skewY());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__skewY_2(_this, angle) {
  try {
    return __dom_wrap(_this.skewY(__dom_unwrap(angle)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__toString(_this) {
  try {
    return __dom_wrap(_this.toString());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__translate(_this) {
  try {
    return __dom_wrap(_this.translate());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__translate_2(_this, x) {
  try {
    return __dom_wrap(_this.translate(__dom_unwrap(x)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__translate_3(_this, x, y) {
  try {
    return __dom_wrap(_this.translate(__dom_unwrap(x), __dom_unwrap(y)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSMatrixWrappingImplementation__translate_4(_this, x, y, z) {
  try {
    return __dom_wrap(_this.translate(__dom_unwrap(x), __dom_unwrap(y), __dom_unwrap(z)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitCSSTransformValueWrappingImplementation__get__operationType(_this) {
  try {
    return __dom_wrap(_this.operationType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitFlagsWrappingImplementation__get__create(_this) {
  try {
    return __dom_wrap(_this.create);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitFlagsWrappingImplementation__set__create(_this, value) {
  try {
    _this.create = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitFlagsWrappingImplementation__get__exclusive(_this) {
  try {
    return __dom_wrap(_this.exclusive);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitFlagsWrappingImplementation__set__exclusive(_this, value) {
  try {
    _this.exclusive = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitLoseContextWrappingImplementation__loseContext(_this) {
  try {
    return __dom_wrap(_this.loseContext());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitLoseContextWrappingImplementation__restoreContext(_this) {
  try {
    return __dom_wrap(_this.restoreContext());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitPointWrappingImplementation__get__x(_this) {
  try {
    return __dom_wrap(_this.x);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitPointWrappingImplementation__set__x(_this, value) {
  try {
    _this.x = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitPointWrappingImplementation__get__y(_this) {
  try {
    return __dom_wrap(_this.y);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitPointWrappingImplementation__set__y(_this, value) {
  try {
    _this.y = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitTransitionEventWrappingImplementation__get__elapsedTime(_this) {
  try {
    return __dom_wrap(_this.elapsedTime);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitTransitionEventWrappingImplementation__get__propertyName(_this) {
  try {
    return __dom_wrap(_this.propertyName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitTransitionEventWrappingImplementation__initWebKitTransitionEvent(_this) {
  try {
    return __dom_wrap(_this.initWebKitTransitionEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitTransitionEventWrappingImplementation__initWebKitTransitionEvent_2(_this, typeArg) {
  try {
    return __dom_wrap(_this.initWebKitTransitionEvent(__dom_unwrap(typeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitTransitionEventWrappingImplementation__initWebKitTransitionEvent_3(_this, typeArg, canBubbleArg) {
  try {
    return __dom_wrap(_this.initWebKitTransitionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitTransitionEventWrappingImplementation__initWebKitTransitionEvent_4(_this, typeArg, canBubbleArg, cancelableArg) {
  try {
    return __dom_wrap(_this.initWebKitTransitionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitTransitionEventWrappingImplementation__initWebKitTransitionEvent_5(_this, typeArg, canBubbleArg, cancelableArg, propertyNameArg) {
  try {
    return __dom_wrap(_this.initWebKitTransitionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(propertyNameArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebKitTransitionEventWrappingImplementation__initWebKitTransitionEvent_6(_this, typeArg, canBubbleArg, cancelableArg, propertyNameArg, elapsedTimeArg) {
  try {
    return __dom_wrap(_this.initWebKitTransitionEvent(__dom_unwrap(typeArg), __dom_unwrap(canBubbleArg), __dom_unwrap(cancelableArg), __dom_unwrap(propertyNameArg), __dom_unwrap(elapsedTimeArg)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__URL(_this) {
  try {
    return __dom_wrap(_this.URL);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__binaryType(_this) {
  try {
    return __dom_wrap(_this.binaryType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__set__binaryType(_this, value) {
  try {
    _this.binaryType = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__bufferedAmount(_this) {
  try {
    return __dom_wrap(_this.bufferedAmount);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__onclose(_this) {
  try {
    return __dom_wrap(_this.onclose);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__set__onclose(_this, value) {
  try {
    _this.onclose = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__onmessage(_this) {
  try {
    return __dom_wrap(_this.onmessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__set__onmessage(_this, value) {
  try {
    _this.onmessage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__onopen(_this) {
  try {
    return __dom_wrap(_this.onopen);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__set__onopen(_this, value) {
  try {
    _this.onopen = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__protocol(_this) {
  try {
    return __dom_wrap(_this.protocol);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__close(_this) {
  try {
    return __dom_wrap(_this.close());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WebSocketWrappingImplementation__send(_this, data) {
  try {
    return __dom_wrap(_this.send(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__altKey(_this) {
  try {
    return __dom_wrap(_this.altKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__clientX(_this) {
  try {
    return __dom_wrap(_this.clientX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__clientY(_this) {
  try {
    return __dom_wrap(_this.clientY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__ctrlKey(_this) {
  try {
    return __dom_wrap(_this.ctrlKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__metaKey(_this) {
  try {
    return __dom_wrap(_this.metaKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__offsetX(_this) {
  try {
    return __dom_wrap(_this.offsetX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__offsetY(_this) {
  try {
    return __dom_wrap(_this.offsetY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__screenX(_this) {
  try {
    return __dom_wrap(_this.screenX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__screenY(_this) {
  try {
    return __dom_wrap(_this.screenY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__shiftKey(_this) {
  try {
    return __dom_wrap(_this.shiftKey);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__wheelDelta(_this) {
  try {
    return __dom_wrap(_this.wheelDelta);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__wheelDeltaX(_this) {
  try {
    return __dom_wrap(_this.wheelDeltaX);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__wheelDeltaY(_this) {
  try {
    return __dom_wrap(_this.wheelDeltaY);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__x(_this) {
  try {
    return __dom_wrap(_this.x);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__get__y(_this) {
  try {
    return __dom_wrap(_this.y);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent(_this) {
  try {
    return __dom_wrap(_this.initWheelEvent());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_2(_this, wheelDeltaX) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_3(_this, wheelDeltaX, wheelDeltaY) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_4(_this, wheelDeltaX, wheelDeltaY, view) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_5(_this, wheelDeltaX, wheelDeltaY, view, screenX) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view), __dom_unwrap(screenX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_6(_this, wheelDeltaX, wheelDeltaY, view, screenX, screenY) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_7(_this, wheelDeltaX, wheelDeltaY, view, screenX, screenY, clientX) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_8(_this, wheelDeltaX, wheelDeltaY, view, screenX, screenY, clientX, clientY) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_9(_this, wheelDeltaX, wheelDeltaY, view, screenX, screenY, clientX, clientY, ctrlKey) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_10(_this, wheelDeltaX, wheelDeltaY, view, screenX, screenY, clientX, clientY, ctrlKey, altKey) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_11(_this, wheelDeltaX, wheelDeltaY, view, screenX, screenY, clientX, clientY, ctrlKey, altKey, shiftKey) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WheelEventWrappingImplementation__initWheelEvent_12(_this, wheelDeltaX, wheelDeltaY, view, screenX, screenY, clientX, clientY, ctrlKey, altKey, shiftKey, metaKey) {
  try {
    return __dom_wrap(_this.initWheelEvent(__dom_unwrap(wheelDeltaX), __dom_unwrap(wheelDeltaY), __dom_unwrap(view), __dom_unwrap(screenX), __dom_unwrap(screenY), __dom_unwrap(clientX), __dom_unwrap(clientY), __dom_unwrap(ctrlKey), __dom_unwrap(altKey), __dom_unwrap(shiftKey), __dom_unwrap(metaKey)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerWrappingImplementation__get__onmessage(_this) {
  try {
    return __dom_wrap(_this.onmessage);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerWrappingImplementation__set__onmessage(_this, value) {
  try {
    _this.onmessage = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerWrappingImplementation__postMessage(_this, message) {
  try {
    return __dom_wrap(_this.postMessage(__dom_unwrap(message)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerWrappingImplementation__postMessage_2(_this, message, messagePort) {
  try {
    return __dom_wrap(_this.postMessage(__dom_unwrap(message), __dom_unwrap(messagePort)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerWrappingImplementation__terminate(_this) {
  try {
    return __dom_wrap(_this.terminate());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__get__location(_this) {
  try {
    return __dom_wrap(_this.location);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__set__location(_this, value) {
  try {
    _this.location = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__get__navigator(_this) {
  try {
    return __dom_wrap(_this.navigator);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__set__navigator(_this, value) {
  try {
    _this.navigator = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__get__webkitNotifications(_this) {
  try {
    return __dom_wrap(_this.webkitNotifications);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__get__webkitURL(_this) {
  try {
    return __dom_wrap(_this.webkitURL);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__clearInterval(_this) {
  try {
    return __dom_wrap(_this.clearInterval());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__clearInterval_2(_this, handle) {
  try {
    return __dom_wrap(_this.clearInterval(__dom_unwrap(handle)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__clearTimeout(_this) {
  try {
    return __dom_wrap(_this.clearTimeout());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__clearTimeout_2(_this, handle) {
  try {
    return __dom_wrap(_this.clearTimeout(__dom_unwrap(handle)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__close(_this) {
  try {
    return __dom_wrap(_this.close());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__importScripts(_this) {
  try {
    return __dom_wrap(_this.importScripts());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__setInterval(_this, handler, timeout) {
  try {
    return __dom_wrap(_this.setInterval(__dom_unwrap(handler), __dom_unwrap(timeout)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerContextWrappingImplementation__setTimeout(_this, handler, timeout) {
  try {
    return __dom_wrap(_this.setTimeout(__dom_unwrap(handler), __dom_unwrap(timeout)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__get__hash(_this) {
  try {
    return __dom_wrap(_this.hash);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__get__host(_this) {
  try {
    return __dom_wrap(_this.host);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__get__hostname(_this) {
  try {
    return __dom_wrap(_this.hostname);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__get__href(_this) {
  try {
    return __dom_wrap(_this.href);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__get__pathname(_this) {
  try {
    return __dom_wrap(_this.pathname);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__get__port(_this) {
  try {
    return __dom_wrap(_this.port);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__get__protocol(_this) {
  try {
    return __dom_wrap(_this.protocol);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__get__search(_this) {
  try {
    return __dom_wrap(_this.search);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerLocationWrappingImplementation__toString(_this) {
  try {
    return __dom_wrap(_this.toString());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerNavigatorWrappingImplementation__get__appName(_this) {
  try {
    return __dom_wrap(_this.appName);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerNavigatorWrappingImplementation__get__appVersion(_this) {
  try {
    return __dom_wrap(_this.appVersion);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerNavigatorWrappingImplementation__get__onLine(_this) {
  try {
    return __dom_wrap(_this.onLine);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerNavigatorWrappingImplementation__get__platform(_this) {
  try {
    return __dom_wrap(_this.platform);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__WorkerNavigatorWrappingImplementation__get__userAgent(_this) {
  try {
    return __dom_wrap(_this.userAgent);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__onload(_this) {
  try {
    return __dom_wrap(_this.onload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__set__onload(_this, value) {
  try {
    _this.onload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__onloadstart(_this) {
  try {
    return __dom_wrap(_this.onloadstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__set__onloadstart(_this, value) {
  try {
    _this.onloadstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__onprogress(_this) {
  try {
    return __dom_wrap(_this.onprogress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__set__onprogress(_this, value) {
  try {
    _this.onprogress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__onreadystatechange(_this) {
  try {
    return __dom_wrap(_this.onreadystatechange);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__set__onreadystatechange(_this, value) {
  try {
    _this.onreadystatechange = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__readyState(_this) {
  try {
    return __dom_wrap(_this.readyState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__responseText(_this) {
  try {
    return __dom_wrap(_this.responseText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__responseType(_this) {
  try {
    return __dom_wrap(_this.responseType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__set__responseType(_this, value) {
  try {
    _this.responseType = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__responseXML(_this) {
  try {
    return __dom_wrap(_this.responseXML);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__status(_this) {
  try {
    return __dom_wrap(_this.status);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__statusText(_this) {
  try {
    return __dom_wrap(_this.statusText);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__upload(_this) {
  try {
    return __dom_wrap(_this.upload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__get__withCredentials(_this) {
  try {
    return __dom_wrap(_this.withCredentials);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__set__withCredentials(_this, value) {
  try {
    _this.withCredentials = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__abort(_this) {
  try {
    return __dom_wrap(_this.abort());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__getAllResponseHeaders(_this) {
  try {
    return __dom_wrap(_this.getAllResponseHeaders());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__getResponseHeader(_this, header) {
  try {
    return __dom_wrap(_this.getResponseHeader(__dom_unwrap(header)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__open(_this, method, url, async) {
  try {
    return __dom_wrap(_this.open(__dom_unwrap(method), __dom_unwrap(url), __dom_unwrap(async)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__open_2(_this, method, url, async, user) {
  try {
    return __dom_wrap(_this.open(__dom_unwrap(method), __dom_unwrap(url), __dom_unwrap(async), __dom_unwrap(user)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__open_3(_this, method, url, async, user, password) {
  try {
    return __dom_wrap(_this.open(__dom_unwrap(method), __dom_unwrap(url), __dom_unwrap(async), __dom_unwrap(user), __dom_unwrap(password)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__overrideMimeType(_this, mime) {
  try {
    return __dom_wrap(_this.overrideMimeType(__dom_unwrap(mime)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__send(_this) {
  try {
    return __dom_wrap(_this.send());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__send_2(_this, data) {
  try {
    return __dom_wrap(_this.send(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__send_3(_this, data) {
  try {
    return __dom_wrap(_this.send(__dom_unwrap(data)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestWrappingImplementation__setRequestHeader(_this, header, value) {
  try {
    return __dom_wrap(_this.setRequestHeader(__dom_unwrap(header), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestExceptionWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestProgressEventWrappingImplementation__get__position(_this) {
  try {
    return __dom_wrap(_this.position);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestProgressEventWrappingImplementation__get__totalSize(_this) {
  try {
    return __dom_wrap(_this.totalSize);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__get__onabort(_this) {
  try {
    return __dom_wrap(_this.onabort);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__set__onabort(_this, value) {
  try {
    _this.onabort = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__get__onerror(_this) {
  try {
    return __dom_wrap(_this.onerror);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__set__onerror(_this, value) {
  try {
    _this.onerror = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__get__onload(_this) {
  try {
    return __dom_wrap(_this.onload);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__set__onload(_this, value) {
  try {
    _this.onload = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__get__onloadstart(_this) {
  try {
    return __dom_wrap(_this.onloadstart);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__set__onloadstart(_this, value) {
  try {
    _this.onloadstart = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__get__onprogress(_this) {
  try {
    return __dom_wrap(_this.onprogress);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__set__onprogress(_this, value) {
  try {
    _this.onprogress = __dom_unwrap(value);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__addEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__addEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.addEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__dispatchEvent(_this, evt) {
  try {
    return __dom_wrap(_this.dispatchEvent(__dom_unwrap(evt)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__removeEventListener(_this, type, listener) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLHttpRequestUploadWrappingImplementation__removeEventListener_2(_this, type, listener, useCapture) {
  try {
    return __dom_wrap(_this.removeEventListener(__dom_unwrap(type), __dom_unwrap(listener), __dom_unwrap(useCapture)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLSerializerWrappingImplementation__serializeToString(_this) {
  try {
    return __dom_wrap(_this.serializeToString());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XMLSerializerWrappingImplementation__serializeToString_2(_this, node) {
  try {
    return __dom_wrap(_this.serializeToString(__dom_unwrap(node)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__createExpression(_this) {
  try {
    return __dom_wrap(_this.createExpression());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__createExpression_2(_this, expression) {
  try {
    return __dom_wrap(_this.createExpression(__dom_unwrap(expression)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__createExpression_3(_this, expression, resolver) {
  try {
    return __dom_wrap(_this.createExpression(__dom_unwrap(expression), __dom_unwrap(resolver)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__createNSResolver(_this) {
  try {
    return __dom_wrap(_this.createNSResolver());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__createNSResolver_2(_this, nodeResolver) {
  try {
    return __dom_wrap(_this.createNSResolver(__dom_unwrap(nodeResolver)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__evaluate(_this) {
  try {
    return __dom_wrap(_this.evaluate());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__evaluate_2(_this, expression) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(expression)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__evaluate_3(_this, expression, contextNode) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(expression), __dom_unwrap(contextNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__evaluate_4(_this, expression, contextNode, resolver) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(expression), __dom_unwrap(contextNode), __dom_unwrap(resolver)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__evaluate_5(_this, expression, contextNode, resolver, type) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(expression), __dom_unwrap(contextNode), __dom_unwrap(resolver), __dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathEvaluatorWrappingImplementation__evaluate_6(_this, expression, contextNode, resolver, type, inResult) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(expression), __dom_unwrap(contextNode), __dom_unwrap(resolver), __dom_unwrap(type), __dom_unwrap(inResult)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathExceptionWrappingImplementation__get__code(_this) {
  try {
    return __dom_wrap(_this.code);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathExceptionWrappingImplementation__get__message(_this) {
  try {
    return __dom_wrap(_this.message);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathExceptionWrappingImplementation__get__name(_this) {
  try {
    return __dom_wrap(_this.name);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathExpressionWrappingImplementation__evaluate(_this) {
  try {
    return __dom_wrap(_this.evaluate());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathExpressionWrappingImplementation__evaluate_2(_this, contextNode) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(contextNode)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathExpressionWrappingImplementation__evaluate_3(_this, contextNode, type) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(contextNode), __dom_unwrap(type)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathExpressionWrappingImplementation__evaluate_4(_this, contextNode, type, inResult) {
  try {
    return __dom_wrap(_this.evaluate(__dom_unwrap(contextNode), __dom_unwrap(type), __dom_unwrap(inResult)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathNSResolverWrappingImplementation__lookupNamespaceURI(_this) {
  try {
    return __dom_wrap(_this.lookupNamespaceURI());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathNSResolverWrappingImplementation__lookupNamespaceURI_2(_this, prefix) {
  try {
    return __dom_wrap(_this.lookupNamespaceURI(__dom_unwrap(prefix)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__get__booleanValue(_this) {
  try {
    return __dom_wrap(_this.booleanValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__get__invalidIteratorState(_this) {
  try {
    return __dom_wrap(_this.invalidIteratorState);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__get__numberValue(_this) {
  try {
    return __dom_wrap(_this.numberValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__get__resultType(_this) {
  try {
    return __dom_wrap(_this.resultType);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__get__singleNodeValue(_this) {
  try {
    return __dom_wrap(_this.singleNodeValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__get__snapshotLength(_this) {
  try {
    return __dom_wrap(_this.snapshotLength);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__get__stringValue(_this) {
  try {
    return __dom_wrap(_this.stringValue);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__iterateNext(_this) {
  try {
    return __dom_wrap(_this.iterateNext());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__snapshotItem(_this) {
  try {
    return __dom_wrap(_this.snapshotItem());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XPathResultWrappingImplementation__snapshotItem_2(_this, index) {
  try {
    return __dom_wrap(_this.snapshotItem(__dom_unwrap(index)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XSLTProcessorWrappingImplementation__clearParameters(_this) {
  try {
    return __dom_wrap(_this.clearParameters());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XSLTProcessorWrappingImplementation__getParameter(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.getParameter(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XSLTProcessorWrappingImplementation__importStylesheet(_this, stylesheet) {
  try {
    return __dom_wrap(_this.importStylesheet(__dom_unwrap(stylesheet)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XSLTProcessorWrappingImplementation__removeParameter(_this, namespaceURI, localName) {
  try {
    return __dom_wrap(_this.removeParameter(__dom_unwrap(namespaceURI), __dom_unwrap(localName)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XSLTProcessorWrappingImplementation__reset(_this) {
  try {
    return __dom_wrap(_this.reset());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XSLTProcessorWrappingImplementation__setParameter(_this, namespaceURI, localName, value) {
  try {
    return __dom_wrap(_this.setParameter(__dom_unwrap(namespaceURI), __dom_unwrap(localName), __dom_unwrap(value)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XSLTProcessorWrappingImplementation__transformToDocument(_this, source) {
  try {
    return __dom_wrap(_this.transformToDocument(__dom_unwrap(source)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__XSLTProcessorWrappingImplementation__transformToFragment(_this, source, docVal) {
  try {
    return __dom_wrap(_this.transformToFragment(__dom_unwrap(source), __dom_unwrap(docVal)));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}


function native__DOMWindowWrappingImplementation__createFileReader(_this) {
  try {
    return __dom_wrap(new FileReader());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__createWebKitCSSMatrix(_this, cssValue) {
  try {
    if (typeof cssValue === 'undefined')
      return __dom_wrap(new WebKitCSSMatrix());
    else
      return __dom_wrap(new WebKitCSSMatrix(cssValue));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__createWebKitPoint(_this, x, y) {
  try {
    return __dom_wrap(new WebKitPoint(x, y));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__createXMLHttpRequest(_this) {
  try {
    return __dom_wrap(new XMLHttpRequest());
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillStyle(_this, color_OR_gradient_OR_pattern) {
  try {
    _this.fillStyle = __dom_unwrap(color_OR_gradient_OR_pattern);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillStyle_2(_this, color_OR_gradient_OR_pattern) {
  try {
    _this.fillStyle = __dom_unwrap(color_OR_gradient_OR_pattern);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setFillStyle_3(_this, color_OR_gradient_OR_pattern) {
  try {
    _this.fillStyle = __dom_unwrap(color_OR_gradient_OR_pattern);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeStyle(_this, color_OR_gradient_OR_pattern) {
  try {
    _this.strokeStyle = __dom_unwrap(color_OR_gradient_OR_pattern);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeStyle_2(_this, color_OR_gradient_OR_pattern) {
  try {
    _this.strokeStyle = __dom_unwrap(color_OR_gradient_OR_pattern);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__CanvasRenderingContext2DWrappingImplementation__setStrokeStyle_3(_this, color_OR_gradient_OR_pattern) {
  try {
    _this.strokeStyle = __dom_unwrap(color_OR_gradient_OR_pattern);
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__get__localStorage(_this) {
  try {
    if (_this._dart_localStorage) return _this._dart_localStorage;
    var wrapper = new _StorageWrappingImplementation$Dart();
    wrapper._ptr$field = _this.localStorage;
    _this._dart_localStorage = wrapper;
    return wrapper;
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function native__DOMWindowWrappingImplementation__postMessage_2(_this, message, messagePort, targetOrigin) {
  try {
    if (targetOrigin == null)
      _this.postMessage(__dom_unwrap(message), __dom_unwrap(messagePort));
    else
      _this.postMessage(__dom_unwrap(message), __dom_unwrap(messagePort), __dom_unwrap(targetOrigin));
  } catch (e) {
    throw __dom_wrap_exception(e);
  }
}

function __dom_get_class_chrome(ptr) {
  var cls = ptr.constructor._dart_class;
  if (!cls) {
    var name = ptr.constructor.name;
    cls = window['_' + name + 'WrappingImplementation$Dart'];
    if (!cls) {
      return (void 0);
     }
    ptr.constructor._dart_class = cls;
   }
  return cls;
}

function __dom_get_class_generic(ptr) {
  if (ptr.__proto__.hasOwnProperty('_dart_class')) {
    return ptr.__proto__._dart_class;
  }
  var str = Object.prototype.toString.call(ptr);
  var name = str.substring(8, str.length - 1);
  if (name == 'global' || name == 'Window')
    name = 'DOMWindow';
  var cls = window['_' + name + 'WrappingImplementation$Dart'];
  ptr.__proto__._dart_class = cls;
  return cls;
}

var __dom_get_class = __dom_get_class_generic;
if (window.constructor.name == "DOMWindow") {
  __dom_get_class = __dom_get_class_chrome;
}

function __dom_wrap(ptr) {
  if (ptr == null) {
    return (void 0);
  }
  var type = typeof(ptr);
  if (type != "object" && type != "function") {
    return ptr;
  }
  if (ptr._dart) {
    return ptr._dart;
    // TODO: Should each isolate have its own wrapper object?  instance-of might
    // stop working if the cross-isolate wrapper is returned.
  }
  var cls = __dom_get_class(ptr);
  if (!cls) {
    return ptr;
  }
  var wrapper = new cls();
  wrapper._ptr$field = ptr;
  ptr._dart = wrapper;
  return wrapper;
}

function __dom_wrap_exception(e) {
  return __dom_wrap(e);
}

function __dom_wrap_primitive(ptr) {
  return (ptr === null) ? (void 0) : ptr;
}

function __dom_unwrap(obj) {
  if (obj == null) {
    return (void 0);
  }
  if (obj._ptr$field) {
    return obj._ptr$field;
  }
  if (obj instanceof Function) {  // BUGBUG: function from other IFrame
    var unwrapped = function () {
      var args = Array.prototype.slice.call(arguments);
      return obj.apply(this, args.map(__dom_wrap));
      // BUGBUG? Should the result be unwrapped? Or is it always void/bool ?
    };
    obj._ptr$field = unwrapped;
    unwrapped._dart = obj;
    return unwrapped;
  }
  return obj;
}

// Declared in src/GlobalProperties.dart
function native__NativeDomGlobalProperties_getWindow() {
  // TODO: Should the window be obtained from an isolate?
  return __dom_wrap(window);
}

// Declared in src/GlobalProperties.dart
function native__NativeDomGlobalProperties_getDocument() {
  // TODO: Should the window be obtained from an isolate?
  return __dom_wrap(window.document);
}
