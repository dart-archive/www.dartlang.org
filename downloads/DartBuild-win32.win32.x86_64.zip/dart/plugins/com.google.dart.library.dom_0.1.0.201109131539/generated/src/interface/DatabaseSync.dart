/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DatabaseSync {

  String get version();

  void changeVersion(String oldVersion, String newVersion, SQLTransactionSyncCallback callback = null);

  void readTransaction(SQLTransactionSyncCallback callback);

  void transaction(SQLTransactionSyncCallback callback);
}
