/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface Console {

  MemoryInfo get memory();

  void assert(bool condition);

  void count();

  void debug();

  void dir();

  void dirxml();

  void error();

  void group();

  void groupCollapsed();

  void groupEnd();

  void info();

  void log();

  void markTimeline();

  void time(String title = null);

  void timeEnd(String title);

  void timeStamp();

  void trace();

  void warn();
}
