/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface BeforeProcessEvent extends Event {

  String get text();

  void set text(String value);

  void initBeforeProcessEvent(String type = null, bool canBubble = null, bool cancelable = null);
}
