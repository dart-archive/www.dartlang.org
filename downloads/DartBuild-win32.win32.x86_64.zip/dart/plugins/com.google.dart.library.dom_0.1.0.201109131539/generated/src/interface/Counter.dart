/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface Counter {

  String get identifier();

  String get listStyle();

  String get separator();
}
