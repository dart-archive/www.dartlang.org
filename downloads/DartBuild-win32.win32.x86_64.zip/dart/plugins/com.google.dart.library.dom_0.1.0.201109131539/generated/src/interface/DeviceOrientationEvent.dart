/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DeviceOrientationEvent extends Event {

  num get alpha();

  num get beta();

  num get gamma();

  void initDeviceOrientationEvent(String type = null, bool bubbles = null, bool cancelable = null, num alpha = null, num beta = null, num gamma = null);
}
