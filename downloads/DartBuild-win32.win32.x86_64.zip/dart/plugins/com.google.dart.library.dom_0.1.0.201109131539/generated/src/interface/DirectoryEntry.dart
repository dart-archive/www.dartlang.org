/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DirectoryEntry extends Entry {

  DirectoryReader createReader();

  void getDirectory(String path, WebKitFlags flags = null, EntryCallback successCallback = null, ErrorCallback errorCallback = null);

  void getFile(String path, WebKitFlags flags = null, EntryCallback successCallback = null, ErrorCallback errorCallback = null);

  void removeRecursively(VoidCallback successCallback = null, ErrorCallback errorCallback = null);
}
