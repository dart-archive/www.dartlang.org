/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface WebKitAnimationEvent extends Event {

  String get animationName();

  num get elapsedTime();

  void initWebKitAnimationEvent(String typeArg = null, bool canBubbleArg = null, bool cancelableArg = null, String animationNameArg = null, num elapsedTimeArg = null);
}
