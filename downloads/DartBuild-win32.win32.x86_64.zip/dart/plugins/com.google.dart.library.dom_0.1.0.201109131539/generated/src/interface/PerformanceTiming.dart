/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface PerformanceTiming {

  int get connectEnd();

  int get connectStart();

  int get domComplete();

  int get domContentLoadedEventEnd();

  int get domContentLoadedEventStart();

  int get domInteractive();

  int get domLoading();

  int get domainLookupEnd();

  int get domainLookupStart();

  int get fetchStart();

  int get loadEventEnd();

  int get loadEventStart();

  int get navigationStart();

  int get redirectEnd();

  int get redirectStart();

  int get requestStart();

  int get responseEnd();

  int get responseStart();

  int get secureConnectionStart();

  int get unloadEventEnd();

  int get unloadEventStart();
}
