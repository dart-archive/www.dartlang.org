/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DOMTokenList {

  int get length();

  void add(String token);

  bool contains(String token);

  String item(int index);

  void remove(String token);

  bool toggle(String token);
}
