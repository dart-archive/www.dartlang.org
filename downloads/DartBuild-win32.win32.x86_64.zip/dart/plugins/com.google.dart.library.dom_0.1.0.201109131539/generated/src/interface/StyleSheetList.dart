/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface StyleSheetList extends Array<StyleSheet> {

  int get length();

  StyleSheet item(int index = null);
}
