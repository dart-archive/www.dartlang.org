/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface HTMLIsIndexElement extends HTMLInputElement {

  HTMLFormElement get form();

  String get prompt();

  void set prompt(String value);
}
