/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface ErrorEvent extends Event {

  String get filename();

  int get lineno();

  String get message();

  void initErrorEvent(String typeArg = null, bool canBubbleArg = null, bool cancelableArg = null, String messageArg = null, String filenameArg = null, int linenoArg = null);
}
