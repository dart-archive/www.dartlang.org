/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DocumentType extends Node {

  NamedNodeMap get entities();

  String get internalSubset();

  String get name();

  NamedNodeMap get notations();

  String get publicId();

  String get systemId();
}
