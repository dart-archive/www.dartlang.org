/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface CSSStyleDeclaration {

  String get cssText();

  void set cssText(String value);

  int get length();

  CSSRule get parentRule();

  CSSValue getPropertyCSSValue(String propertyName = null);

  String getPropertyPriority(String propertyName = null);

  String getPropertyShorthand(String propertyName = null);

  String getPropertyValue(String propertyName = null);

  bool isPropertyImplicit(String propertyName = null);

  String item(int index = null);

  String removeProperty(String propertyName = null);

  void setProperty(String propertyName = null, String value = null, String priority = null);
}
