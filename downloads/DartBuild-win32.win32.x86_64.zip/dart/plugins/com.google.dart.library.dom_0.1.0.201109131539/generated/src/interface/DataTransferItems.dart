/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface DataTransferItems {

  int get length();

  void add(String data = null, String type = null);

  void clear();

  DataTransferItem item(int index);
}
