/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface WebKitBlobBuilder {

  void append(WebKitBlobBuilder_Blob_OR_String blob_OR_value, String endings = null);

  Blob getBlob(String contentType = null);
}

interface WebKitBlobBuilder_Blob_OR_String {}
interface Blob extends WebKitBlobBuilder_Blob_OR_String;
interface String extends WebKitBlobBuilder_Blob_OR_String;
