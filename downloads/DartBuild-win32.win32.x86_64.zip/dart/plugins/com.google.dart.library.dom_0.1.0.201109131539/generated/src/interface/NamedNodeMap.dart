/*
 * Copyright (C) 2011 Google Inc. All rights reserved
 *
 * License - TBD
 *
 * WARNING: Do not edit - generated code.
 */

interface NamedNodeMap extends Array<Node> {

  int get length();

  Node getNamedItem(String name = null);

  Node getNamedItemNS(String namespaceURI = null, String localName = null);

  Node item(int index = null);

  Node removeNamedItem(String name = null);

  Node removeNamedItemNS(String namespaceURI = null, String localName = null);

  Node setNamedItem(Node node = null);

  Node setNamedItemNS(Node node = null);
}
