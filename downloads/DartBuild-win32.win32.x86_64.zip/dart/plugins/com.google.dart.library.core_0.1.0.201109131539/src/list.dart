// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * The [List] interface is a linked collection of that can be manipulated
 * at both ends. A [List] gives access to its first and last entry. It can
 * be visited with [Collection.forEach], [Collection.forEachEntry]
 * or through an iterator.
 */
interface List<E> extends Collection<E>
    factory DoubleLinkedListImplementation<E> {

  List();

  /**
   * Creates a [List] that contains all elements of [other].
   */
  List.from(Iterable<E> other);

  /**
   * Removes and returns the first element of this list. Throws an
   * [EmptyListException] exception if this list is empty.
   */
  E removeFirst();

  /**
   * Removes and returns the last element of the list. Throws an
   * [EmptyListException] exception if this list is empty.
   */
  E removeLast();

  /**
   * Adds [value] at the beginning of the list.
   */
  void addFirst(E value);

  /**
   * Adds [value] at the end of the list.
   */
  void addLast(E value);

  /**
   * Adds [value] at the end of the list.
   */
  void add(E value);

  /**
   * Adds all elements of [collection] at the end of the list. The
   * length of the list is extended by the length of [collection].
   */
  void addAll(Collection<E> collection);

  /**
   * Returns the first element of the list. Throws an
   * [EmptyListException] exception if this list is empty.
   */
  E first();

  /**
   * Returns the last element of the list. Throws an
   * [EmptyListException] exception if this list is empty.
   */
  E last();

  /**
   * Applies the function f to each entry in the list.
   */
  void forEachEntry(void f(ListEntry<E> entry));

  /**
   * Returns the last entry in the list, or null if the list has no
   * entry.
   */
  ListEntry<E> lastEntry();

  /**
   * Returns the first entry in the list, or null if the list has no
   * entry.
   */
  ListEntry<E> firstEntry();

  /**
   * Removes all elements in the list. The size of the list becomes
   * zero.
   */
  void clear();
}


/**
 * An entry in a list. An entry boxes an element and has access
 * to the next entry in the list.
 */
interface ListEntry<E> {
  /**
   * The element that this entry boxes.
   */
  E element;

  /**
   * Returns the next list entry pointed to by this entry.
   */
  ListEntry<E> nextEntry();
}
