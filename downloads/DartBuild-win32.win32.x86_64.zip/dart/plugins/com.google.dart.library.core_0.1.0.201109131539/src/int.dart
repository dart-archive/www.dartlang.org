// Copyright 2011 Google Inc. All Rights Reserved.
// Dart core library.

interface int extends num {
  // Bit-operations.
  int operator &(int other);
  int operator |(int other);
  int operator ^(int other);
  int operator ~();
  int operator <<(int shiftAmount);
  int operator >>(int shiftAmount);

  // Specializations of super-interface.
  int operator negate();
  int abs();
  int round();
  int floor();
  int ceil();
  int truncate();
}
