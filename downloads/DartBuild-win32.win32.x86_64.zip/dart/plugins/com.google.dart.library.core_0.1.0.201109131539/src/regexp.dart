// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * The regular expression API in Dart is divided in two classes:
 * RegExp and Match.
 *    - The RegExp class represents a regular expression.
 *    - The Match interface contains methods to manipulate a regular
 *      expression match.
 *
 * RegExp.firstMatch is the main implementation method that applies a
 * regular expression to a string and returns the first match. All
 * other methods in RegExp can build on it.
 *
 * Use [RegExp.allMatches] to look for all matches of a
 * regular expression in a string:
 *
 * [:
 *    RegExp exp = const RegExp(@"(\w+)", "");
 *    String str = "Parse my string";
 *    Collection<Match> matches = exp.allMatches(str, exp);
 *    matches.forEach(function(Match m) {
 *      String match = m.group(0);
 *      println(match);
 *    });
 * :]
 *
 * The output of the version above is:
 *    Parse
 *    my
 *    string
 */

interface Match {
  /**
   * Returns the index in the string where the given [group] starts.
   */
  int start(int group);

  /**
   * Returns the index in the string after the last character matched
   * for the given [group].
   */
  int end(int group);

  /**
   * Returns the string matched by the given [group]. If [group] is 0,
   * returns the match of the regular expression.
   */
  String group(int group);
  String operator [](int group);

  /**
   * Returns the strings matched by [groups]. The order in the
   * returned string follows the order in [groups].
   */
  Array<String> groups(Array<int> groups);

  /**
   * Returns the string matched by the given group name. If
   * [groupName] is null, returns the match of the regular expression.
   */
  String match(String groupName);

  /**
   * Returns the strings matched by [groupNames]. The order in the
   * returned string follows the order in [groupNames].
   */
  Array<String> matches(Array<String> groupNames);

  /**
   * Returns the number of groups in the regular expression.
   */
  int groupCount();

  /**
   * The string on which this matcher was computed.
   */
  final String str;

  /**
   * The regular expression to search for in [str].
   */
  final RegExp regexp;
}


interface RegExp extends Pattern factory JSSyntaxRegExp {

  /**
   * Constructs a regular expression.
   */
  const RegExp(String pattern, String flags);

  /**
   * Searches for the first match of the regular expression
   * in the string [str]. Returns [:null:] if there is no match.
   */
  Match firstMatch(String str);

  /**
   * Returns an ordered collection of matches of the regular
   * expression in [str]. The order in the collection is the
   * order of the matches found in [str]. For regular expressions
   * without the global flag the collection contains at most
   * one [Match].
   *
   * Note that calling [Collection.getCount] on the returned
   * collection forces all matches to be eagerly computed.
   */
  Collection<Match> allMatches(String str);

  /**
   * Returns whether the regular expression has a match in the string [str].
   */
  bool hasMatch(String str);

  /**
   * Searches for the first match of the regular expression
   * in the string [str] and returns the matched string.
   */
  String stringMatch(String str);

  /**
   * The pattern of this regular expression.
   */
  final String pattern;

  /**
   * The flags for this regular expression.
   */
  final String flags;
}
