// Copyright 2011 Google Inc. All Rights Reserved.
// Exceptions are thrown either by the VM or from Dart code.

/**
 * Interface implemented by all core library exceptions.
 */
interface Exception {
}


/**
 * Exception thrown because of an index outside of the valid range.
 */
class IndexOutOfRangeException implements Exception {
  const IndexOutOfRangeException(int this._index);

  String toString() {
    return "IndexOutOfRangeException: $_index";
  }

  final int _index;
}


/**
 * Exception thrown because of attempt to modify an immutable object.
 */
class IllegalAccessException implements Exception {
  const IllegalAccessException();

  String toString() {
    return "Attempt to modify an immutable object";
  }
}


/**
 * Exception thrown because of non-existing receiver's method.
 */
class NoSuchMethodException implements Exception {
  const NoSuchMethodException(Object this._receiver,
                              String this._functionName,
                              Array this._arguments);

  String toString() {
    String s = "NoSuchMethodException - receiver: '${_receiver}' " +
        "function name: '${_functionName}' arguments: [";
    for (int i = 0; i < _arguments.length; i++) {
      if (i > 0) {
        s += ", ";
      }
      s += _arguments[i].toString();
    }
    return s + "]";
  }

  final Object _receiver;
  final String _functionName;
  final Array _arguments;
}


class ClosureArgumentMismatchException implements Exception {
  const ClosureArgumentMismatchException();
  String toString() {
    return "Closure argument mismatch";
  }
}


class ObjectNotClosureException implements Exception {
  const ObjectNotClosureException();
  String toString() {
    return "Object is not closure";
  }
}


class IllegalArgumentException implements Exception {
  const IllegalArgumentException(...args) : this._args = args;
  String toString() {
    return "Illegal argument(s): $_args";
  }
  final Array _args;
}


class OutOfMemoryException implements Exception {
  const OutOfMemoryException();
  String toString() {
    return "Out of Memory";
  }
}


class StackOverflowException implements Exception {
  const StackOverflowException();
  String toString() {
    return "Stack Overflow";
  }
}


class BadNumberFormatException implements Exception {
  const BadNumberFormatException(String this._s);
  String toString() {
    return "BadNumberFormatException: '${_s}'";
  }
  final String _s;
}


class WrongArgumentCountException implements Exception {
  const WrongArgumentCountException();
  String toString() {
    return "WrongArgumentCountException";
  }
}


class NullPointerException implements Exception {
  const NullPointerException();
  String toString() {
    return "NullPointerException";
  }
}


class NoMoreElementsException implements Exception {
  const NoMoreElementsException();
  String toString() {
    return "NoMoreElementsException";
  }
}

class EmptyListException implements Exception {
  const EmptyListException();
  String toString() {
    return "EmptyListException";
  }
}

class UnsupportedOperationException implements Exception {
  const UnsupportedOperationException(String this._message);
  String toString() {
    return "UnsupportedOperationException: $_message";
  }
  final String _message;
}


class IllegalJSRegExpException implements Exception {
  const IllegalJSRegExpException(String this._pattern, String this._errmsg);
  String toString() {
    return "IllegalJSRegExpException: '${_pattern}' '${_errmsg}'";
  }
  final String _pattern;
  final String _errmsg;
}


class IntegerDivisionByZeroException implements Exception {
  const IntegerDivisionByZeroException();
  String toString() {
    return "IntegerDivisionByZeroException";
  }
}
