// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * This class represents a pair of two objects, used by LinkedHashMap
 * to store a {key, value} in a list.
 */
class KeyValuePair<K, V> {
  KeyValuePair(this.key, this.value) {}

  final K key;
  V value;
}

/**
 * A LinkedHashMap is a hash map that preserves the insertion order
 * when iterating over the keys or the values. Updating the value of a
 * key does not change the order.
 */
class LinkedHashMap<K extends Hashable, V> implements Map<K, V> {
  DoubleLinkedList<KeyValuePair<K, V>> list_;
  HashMap<K, DoubleLinkedListEntry<KeyValuePair<K, V>>> map_;

  LinkedHashMap() {
    map_ = new HashMap<K, DoubleLinkedListEntry<KeyValuePair<K, V>>>();
    list_ = new DoubleLinkedList<KeyValuePair<K, V>>();
  }

  void operator []=(K key, V value) {
    if (map_.containsKey(key)) {
      map_[key].element.value = value;
    } else {
      list_.addLast(new KeyValuePair<K, V>(key, value));
      map_[key] = list_.lastEntry();
    }
  }

  V operator [](K key) {
    DoubleLinkedListEntry<KeyValuePair<K, V>> entry = map_[key];
    if (entry === null) return null;
    return entry.element.value;
  }

  V remove(K key) {
    DoubleLinkedListEntry<KeyValuePair<K, V>> entry = map_.remove(key);
    if (entry === null) return null;
    entry.remove();
    return entry.element.value;
  }

  V putIfAbsent(K key, V ifAbsent()) {
    V value = this[key];
    if ((this[key] === null) && !(containsKey(key))) {
      value = ifAbsent();
      this[key] = value;
    }
    return value;
  }

  Collection<K> getKeys() {
    Array<K> array = new Array<K>(length);
    int index = 0;
    list_.forEach(void _(KeyValuePair<K, V> entry) {
      array[index++] = entry.key;
    });
    assert(index == length);
    return array;
  }


  Collection<V> getValues() {
    Array<V> array = new Array<V>(length);
    int index = 0;
    list_.forEach(void _(KeyValuePair<K, V> entry) {
      array[index++] = entry.value;
    });
    assert(index == length);
    return array;
  }

  void forEach(void f(K key, V value)) {
    list_.forEach(void _(KeyValuePair<K, V> entry) {
      f(entry.key, entry.value);
    });
  }

  bool containsKey(K key) {
    return map_.containsKey(key);
  }

  bool containsValue(V value) {
    return list_.some(bool _(KeyValuePair<K, V> entry) {
      return (entry.value == value);
    });
  }

  int get length() {
    return map_.length;
  }

  bool isEmpty() {
    return length == 0;
  }

  void clear() {
    map_.clear();
    list_.clear();
  }
}
