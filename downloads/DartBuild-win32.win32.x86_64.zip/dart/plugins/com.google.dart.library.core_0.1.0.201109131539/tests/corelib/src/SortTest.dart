// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test for sort routines.
// VMOptions=--expose_core_impl
// DartOptions=-- corelib/tests/corelib/src/SortHelper.dart corelib/tests/corelib/src/SortTest.dart -- SortTest.testMain

class SortTest {

  static void testMain() {
    var compare = (a, b) => a.compareTo(b);
    var sort = (array) => DualPivotQuicksort.sort(array, compare);
    new SortHelper(sort, compare).run();

    compare = (a, b) => -a.compareTo(b);
    new SortHelper(sort, compare).run();
  }
}

main() {
  SortTest.testMain();
}
