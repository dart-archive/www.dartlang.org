// Copyright 2011 Google Inc. All Rights Reserved.
// Dart test for spread expression on an expandable array.

class GrowableArraySpreadTest {

  static Array<int> array;

  static void testMain() {
    array = new Array<int>();
    array.add(1);
    array.add(2);

    // Test that we can call a method with a spread expression.
    foo(...array);

    // Test that we can call a constructor with a spread expression.
    var sup = new Sup.one(...array);
    Expect.equals(array[0], sup.a);
    Expect.equals(array[1], sup.b);

    // Test that initializers get the arguments right.
    var sub = new Sub.two(...array);
    Expect.equals(array[0], sub.a);
    Expect.equals(array[1], sub.b);

    // Test that we can call a super constructor with a spread
    // expression.
    sub = new Sub.one(array[0], array[1]);
    Expect.equals(array[0], sub.a);
    Expect.equals(array[1], sub.b);
  }

  static void foo(...arg) {
    Expect.equals(array[0], arg[0]);
    Expect.equals(array[1], arg[1]);
  }
}

class Sup {
  Sup.one(...arr) : a = arr[0], b = arr[1] {}
  Sup.two(this.a, this.b) {}
  final int a;
  final int b;
}

class Sub extends Sup {
  Sub.one(...a) : super.one(...a) {}
  Sub.two(...a) : super.two(a[0], a[1]) {}
}

main() {
  GrowableArraySpreadTest.testMain();
}
