// Copyright 2011 Google Inc. All Rights Reserved.

// IsolateStubs=MintMakerPromiseWithStubsTest.dart:Mint,Purse

interface Mint factory MintImpl {

  Mint();

  Purse createPurse(int balance);

}

interface Purse factory PurseImpl {

  Purse();

  int queryBalance();
  Purse sproutPurse();
  void deposit(int amount, Purse$Proxy source);

}

class MintImpl implements Mint {

  MintImpl() { }

  Purse createPurse(int balance) {
    return new PurseImpl(this, balance);
  }

}

class PurseImpl implements Purse {

  PurseImpl(this._mint, this._balance) { }

  int queryBalance() {
    return _balance;
  }

  Purse sproutPurse() {
    return _mint.createPurse(0);
  }

  void deposit(int amount, Purse$Proxy proxy) {
    PurseImpl source = proxy.local;
    if (source._balance < amount) throw "Not enough dough.";
    _balance += amount;
    source._balance -= amount;
  }

  Mint _mint;
  int _balance;

}

class MintMakerPromiseWithStubsTest {

  static void testMain() {
    Mint$Proxy mint = new Mint$ProxyImpl.createIsolate();
    Purse$Proxy purse = mint.createPurse(100);
    expectEquals(100, purse.queryBalance());

    Purse$Proxy sprouted = purse.sproutPurse();
    expectEquals(0, sprouted.queryBalance());

    sprouted.deposit(5, purse);
    expectEquals(0 + 5, sprouted.queryBalance());
    expectEquals(100 - 5, purse.queryBalance());

    sprouted.deposit(42, purse);
    expectEquals(0 + 5 + 42, sprouted.queryBalance());
    expectEquals(100 - 5 - 42, purse.queryBalance());

    expectDone(6);
  }

  static Array<Promise> results;

  static void expectEquals(int expected, Promise<int> promise) {
    if (results === null) {
      results = new Array<Promise>();
    }
    results.add(promise.then((int actual) {
      Expect.equals(expected, actual);
    }));
  }

  static void expectDone(int n) {
    if (results === null) {
      Expect.equals(0, n);
    } else {
      Promise done = new Promise();
      done.waitFor(results, results.length);
      done.then((ignored) {
        Expect.equals(n, results.length);
      });
    }
  }

}

main() {
  MintMakerPromiseWithStubsTest.testMain();
}
