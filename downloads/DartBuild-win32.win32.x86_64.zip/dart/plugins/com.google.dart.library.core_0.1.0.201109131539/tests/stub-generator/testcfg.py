# Copyright 2010 Google Inc. All Rights Reserved.

import os
import re
import shutil
import tempfile
import test
import testing
import utils

from os.path import join, exists, isdir

class DartStubTestCase(testing.StandardTestCase):
  def __init__(self, context, path, filename, mode, arch):
    super(DartStubTestCase, self).__init__(context, path, filename, mode, arch)
    self.filename = filename
    self.mode = mode
    self.arch = arch

  def GetStubs(self):
    source = self.GetSource()
    stub_classes = utils.ParseTestOptions(test.ISOLATE_STUB_PATTERN, source,
                                          self.context.workspace)
    (interface, _, classes) = stub_classes[0].partition(':')
    (interface, _, implementation) = interface.partition('+')
    return (interface, classes, implementation)

  def BeforeRun(self):
    command = self.context.GetDartC(self.mode, 'dartc')
    (interface, classes, _) = self.GetStubs()
    d = join(self.GetPath(), 'generated')
    if not isdir(d):
      os.mkdir(d)
    tmpdir = tempfile.mkdtemp()
    self.RunCommand(command + [ join(self.GetPath(), interface),
                                # dartc generates output even if it has no
                                # output to generate.
                                '-out', tmpdir,
                                '-isolate-stub-out', join(self.GetPath(),
                                                          'generated',
                                                          interface),
                                '-generate-isolate-stubs', classes ])
    shutil.rmtree(tmpdir)

  def GetCommand(self):
    # Parse the options by reading the .dart source file.
    source = self.GetSource()
    vm_options = utils.ParseTestOptions(test.VM_OPTIONS_PATTERN, source,
                                        self.context.workspace)
    dart_options = utils.ParseTestOptions(test.DART_OPTIONS_PATTERN, source,
                                          self.context.workspace)
    (interface, _, implementation) = self.GetStubs()

    # Combine everything into a command array and return it.
    command = self.context.GetDart(self.mode, self.arch)
    files = [ self.filename ]
    files += [ join(self.GetPath(), interface),
               join(self.GetPath(), 'generated', interface) ]
    if implementation != '':
      files += [ join(self.GetPath(), implementation) ]
    if vm_options: command += vm_options
    if dart_options: command += dart_options
    else: command += [ '--' ] + \
                     files + \
                     [ '--',
                       self.GetName() + ".testMain" ]
    return command


class DartStubTestConfiguration(testing.StandardTestConfiguration):
  def __init__(self, context, root):
    super(DartStubTestConfiguration, self).__init__(context, root)

  def ListTests(self, current_path, path, mode, arch):
    tests = []
    for root, dirs, files in os.walk(join(self.root, 'src')):
      if root[-9:] == 'generated':
        continue
      for f in [x for x in files if self.IsTest(x)]:
        test_path = current_path + [ f[:-5] ]  # Remove .dart suffix.
        if not self.Contains(path, test_path):
          continue
        tests.append(DartStubTestCase(self.context,
                                      test_path,
                                      join(root, f),
                                      mode,
                                      arch))
    return tests


def GetConfiguration(context, root):
  return DartStubTestConfiguration(context, root)
