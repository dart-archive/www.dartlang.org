// Copyright 2011 Google Inc. All Rights Reserved.

// TODO(ngeoffray): define native top-level methods once top-level
// methods work with the resolver.
typedef void _PrintType(...args);

_PrintType get print() {
  return _Logger.print;
}

_PrintType get println() {
  return _Logger.println;
}

class _Logger {
  static print(...args) {
    StringBuffer sb = new StringBuffer();
    for (final o in args) {
      sb.add(o);
    }
    native_print(sb.toString());
  }

  static println(...args) {
    print(...args);
    native_print('\n');
  }

  static void native_print(str) native;
}
