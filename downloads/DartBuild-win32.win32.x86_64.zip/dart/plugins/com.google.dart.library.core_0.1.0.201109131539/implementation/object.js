// Copyright 2011 Google Inc. All Rights Reserved.

Object.$instanceOf = function(obj) {
  return true;
};
