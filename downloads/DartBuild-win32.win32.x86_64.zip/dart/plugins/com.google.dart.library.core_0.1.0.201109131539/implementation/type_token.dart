// Copyright 2011 Google Inc. All Rights Reserved.

/*
 * This class is generic. It's main use is to transfer type information from
 * Dart to JS.
 */
class TypeToken<T> {
  const TypeToken();
}
