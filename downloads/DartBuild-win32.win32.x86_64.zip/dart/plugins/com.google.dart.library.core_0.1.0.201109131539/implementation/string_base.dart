// Copyright 2011 Google Inc. All Rights Reserved.

class StringBase {
  static String createFromCharCodes(Array<int> charCodes) native;

  static String join(Array<String> strings, String separator) {
    String s = "";
    for (int i = 0; i < strings.length; i++) {
      if (i > 0) {
        s = s.concat(separator);
      }
      s = s.concat(strings[i]);
    }
    return s;
  }

  static String concatAll(Array<String> strings) {
    return join(strings, "");
  }

}
