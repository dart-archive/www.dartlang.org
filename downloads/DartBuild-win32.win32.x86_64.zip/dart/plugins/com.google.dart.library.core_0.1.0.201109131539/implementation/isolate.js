// Copyright 2011 Google Inc. All Rights Reserved.

var isolate$current = null;
var isolate$rootIsolate = null;  // Will only be set in the main worker.
var isolate$inits = [];
var isolate$globalThis = this;

// These declarations are needed to avoid errors from the Closure Compiler
// optimizer. They are defined in client/dom/generated/dart_dom_wrapping.js.
var __dom_wrap;
var __dom_unwrap;

var isolate$inWorker =
    (typeof isolate$globalThis['importScripts']) != "undefined";
var isolate$supportsWorkers =
    isolate$inWorker || ((typeof isolate$globalThis['Worker']) != 'undefined');

var isolate$MAIN_WORKER_ID = 0;
// Non-main workers will update the id variable.
var isolate$thisWorkerId = isolate$MAIN_WORKER_ID;

// Whether to use web workers when implementing isolates.
var isolate$useWorkers = isolate$supportsWorkers;
// Uncomment this to not use web workers even if they're available.
//   isolate$useWorkers = false;

// Whether to use the web-worker JSON-based message serialization protocol,
// even if not using web workers.
var isolate$useWorkerSerializationProtocol = false;
// Uncomment this to always use the web-worker JSON-based message
// serialization protocol, e.g. for testing purposes.
//   isolate$useWorkerSerializationProtocol = true;


// ------- SendPort -------
function isolate$SendPort(token, workerId) {
  this.token = token;
  this.workerId = workerId;
}
isolate$SendPort.prototype = new SendPortImpl$Dart();
isolate$SendPort.prototype.send = function(message, replyTo) {
  if (this.workerId == isolate$thisWorkerId) {
    var receivePort = isolate$getReceivePortForToken(this.token);
    isolate$receiveMessage(receivePort, message, replyTo);
  } else {
    var worker = isolate$getWorkerForId(this.workerId);
    worker.postMessage({ command: 'message',
                         port: this.token,
                         msg: message,
                         replyTo: isolate$serializeMessage(replyTo) });
  }
};

isolate$SendPort.prototype.hashCode = function() {
  return (this.workerId << 16) ^ ((this.token * 0x0fffffff) >>> 0);
};

function isolate$receiveMessage(port, message, replyTo) {
  // If no port has been given assume that it has been closed.
  if (!port) return;
  message = isolate$deserializeMessage(message);
  isolate$IsolateEvent.enqueue(port.isolate, function() {
    var callback = port.callback;
    if (callback) callback(message, replyTo);
    native__IsolateJsUtil__promiseQueueProcess();
  });
};

// ------- ReceivePort -------
function isolate$ReceivePort(token) {
  this.isolate = isolate$current;
  // Each Port has a token that uniquely identifies it. For now just use
  // Math.random() to generate this token.
  // TODO(floitsch): don't rely on Math.random to generate unique ids.
  if (!token) token = Math.random();
  this.token = token;
  this.callback = $Dart$Null;
  isolate$registerReceivePort(token, this);
}

isolate$ReceivePort.prototype = new ReceivePortImpl$Dart();
isolate$ReceivePort.prototype.toSendPort = function() {
  return new isolate$SendPort(this.token, isolate$thisWorkerId);
};
isolate$ReceivePort.prototype.close = function() {
  this.callback = $Dart$Null;
  isolate$unregisterReceivePort(this.token);
};

// ------- Worker Port-registry -------
var isolate$receivePortRegistry = { count: 0 };

function isolate$hasOpenReceivePorts() {
  return isolate$receivePortRegistry.count != 0;
}

function isolate$registerReceivePort(token, port) {
  isolate$receivePortRegistry[token] = port;
  isolate$receivePortRegistry.count++;
}

function isolate$unregisterReceivePort(token) {
  var port = isolate$receivePortRegistry[token];
  if (port) {
    delete isolate$receivePortRegistry[token];
    isolate$receivePortRegistry.count--;
  }
}

function isolate$getReceivePortForToken(token) {
  return isolate$receivePortRegistry[token];
}

// ------- Worker registry -------
// Only used in the main worker.
var isolate$workerRegistry = { count: 0 };

function isolate$hasRunningWorkers() {
  return isolate$workerRegistry.count != 0;
}

function isolate$registerWorker(id, worker) {
  isolate$workerRegistry[id] = worker;
  isolate$workerRegistry.count++;
}

function isolate$unregisterWorker(id) {
  delete isolate$workerRegistry[id];
  isolate$workerRegistry.count--;
}

function isolate$getWorkerForId(id) {
  return isolate$workerRegistry[id];
}

// ------- Debugging log function -------
function isolate$log(msg) {
  return;
  if (isolate$inWorker) {
    isolate$defaultWorker.postMessage({ command: 'log', msg: msg });
  } else {
    try {
      isolate$globalThis.console.log(msg);
    } catch(e) {
      throw String(e.stack);
    }
  }
}

function isolate$initializeWorker(workerId) {
  isolate$thisWorkerId = workerId;
  isolate$registerWorker(isolate$MAIN_WORKER_ID, isolate$defaultWorker);
}

// ------- Message handler -------
function isolate$processWorkerMessage(sender, e) {
  var msg = e.data;
  switch (msg.command) {
    case 'start':
      isolate$log("starting worker: " +
          msg.port + " " + msg.id + " " + msg.runner);
      isolate$initializeWorker(msg.id);
      var token = msg.port;
      var runnerObject = isolate$globalThis[msg.runner].default$factory();
      isolate$IsolateEvent.enqueue(new isolate$Isolate(), function() {
        var port = new isolate$ReceivePort(token);
        native__IsolateJsUtil__invokeRun(runnerObject, port);
      });
      isolate$runEventLoop();
      break;
    case 'message':
      // isolate$log("received msg: " + msg.port + " " + msg.msg + " " +
      //             msg.replyTo);
      var port = isolate$getReceivePortForToken(msg.port);
      var message = msg.msg;
      var replyTo = isolate$deserializeMessage(msg.replyTo);
      isolate$receiveMessage(port, message, replyTo);
      isolate$runEventLoop();
      break;
    case 'close':
      isolate$log("Closing Worker");
      isolate$unregisterWorker(sender.id);
      sender.terminate();
      isolate$runEventLoop();
      break;
    case 'log':
      isolate$log(msg.msg);
      break;
    case 'error':
      throw msg.msg;
      break;
  }
}

if (isolate$supportsWorkers) {
  isolate$globalThis.onmessage = function(e) {
    isolate$processWorkerMessage(isolate$defaultWorker, e);
  };
}

// ------- Default Worker -------
function isolate$DefaultWorker() {
  this.id = isolate$MAIN_WORKER_ID;
}

var isolate$defaultWorker = new isolate$DefaultWorker();
isolate$defaultWorker.postMessage = function(msg) {
  isolate$globalThis.postMessage(msg);
};

// Native methods for isolate functionality.
function isolate$Isolate() {
  this.run(function() {
    // The Dart-to-JavaScript compiler builds a list of functions that
    // need to run for each isolate to setup the state of static
    // variables. Run through the list and execute each function.
    for (var i = 0, len = isolate$inits.length; i < len; i++) {
      isolate$inits[i]();
    }
  });
}

isolate$Isolate.prototype.run = function(code) {
  var old = isolate$current;
  isolate$current = this;
  try {
    code();
  } finally {
    isolate$current = old;
  }
};

var isolate$events = [];

function isolate$IsolateEvent(isolate, fn) {
  this.isolate = isolate;
  this.fn = fn;
}

isolate$IsolateEvent.prototype.process = function() {
  this.isolate.run(this.fn);
};

isolate$IsolateEvent.enqueue = function(isolate, fn) {
  isolate$events.push(new isolate$IsolateEvent(isolate, fn));
};

isolate$IsolateEvent.dequeue = function() {
  if (isolate$events.length == 0) return $Dart$Null;
  var result = isolate$events[0];
  isolate$events.splice(0, 1);
  return result;
};

var isolate$lightCount = 0;
var isolate$heavyCount = 0;

function native_IsolateNatives_start(runnable, light) {
  // TODO(kasperl): Allow mixing heavy and light isolates.
  if (light) {
    isolate$lightCount++;
    if (isolate$heavyCount != 0) {
      throw Error("Cannot mix light and heavy isolates.");
    }
    isolate$useWorkers = false;
  } else {
    isolate$heavyCount++;
    if (isolate$lightCount != 0) {
      throw Error("Cannot mix light and heavy isolates.");
    }
  }

  // TODO(floitsch): throw exception if runnable's class doesn't have a
  // default constructor.
  if (isolate$useWorkers) {
    return isolate$startWorker(runnable);
  } else {
    return isolate$startNonWorker(runnable);
  }
}

function native_IsolateNatives_bind(fn) {
  var isolate = isolate$current;
  return function() {
    var self = this;
    var args = arguments;
    isolate.run(function() {
      fn.apply(self, args);
    });
    isolate$runEventLoop();
  };
}

var isolate$exitHandler = false;
function native_IsolateNatives_setExitHandler(handler) {
  if (handler) {
    if (isolate$inWorker || (isolate$current !== isolate$rootIsolate)) {
      throw Error("Exit handler must be registered in root isolate.");
    }
    isolate$exitHandler = { isolate: isolate$current, handler: handler };
  } else {
    isolate$exitHandler = false;
  }
}

function isolate$startNonWorker(runnable) {
  // Spawn a new isolate and create the receive port in it.
  var spawned = new isolate$Isolate();
  var port;
  spawned.run(function() { port = native_ReceivePortImpl_(); });

  // Instead of just running the provided runnable, we create a
  // new cloned instance of it with a fresh state in the spawned
  // isolate. This way, we do not get cross-isolate references
  // through the runnable.
  var constructor = runnable.constructor;
  isolate$IsolateEvent.enqueue(spawned, function() {
    native__IsolateJsUtil__invokeRun(constructor.default$factory(), port);
  });

  return native__IsolateJsUtil__toSendPort(port);
}

// This field is only used by the main worker.
var isolate$nextFreeWorkerId = isolate$thisWorkerId + 1;

function isolate$startWorker(runnable) {
  if (isolate$inWorker) {
    isolate$defaultWorker.postMessage("Unimplemented nested spawn.");
    throw "Unimplemented";
  }
  var constructor = runnable.constructor;
  var constructorName = constructor.name;
  var scripts = document.getElementsByTagName('script');
  var thisScript = scripts[scripts.length-1];
  var worker = new Worker(thisScript.src);
  worker.onmessage = function(e) {
    isolate$processWorkerMessage(worker, e);
  };
  var token = Math.random();
  var id = isolate$nextFreeWorkerId++;
  var port = new isolate$SendPort(token, id);
  // We also store the id on the worker itself so that we can unregister it.
  worker.id = id;
  isolate$registerWorker(id, worker);
  worker.postMessage({ command: 'start',
                       id: id,
                       runner: constructorName,
                       port: token });
  return port;
}

function native_SendPortImpl__sendNow(message, replyTo) {
  if (replyTo !== $Dart$Null && !(replyTo instanceof SendPortImpl$Dart)) {
    throw "SendPort::send: Illegal replyTo type.";
  }
  message = isolate$serializeMessage(message);
  this.send(message, replyTo);
}

function native_SendPortImpl_EQ(other) {
  return (other instanceof SendPortImpl$Dart) &&
      (this.token === other.token);
}

function native_SendPortImpl_hashCode() {
  return this.hashCode();
}

function native_ReceivePortImpl_() {
  return new isolate$ReceivePort();
}

function native_ReceivePortImpl_receive(callback) {
  this.callback = callback;
}

function native_ReceivePortImpl_close() {
  this.close();
}

function native_ReceivePortImpl_toSendPort() {
  return this.toSendPort();
}

function isolate$closeWorkerIfNecessary() {
  if (isolate$hasOpenReceivePorts()) return;
  isolate$defaultWorker.postMessage( { command: 'close' } );
}

function isolate$doOneEventLoopIteration() {
  var CONTINUE_LOOP = true;
  var STOP_LOOP = false;
  var event = isolate$IsolateEvent.dequeue();
  if (!event) {
    if (isolate$inWorker) {
      isolate$closeWorkerIfNecessary();
    } else if (isolate$exitHandler &&
               !isolate$hasOpenReceivePorts() &&
               !isolate$hasRunningWorkers()) {
      var handler = isolate$exitHandler.handler;
      // The given handler is a Dart function. We must go through the native
      // interface to invoke it.
      var f = function() {
        native__IsolateJsUtil__callDartFun0(handler);
      };
      isolate$IsolateEvent.enqueue(isolate$exitHandler.isolate, f);
      isolate$exitHandler = false;
      return CONTINUE_LOOP;
    }
    return STOP_LOOP;
  } else {
    event.process();
    return CONTINUE_LOOP;
  }
}

function isolate$doRunEventLoop() {
  if (typeof window != 'undefined' && window.setTimeout) {
    (function next() {
      var continueLoop = isolate$doOneEventLoopIteration();
      if (!continueLoop) return;
      // TODO(kasperl): It might turn out to be too expensive to call
      // setTimeout for every single event. This needs more investigation.
      window.setTimeout(next, 0);
    })();
  } else {
    while (true) {
      var continueLoop = isolate$doOneEventLoopIteration();
      if (!continueLoop) break;
    }
  }
}

function isolate$runEventLoop() {
  if (!isolate$inWorker) {
    isolate$doRunEventLoop();
  } else {
    try {
      isolate$doRunEventLoop();
    } catch(e) {
      // TODO(floitsch): try to send stack-trace to the other side.
      isolate$defaultWorker.postMessage({ command: 'error', msg: "" + e });
    }
  }
}

function RunEntry(entry, args) {
  // Don't start the main loop again, if we are in a worker.
  if (isolate$inWorker) return;
  var isolate = new isolate$Isolate();
  isolate$rootIsolate = isolate;
  isolate$IsolateEvent.enqueue(isolate, function() {
    entry(args);
  });
  isolate$runEventLoop();

  // BUG(5151491): This should not be necessary, but because closures
  // passed to the DOM as event handlers do not bind their isolate
  // automatically we try to give them a reasonable context to live in
  // by having a "default" isolate (the first one created).
  isolate$current = isolate;
}

// ------- Message Serializing and Deserializing -------

function isolate$serializeMessage(message) {
  if (isolate$useWorkers || isolate$useWorkerSerializationProtocol) {
    message = isolate$convertDartToJs(message);
  } else {
    message = isolate$copyObject(message);
  }
  return message;
}

function isolate$deserializeMessage(message) {
  if (isolate$useWorkers || isolate$useWorkerSerializationProtocol) {
    message = isolate$convertJsToDart(message);
  } else {
    // Nothing more to do.
  }
  return message;
}

// Returns a structural deep copy of the argument.  Validates that only
// scalars, arrays, maps, and ports are included.
function isolate$copyObject(obj) {
  var copy = isolate$copyObjectHelper(obj);
  isolate$postCopyObjectHelper(obj);
  return copy;
}

function isolate$copyObjectHelper(obj) {
  if (typeof obj == 'undefined' ||
      typeof obj == 'boolean' ||
      typeof obj == 'number' ||
      typeof obj == 'string') {
    return obj;
  } else if (obj instanceof Array) {
    return isolate$copyArray(obj);
  } else if (obj instanceof $Dart$MapLiteralType) {
    return isolate$copyMap(obj);
  } else if (obj instanceof SendPortImpl$Dart) {
    // Pass send ports through unchanged.
    return obj;
  } else if (obj instanceof ReceivePortImpl$Dart) {
    // Convert receive ports to send ports.
    return native__IsolateJsUtil__toSendPort(obj);
  } else if (obj == isolate$globalThis) {
    // As a special hack for initializing the DomWindow isolate, allow
    // the Window object to be passed through.
    // TODO(chambers): Remove this when we have a better solution.
    return obj;
  } else if (__dom_unwrap && (__dom_unwrap(obj) == isolate$globalThis)) {
    // Another hack for the wrapper DOM where the Dart Window != this.
    // TODO(vsm): Return the wrapper for the target isolate, not the
    // same wrapper.
    return obj;
  } else {
    throw 'SendPort::send: Illegal value ' + obj + ' passed.';
  }
}

function isolate$copyArray(arr) {
  var copy = isolate$lookupCopy(arr);
  if (copy) {
    // This array has already been copied.
    return copy;
  }
  var len = native__ArrayJsUtil__arrayLength(arr);
  copy = new native__ArrayJsUtil__newArray(len);
  isolate$rememberCopy(arr, copy);
  for (var i = 0; i < len; i++) {
    var elem = INDEX$operator(arr, i);
    elem = isolate$copyObjectHelper(elem);
    ASSIGN_INDEX$operator(copy, i, elem);
  }
  return copy;
}

function native__IsolateJsUtil__callJsFun2(fun, arg1, arg2) {
  return fun(arg1, arg2);
}

function isolate$copyMap(map) {
  var copy = isolate$lookupCopy(map);
  if (copy) {
    // This map has already been copied.
    return copy;
  }
  copy = $Dart$MapLiteralFactory();
  isolate$rememberCopy(map, copy);
  native__IsolateJsUtil__mapForEach(map, function(key, value) {
    key = isolate$copyObjectHelper(key);
    value = isolate$copyObjectHelper(value);
    ASSIGN_INDEX$operator(copy, key, value);
  });
  return copy;
}

// Cleans up the original object after finishing the deep copy.
function isolate$postCopyObjectHelper(obj) {
  if (obj instanceof Array) {
    isolate$postCopyArray(obj);
  } else if (obj instanceof $Dart$MapLiteralType) {
    isolate$postCopyMap(obj);
  }
}

function isolate$postCopyArray(arr) {
  var copy = isolate$lookupCopy(arr);
  if (!copy) {
    // This array and its subtrees have already been cleared.
    return;
  }
  isolate$clearCopy(arr);
  var len = native__ArrayJsUtil__arrayLength(arr);
  for (var i = 0; i < len; i++) {
    var elem = INDEX$operator(arr, i);
    isolate$postCopyObjectHelper(elem);
  }
}

function isolate$postCopyMap(map) {
  var copy = isolate$lookupCopy(map);
  if (!copy) {
    // This map and its subtrees have already been cleared.
    return;
  }
  isolate$clearCopy(map);
  native__IsolateJsUtil__mapForEach(map, function(key, value) {
    isolate$postCopyObjectHelper(key);
    isolate$postCopyObjectHelper(value);
  });
}

// To support sharing and cycles, we want to remember a map from
// object to its copy.  This is unpleasant in JavaScript.  So we use a
// magic field in each object to store its copy.  Look away.
function isolate$lookupCopy(obj) {
  return obj['__deep_copy__'];
}

function isolate$rememberCopy(obj, copy) {
  obj['__deep_copy__'] = copy;
}

function isolate$clearCopy(obj) {
  obj['__deep_copy__'] = void 0;  // Storing undefined approximates deleting it.
}

var isolate$uid = 1;

// Converts the Dart object into a JavaScript value that's legal JSON.
// Handles recursive structures.
function isolate$convertDartToJs(obj) {
  isolate$uid = 1;
  var copy = isolate$convertDartToJsHelper(obj);
  isolate$postCopyObjectHelper(obj);
  return copy;
}

function isolate$convertDartToJsHelper(obj) {
  if (obj === $Dart$Null) {
    return null;
  } else if (obj == null) {
    throw 'not expecting JS-null in a Dart object';
  } else if (typeof obj == 'boolean' ||
             typeof obj == 'number' ||
             typeof obj == 'string') {
    return obj;
  } else if (obj instanceof Array) {
    return isolate$convertDartArrayToJs(obj);
  } else if (obj instanceof $Dart$MapLiteralType) {
    return isolate$convertDartMapToJs(obj);
  } else if (obj instanceof SendPortImpl$Dart) {
    return isolate$convertDartPortToJs(obj);
  } else if (obj instanceof ReceivePortImpl$Dart) {
    // Convert receive ports to send ports.
    var sendPort = native__IsolateJsUtil__toSendPort(obj);
    return isolate$convertDartPortToJs(sendPort);
  } else if (obj == isolate$globalThis) {
    // As a special hack for initializing the DomWindow isolate, allow
    // the Window object to be passed through.
    // This won't work properly with real web workers.
    // TODO(chambers): Remove this when we have a better solution.
    return {window: 'the window'};
  } else if (__dom_unwrap && (__dom_unwrap(obj) == isolate$globalThis)) {
    return {window: 'the window'};
  } else {
    throw 'SendPort::send: Illegal value ' + obj + ' passed.';
  }
}

// Converts the Dart Array into a JavaScript array that's legal for
// converting to JSON.
function isolate$convertDartArrayToJs(arr) {
  var uid = isolate$lookupCopy(arr);
  if (uid) {
    // This object has already been copied.
    return {ref: uid};
  }
  uid = isolate$uid++;
  isolate$rememberCopy(arr, uid);
  var len = native__ArrayJsUtil__arrayLength(arr);
  var obj = new Array(len);
  for (var i = 0; i < len; i++) {
    var elemValue = INDEX$operator(arr, i);
    obj[i] = isolate$convertDartToJsHelper(elemValue);
  }
  return {uid: uid, array: obj};
}

// Converts the Dart Map into a JavaScript object that's legal for
// converting to JSON.
function isolate$convertDartMapToJs(map) {
  var uid = isolate$lookupCopy(map);
  if (uid) {
    // This object has already been copied.
    return {ref: uid};
  }
  uid = isolate$uid++;
  isolate$rememberCopy(map, uid);
  var keys = native__IsolateJsUtil__mapKeysAsArray(map);
  var len = native__ArrayJsUtil__arrayLength(keys);
  // Represent a Dart Map as an array of key/value pairs.
  var obj = new Array(len);
  for (var i = 0; i < len; i++) {
    var key = INDEX$operator(keys, i);
    var value = INDEX$operator(map, key);
    key = isolate$convertDartToJsHelper(key);
    value = isolate$convertDartToJsHelper(value);
    obj[i] = {key: key, value: value};
  }
  return {uid: uid, map: obj};
}

// Converts the Dart SendPort into a JavaScript object that's legal for
// converting to JSON.
// TODO(chambers): This assumes that web worker references can be
// passed in messages to other web workers.  Is that true?  If not,
// how can we support this?
function isolate$convertDartPortToJs(port) {
  return {port: port};
}

// Converts the JavaScript received by a web-worker into a Dart object, and
// returns the Dart object.
function isolate$convertJsToDart(obj) {
  var objTable = {};
  return isolate$convertJsToDartHelper(obj, objTable);
}

function isolate$convertJsToDartHelper(obj, objTable) {
  // The following kinds of Dart objects have the same representation in JS:
  //   boolean, number, string, arrays
  // Dart null is JS undefined.
  if (obj === null) {
    return $Dart$Null;
  } else if (obj === void 0) {
    throw 'unexpected kind of JSON value';
  } else if (typeof obj == 'boolean' ||
             typeof obj == 'number' ||
             typeof obj == 'string') {
    return obj;
  } else if (obj.ref) {
    var uid = obj.ref;
    var dartObj = objTable[uid];
    if (!dartObj) {
      throw 'dangling ref';
    }
    return dartObj;
  } else if (obj.array) {
    var jsArray = obj.array;
    var uid = obj.uid;
    if (!uid) {
      throw 'missing uid';
    }
    var dartArray = new Array(jsArray.length);
    objTable[uid] = dartArray;
    isolate$convertJsToDartArray(jsArray, dartArray, objTable);
    return dartArray;
  } else if (obj.map) {
    var jsObj = obj.map;
    var uid = obj.uid;
    if (!uid) {
      throw 'missing uid';
    }
    var dartMap = $Dart$MapLiteralFactory();
    objTable[uid] = dartMap;
    isolate$convertJsToDartMap(jsObj, dartMap, objTable);
    return dartMap;
  } else if (obj.port) {
    var jsPort = obj.port;
    var dartPort = isolate$convertJsToDartPort(jsPort, objTable);
    return dartPort;
  } else if (obj.window) {
    // As a special hack for initializing the DomWindow isolate, allow
    // the Window object to be passed through.
    // This won't work properly with real web workers.
    // TODO(chambers): Remove this when we have a better solution.
    if (__dom_wrap) {
      // TODO(vsm): Return the wrapper for the target isolate, not the
      // same wrapper.
      return __dom_wrap(isolate$globalThis);
    } else {
      return isolate$globalThis;
    }
  } else {
    throw 'unexpected kind of JSON value';
  }
}

// Converts the elements of the JavaScript Array into the Dart Array.
function isolate$convertJsToDartArray(jsArray, dartArray, objTable) {
  if (!(jsArray instanceof Array)) {
    throw 'unexpected JS representation of a Dart Array';
  }
  var len = jsArray.length;
  for (var i = 0; i < len; i++) {
    var value = jsArray[i];
    value = isolate$convertJsToDartHelper(value, objTable);
    ASSIGN_INDEX$operator(dartArray, i, value);
  }
}

// Converts the JavaScript Array of key/value pairs into the Dart Map.
function isolate$convertJsToDartMap(jsObj, dartMap, objTable) {
  if (!(jsObj instanceof Array)) {
    throw 'unexpected JS representation of a Dart Map';
  }
  var len = jsObj.length;
  for (var i = 0; i < len; i++) {
    var pair = jsObj[i];
    var key = pair.key;
    var value = pair.value;
    key = isolate$convertJsToDartHelper(key, objTable);
    value = isolate$convertJsToDartHelper(value, objTable);
    ASSIGN_INDEX$operator(dartMap, key, value);
  }
}

// Converts the JavaScript Object into a Dart SendPort.
function isolate$convertJsToDartPort(obj, objTable) {
  if (isolate$useWorkers) {
    return new isolate$SendPort(obj.token, obj.workerId);
  } else {
    return obj;
  }
}
